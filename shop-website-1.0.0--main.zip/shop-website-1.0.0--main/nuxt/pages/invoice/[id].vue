<template>
   <div class="invoice-page-wrapper">
      <div class="container py-4">
         <div v-if="isLoading" class="d-flex flex-column justify-content-center align-items-center py-5 min-vh-50">
            <div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;"></div>
            <h5 class="fw-bold mt-3 text-secondary animate-pulse">Sedang Memuat Data Invoice...</h5>
         </div>

         <div v-else-if="error" class="glass-card error-card text-center animate-fade-in p-5 mx-auto"
            style="max-width: 500px">
            <div class="error-icon"><i class="bi bi-exclamation-triangle-fill text-danger display-1"></i></div>
            <h4 class="fw-bold mt-4 text-white">Gagal Memuat Data</h4>
            <p class="text-secondary">{{ error }}</p>
            <button @click="$router.push('/dashboard')" class="btn-explore mt-3">Kembali ke Dashboard</button>
         </div>

         <div v-else-if="invoice" class="row g-4 justify-content-center animate-slide-up">
            <!-- Left Panel (QR & Actions) -->
            <div class="col-lg-5 printable-hidden">
               <div
                  class="premium-glass-card h-100 d-flex flex-column text-center p-4 p-md-5 position-relative overflow-hidden">
                  <div class="card-glow-bg"></div>

                  <div class="mb-4 position-relative z-1">
                     <span class="status-badge-lg shadow-sm" :class="statusBadgeClass">
                        <i :class="statusIconClass" class="me-2"></i> {{ invoice.status }}
                     </span>
                  </div>

                  <template v-if="invoice.status === 'Pending'">
                     <h4 class="fw-bold text-gradient mb-1">Menunggu Pembayaran</h4>
                     <p class="text-secondary small mb-4">Scan kode QRIS di bawah untuk membayar</p>

                     <div class="qr-container-outer mx-auto mb-4">
                        <div class="qr-wrapper shadow-lg">
                           <div class="qr-scanner-line"></div>
                           <img v-if="!qrError" :src="invoice.qr" alt="QRIS Payment Code" class="img-fluid rounded qr-image" @error="qrError = true" />
                           <div v-else class="qr-error-fallback text-center p-4">
                              <i class="bi bi-qr-code-scan text-danger" style="font-size: 3rem;"></i>
                              <p class="text-danger fw-bold mt-2 mb-1">Gagal Memuat QRIS</p>
                              <small class="text-secondary">Silakan klik "Saya Sudah Bayar" untuk refresh, atau batalkan dan buat pesanan baru.</small>
                           </div>
                        </div>
                        <div class="qr-footer-label mt-3">
                           <img src="https://upload.wikimedia.org/wikipedia/commons/a/a2/Logo_QRIS.svg" height="20"
                              alt="QRIS">
                        </div>
                     </div>

                     <div v-if="countdownText" class="countdown-box mb-4">
                        <span class="text-secondary d-block small mb-1">Batas Waktu:</span>
                        <h3 class="fw-bold mb-0 font-monospace text-warning">{{ countdownText }}</h3>
                     </div>

                     <div class="d-grid gap-3 z-1">
                        <button
                           class="btn btn-premium btn-lg w-100 d-flex align-items-center justify-content-center shadow-lg"
                           @click="checkPaymentStatus" :disabled="isChecking">
                           <span v-if="isChecking" class="spinner-border spinner-border-sm me-2"></span>
                           <i v-else class="bi bi-arrow-clockwise me-2"></i>
                           {{ isChecking ? 'Mengecek...' : 'Saya Sudah Bayar' }}
                        </button>
                        <button
                           class="btn btn-outline-danger btn-lg w-100 d-flex align-items-center justify-content-center"
                           @click="confirmCancelInvoice" :disabled="isChecking">
                           <i class="bi bi-x-circle me-2"></i> Batalkan Invoice
                        </button>
                     </div>
                  </template>

                  <template v-else-if="invoice.status === 'Lunas'">
                     <div class="success-illustration my-auto z-1">
                        <div class="success-icon-wrap mb-4">
                           <i class="bi bi-patch-check-fill text-success display-1 shadow-success-icon"></i>
                        </div>
                        <h3 class="fw-bold mt-2 mb-2 text-white">Pembayaran Berhasil!</h3>
                        <p class="text-secondary fs-6">Terima kasih atas pesanan Anda. Transaksi #{{ invoice.id }} telah
                           selesai.</p>

                        <div class="d-grid gap-2 mt-4">
                           <button @click="printInvoice" class="btn btn-outline-primary shadow-sm">
                              <i class="bi bi-printer me-2"></i> Cetak Struk / Simpan PDF
                           </button>
                           <NuxtLink to="/dashboard" class="btn btn-link text-secondary text-decoration-none">
                              <i class="bi bi-speedometer2 me-1"></i> Dashboard Akun
                           </NuxtLink>
                        </div>
                     </div>
                  </template>

                  <template v-else>
                     <div class="expired-illustration my-auto z-1">
                        <i class="bi bi-x-circle-fill text-danger display-1 opacity-75"></i>
                        <h3 class="fw-bold mt-4 mb-2 text-white">Invoice Hangus</h3>
                        <p class="text-secondary">Waktu pembayaran telah habis atau dibatalkan. Silakan buat pesanan
                           baru.</p>
                        <NuxtLink to="/products" class="btn btn-premium mt-3">Kembali Belanja</NuxtLink>
                     </div>
                  </template>
               </div>
            </div>

            <!-- Right Panel (Transaction Details & Receipt) -->
            <div class="col-lg-7">
               <div class="receipt-outer-container">
                  <div class="premium-glass-card h-100 p-4 p-md-5 receipt-shadow" id="printable-area">
                     <!-- Receipt Header (Print Only) -->
                     <div class="receipt-header-print text-center mb-4 d-none d-print-block">
                        <h2 class="fw-bold mb-1">STRUK PEMBAYARAN</h2>
                        <h5 class="text-secondary mb-0">{{ webName }}</h5>
                        <hr class="border-secondary opacity-50 my-3">
                     </div>

                     <div
                        class="d-flex justify-content-between align-items-center border-bottom border-secondary border-opacity-25 pb-3 mb-4">
                        <h4 class="fw-bold mb-0 text-white"><i class="bi bi-receipt me-2 text-primary"></i> Detail
                           Transaksi</h4>
                        <div class="text-end">
                           <p class="text-secondary mb-0 small">ID: <span class="font-monospace text-white">{{
                              invoice.id }}</span>
                           </p>
                           <small class="text-secondary">{{ formatDate(invoice.createdAt) }}</small>
                        </div>
                     </div>

                     <div class="receipt-card-body">
                        <div class="row g-4 mb-4">
                           <div class="col-sm-6">
                              <div class="detail-box h-100">
                                 <small class="text-secondary d-block mb-1"><i class="bi bi-credit-card me-1"></i>
                                    Metode
                                    Pembayaran</small>
                                 <strong class="d-block text-white fs-5">{{ invoice.paymentMethod.toUpperCase()
                                 }}</strong>
                              </div>
                           </div>
                           <div class="col-sm-6">
                              <div class="detail-box h-100">
                                 <small class="text-secondary d-block mb-1"><i class="bi bi-person me-1"></i>
                                    Customer</small>
                                 <strong class="d-block text-white text-truncate">{{ invoice.email }}</strong>
                              </div>
                           </div>
                        </div>

                        <!-- Optional Additional Info -->
                        <div v-if="invoice.additionalInformation && invoice.additionalInformation.length > 0"
                           class="mb-5">
                           <h6 class="fw-bold text-primary mb-3"><i class="bi bi-info-circle me-2"></i>Konfigurasi
                              Layanan</h6>
                           <div
                              class="detail-box-group rounded-3 overflow-hidden border border-secondary border-opacity-25">
                              <div v-for="info in invoice.additionalInformation" :key="info.name"
                                 class="detail-row p-3 d-flex justify-content-between align-items-center border-bottom border-dark border-opacity-25 bg-black bg-opacity-10 hover-bg-light">
                                 <span class="text-secondary">{{ info.name }}</span>
                                 <strong class="text-white text-end">{{ info.value }}</strong>
                              </div>
                           </div>
                        </div>

                        <!-- Order Items Table -->
                        <h6 class="fw-bold text-primary mb-3"><i class="bi bi-bag-check me-2"></i>Item Pesanan</h6>
                        <div class="order-table-wrapper mb-4">
                           <table class="table table-dark table-borderless align-middle mb-0">
                              <thead class="border-bottom border-secondary border-opacity-25">
                                 <tr>
                                    <th class="text-secondary py-3 ps-0"
                                       style="font-size: 0.8rem; text-transform: uppercase;">
                                       Produk</th>
                                    <th class="text-secondary py-3 text-center"
                                       style="font-size: 0.8rem; text-transform: uppercase;">Qty</th>
                                    <th class="text-secondary py-3 text-end pe-0"
                                       style="font-size: 0.8rem; text-transform: uppercase;">Harga</th>
                                 </tr>
                              </thead>
                              <tbody>
                                 <tr v-for="item in invoice.items" :key="item.name"
                                    class="border-bottom border-secondary border-opacity-10">
                                    <td class="py-3 ps-0">
                                       <span class="d-block fw-bold text-white">{{ item.name }}</span>
                                    </td>
                                    <td class="py-3 text-center text-white">{{ item.quantity }}</td>
                                    <td class="py-3 text-end pe-0 text-white fw-bold">{{ formatCurrency(item.price *
                                       item.quantity)
                                    }}</td>
                                 </tr>
                              </tbody>
                           </table>
                        </div>

                        <!-- Fee & Tax -->
                        <div class="d-flex justify-content-between align-items-center mb-4 px-2">
                           <span class="text-secondary fst-italic small">Biaya Layanan & Pajak</span>
                           <span class="text-secondary fw-bold">{{ formatCurrency(invoice.fee) }}</span>
                        </div>

                        <!-- Total -->
                        <div class="total-receipt-box p-4 rounded-4 shadow-lg mb-4">
                           <div class="d-flex justify-content-between align-items-center">
                              <div class="total-label-wrap">
                                 <span class="fw-bold text-white-50 small text-uppercase letter-spacing-1">Total
                                    Pembayaran</span>
                                 <h4 class="fw-bold text-white mb-0 mt-1">LUNAS</h4>
                              </div>
                              <div class="total-value-wrap text-end">
                                 <h2 class="fw-bolder text-white mb-0 font-monospace display-6">{{
                                    formatCurrency(invoice.total) }}
                                 </h2>
                              </div>
                           </div>
                        </div>

                        <!-- Download Section -->
                        <div v-if="invoice.status === 'Lunas' && downloadableItems.length > 0"
                           class="download-section mt-5 animate-fade-in printable-hidden">
                           <h6 class="fw-bold text-success mb-3 d-flex align-items-center">
                              <span class="pulse-green me-2"></span>
                              Akses Produk Digital
                           </h6>

                           <div v-if="isDownloadExpired"
                              class="alert custom-alert-danger d-flex align-items-center rounded-4">
                              <i class="bi bi-clock-history fs-3 me-3"></i>
                              <div>
                                 <strong>Sesi Akses Berakhir</strong><br>
                                 <small>Masa berlaku unduhan telah habis. Silakan hubungi dukungan pelanggan.</small>
                              </div>
                           </div>
                           <div v-else class="row g-3">
                              <div v-for="item in downloadableItems" :key="item.name" class="col-sm-6">
                                 <a :href="item.file.data" :download="item.file.type === 'local'" target="_blank"
                                    rel="noopener noreferrer"
                                    class="premium-download-btn w-100 p-4 h-100 d-flex flex-column align-items-center justify-content-center text-decoration-none rounded-4">
                                    <i class="bi bi-download fs-2 mb-3"></i>
                                    <strong>Download {{ item.name }}</strong>
                                    <small class="mt-1 opacity-75">Klik untuk mengunduh file</small>
                                 </a>
                              </div>
                           </div>
                        </div>

                        <!-- Receipt Footer (Print Only) -->
                        <div class="receipt-footer-print text-center mt-5 d-none d-print-block">
                           <p class="text-secondary small mb-0">Terima kasih telah berbelanja di {{ webName }}</p>
                           <p class="text-secondary small">Simpan struk ini sebagai bukti transaksi yang sah.</p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import Swal from 'sweetalert2'

useHead({ title: 'Invoice Pembayaran' })
const config = useRuntimeConfig()
const { $api }: any = useNuxtApp()
const route = useRoute()
const router = useRouter()
const id = Array.isArray(route.params.id) ? route.params.id[0] : route.params.id

const webName = computed(() => config.public.webName || 'Yilzi Shop')

interface FileObject { type: 'local' | 'cloud'; data: string }
interface ItemWithFile extends Item { file: FileObject }
interface Item { name: string; price: number; quantity: number; file?: FileObject }
interface AdditionalInfo { name: string; value: string }
interface ApiData {
   _id: string; email: string; amount: number; items: (Item & { productId: string })[]
   qr: string; status: 'Pending' | 'Success' | 'Paid' | 'Expired' | 'Kadaluwarsa' | 'Cancelled'; created_at: string
   paid_at?: string; payment_method: string; additional_information?: AdditionalInfo[]
}
interface Invoice {
   id: string; status: string; email: string; createdAt: string; paidAt?: string
   expiresAt: string; items: Item[]; fee: number; total: number; qr: string
   paymentMethod: string; additionalInformation?: AdditionalInfo[]
}

const invoice = ref<Invoice | null>(null)
const isLoading = ref<boolean>(true)
const isChecking = ref<boolean>(false)
const error = ref<string | null>(null)
const countdownText = ref<string>('')
const isDownloadExpired = ref(false)
const qrError = ref(false)

let countdownInterval: NodeJS.Timeout | null = null
let paymentCheckInterval: NodeJS.Timeout | null = null
let expirationCheckInterval: NodeJS.Timeout | null = null

const downloadableItems = computed((): ItemWithFile[] => invoice.value?.items.filter((item): item is ItemWithFile => !!item.file) || [])

const statusBadgeClass = computed(() => {
   if (!invoice.value) return 'bg-secondary text-white'
   switch (invoice.value.status) {
      case 'Lunas': return 'bg-success text-white border-success'
      case 'Kadaluwarsa': case 'Cancelled': return 'bg-danger text-white border-danger'
      case 'Pending': return 'bg-warning text-dark border-warning'
      default: return 'bg-secondary text-white'
   }
})

const statusIconClass = computed(() => {
   if (!invoice.value) return 'bi-info-circle'
   switch (invoice.value.status) {
      case 'Lunas': return 'bi-check-circle-fill'
      case 'Kadaluwarsa': case 'Cancelled': return 'bi-x-circle-fill'
      case 'Pending': return 'bi-hourglass-split'
      default: return 'bi-info-circle'
   }
})

const formatCurrency = (value: number) => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(value)
const formatDate = (dateString: string) => new Date(dateString).toLocaleString('id-ID', { dateStyle: 'medium', timeStyle: 'short' })
const padZero = (num: number) => String(num).padStart(2, '0')

const stopAllIntervals = () => {
   if (countdownInterval) clearInterval(countdownInterval)
   if (paymentCheckInterval) clearInterval(paymentCheckInterval)
   if (expirationCheckInterval) clearInterval(expirationCheckInterval)
}

const checkDownloadExpiration = () => {
   if (!invoice.value?.paidAt) return
   const expirationHours = (config.public.downloadLinkExpiresInHours as number) || 1
   const paidTimestamp = new Date(invoice.value.paidAt).getTime()
   const expirationTimestamp = paidTimestamp + (expirationHours * 60 * 60 * 1000)
   if (Date.now() > expirationTimestamp) {
      isDownloadExpired.value = true
      if (expirationCheckInterval) clearInterval(expirationCheckInterval)
   }
}

const updateCountdown = () => {
   if (!invoice.value?.expiresAt || invoice.value.status !== 'Pending') {
      stopAllIntervals()
      if (invoice.value) countdownText.value = ''
      return
   }
   const now = new Date().getTime()
   const expirationTime = new Date(invoice.value.expiresAt).getTime()
   const timeDifference = expirationTime - now
   if (timeDifference <= 0) {
      if (invoice.value) invoice.value.status = 'Kadaluwarsa'
      countdownText.value = 'Waktu Habis'
      stopAllIntervals()
      return
   }
   const minutes = Math.floor((timeDifference % (1000 * 60 * 60)) / (1000 * 60))
   const seconds = Math.floor((timeDifference % (1000 * 60)) / 1000)
   countdownText.value = `${padZero(minutes)}:${padZero(seconds)}`
}

const pollPaymentStatus = async (isManual: boolean = false) => {
   if (!invoice.value || invoice.value.status !== 'Pending') return
   if (isManual) {
      isChecking.value = true
   }
   try {
      const response = await $api('/api/v1/check', { method: 'POST', body: { id: invoice.value.id } })
      if (response.status) {
         await fetchInvoice()
         if (isManual) {
            Swal.fire({
               html: `
                  <div class="swal-success-icon-wrap my-4 d-flex justify-content-center align-items-center">
                     <div class="swal-success-glow" style="position: absolute; width: 80px; height: 80px; background: rgba(16,185,129,0.3); filter: blur(25px); border-radius: 50%;"></div>
                     <i class="bi bi-check-circle-fill text-success" style="font-size: 5rem; z-index: 10;"></i>
                  </div>
                  <h2 class="fw-bolder text-success mb-3" style="letter-spacing: -0.5px;">Pembayaran Berhasil!</h2>
                  <p class="text-secondary pb-3 fs-6">Terima kasih banyak atas pesanan Anda. Kami telah memverifikasi pembayaran sebesar <b class="text-white bg-dark px-2 py-1 rounded shadow-sm ms-1">${formatCurrency(invoice.value.total)}</b>.</p>
                  <hr class="border-secondary opacity-25">
                  <p class="text-secondary small mt-3"><i class="bi bi-shield-check me-1 text-primary"></i> Transaksi Anda diproses dengan aman & terjamin.</p>
               `,
               showConfirmButton: true,
               confirmButtonText: '<i class="bi bi-box-arrow-in-right me-2"></i>Lihat Pesanan & Unduh File',
               confirmButtonColor: '#10B981',
               customClass: { popup: 'premium-swal-popup rounded-4 border border-success border-opacity-25' },
               backdrop: 'rgba(0,0,0,0.85)'
            })
         }
      } else if (isManual) {
         Swal.fire({
            html: `
               <h4 class="fw-bold text-warning mb-2"><i class="bi bi-hourglass-top me-2"></i>Masih Pending</h4>
               <p class="text-secondary">Kami belum menerima dana untuk invoice ini. Pastikan Anda telah mentransfer sesuai nominal QRIS.</p>
               <div class="mt-3 p-2 bg-dark bg-opacity-25 rounded small text-secondary">ID Transaksi: ${invoice.value.id}</div>
            `,
            icon: 'info',
            confirmButtonColor: '#3B82F6',
            confirmButtonText: 'Tutup',
            customClass: { popup: 'premium-swal-popup' }
         })
      }
   } catch (err: any) {
      if (isManual) {
         const msg = err.data?.msg || 'Gagal menghubungi server. Tidak usah panik, coba lagi.'
         Swal.fire({
            title: 'Info',
            text: msg,
            icon: msg.includes('sedang berlangsung') ? 'info' : 'error',
            confirmButtonColor: '#3B82F6',
            customClass: { popup: 'premium-swal-popup' }
         })
      }
   } finally {
      if (isManual) isChecking.value = false
   }
}

const checkPaymentStatus = () => pollPaymentStatus(true)

const printInvoice = () => {
   window.print()
}

const confirmCancelInvoice = async () => {
   const res = await Swal.fire({
      title: 'Batalkan Invoice?',
      html: "<p class='text-secondary'>Invoice ini akan hangus dan tidak dapat dibayar lagi. Apakah Anda yakin?</p>",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#dc3545',
      cancelButtonColor: '#475569',
      confirmButtonText: '<i class="bi bi-x-circle me-1"></i> Ya, Batalkan!',
      cancelButtonText: 'Kembali',
      customClass: { popup: 'premium-swal-popup' }
   })

   if (res.isConfirmed) {
      try {
         isChecking.value = true
         const resp = await $api('/api/v1/invoice/cancel', { method: 'POST', body: { id: invoice.value!.id } })
         if (resp.status) {
            Swal.fire({
               icon: 'success', title: 'Dibatalkan', text: resp.msg,
               customClass: { popup: 'premium-swal-popup' }, confirmButtonColor: '#10B981'
            })
            await fetchInvoice()
         } else throw new Error(resp.msg)
      } catch (err: any) {
         Swal.fire('Gagal!', err.data?.msg || err.message, 'error')
      } finally {
         isChecking.value = false
      }
   }
}

const fetchInvoice = async () => {
   try {
      if (!invoice.value) isLoading.value = true
      qrError.value = false
      const response = await $api(`/api/v1/invoice?id=${id}`) as { status: boolean; data: ApiData }
      if (!response || !response.status || !response.data) throw new Error('Invoice tidak ditemukan atau Anda tidak memiliki akses.')

      const apiData = response.data
      const itemsTotal = apiData.items?.reduce((sum, item) => sum + (Number(item.price) * item.quantity), 0)
      const calculatedFee = apiData.amount - itemsTotal
      const createdAt = new Date(apiData.created_at)
      const expiresAt = new Date(createdAt.getTime() + 15 * 60 * 1000).toISOString() // 15 mins expiry for display

      const mappedStatus = apiData.status === 'Paid' || apiData.status === 'Success' ? 'Lunas' : apiData.status === 'Cancelled' ? 'Kadaluwarsa' : apiData.status

      invoice.value = {
         id: apiData._id,
         status: mappedStatus,
         email: apiData.email,
         createdAt: apiData.created_at,
         paidAt: apiData.paid_at,
         expiresAt: expiresAt,
         items: apiData.items.map(item => ({ ...item })),
         fee: calculatedFee,
         total: apiData.amount,
         qr: apiData.qr,
         paymentMethod: apiData.payment_method || 'qris',
         additionalInformation: apiData.additional_information || []
      }

      stopAllIntervals()

      if (invoice.value.status === 'Pending') {
         updateCountdown()
         countdownInterval = setInterval(updateCountdown, 1000)
         paymentCheckInterval = setInterval(() => pollPaymentStatus(false), 5000)
      } else if (invoice.value.status === 'Lunas') {
         checkDownloadExpiration()
         expirationCheckInterval = setInterval(checkDownloadExpiration, 60000)
      }

   } catch (e: any) {
      error.value = e.data?.msg || e.message || "Gagal memuat detail invoice. Silakan coba login kembali."
      stopAllIntervals()
   } finally {
      isLoading.value = false
   }
}

onMounted(fetchInvoice)
onUnmounted(stopAllIntervals)
</script>

<style scoped>
.invoice-page-wrapper {
   width: 100%;
   min-height: 100vh;
   background: radial-gradient(circle at 50% -20%, rgba(139, 92, 246, 0.15) 0%, transparent 60%), var(--app-bg);
}

.premium-glass-card {
   background: var(--app-card-bg);
   backdrop-filter: blur(20px);
   border: 1px solid var(--app-border-color);
   border-radius: 24px;
   transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
}

.receipt-shadow {
   box-shadow: 0 40px 80px -20px rgba(0, 0, 0, 0.5), inset 0 0 0 1px rgba(255, 255, 255, 0.03);
}

.card-glow-bg {
   position: absolute;
   top: -20%;
   right: -20%;
   width: 60%;
   height: 60%;
   background: radial-gradient(circle at center, rgba(139, 92, 246, 0.15) 0%, transparent 70%);
   z-index: 0;
   pointer-events: none;
}

.text-gradient {
   background: linear-gradient(135deg, var(--app-text-color) 0%, var(--app-secondary-text-color) 100%);
   -webkit-background-clip: text;
   -webkit-text-fill-color: transparent;
   background-clip: text;
}

.status-badge-lg {
   display: inline-flex;
   align-items: center;
   padding: 0.6rem 1.5rem;
   border-radius: 50px;
   font-weight: 800;
   font-size: 0.85rem;
   text-transform: uppercase;
   letter-spacing: 1.5px;
   box-shadow: 0 10px 20px -5px rgba(0, 0, 0, 0.3);
}

.qr-container-outer {
   position: relative;
   max-width: 280px;
}

.qr-wrapper {
   position: relative;
   padding: 1.5rem;
   background: #fff;
   border-radius: 20px;
   overflow: hidden;
}

.qr-scanner-line {
   position: absolute;
   top: 0;
   left: 0;
   width: 100%;
   height: 3px;
   background: #3b82f6;
   box-shadow: 0 0 20px 2px #3b82f6;
   animation: scan 2.5s ease-in-out infinite;
   z-index: 10;
}

@keyframes scan {

   0%,
   100% {
      top: 0%;
      opacity: 0;
   }

   5%,
   95% {
      opacity: 1;
   }

   50% {
      top: 100%;
   }
}

.qr-image {
   width: 100%;
   height: auto;
   display: block;
}

.qr-error-fallback {
   min-height: 200px;
   display: flex;
   flex-direction: column;
   align-items: center;
   justify-content: center;
}

.countdown-box {
   background: var(--app-surface);
   padding: 1.25rem;
   border-radius: 16px;
   border: 1px solid var(--app-border-color);
}

.btn-premium {
   background: var(--gradient-primary);
   color: #fff;
   border: none;
   font-weight: 700;
   padding: 1rem;
   border-radius: 16px;
   transition: all 0.3s;
}

.btn-premium:hover:not(:disabled) {
   transform: translateY(-3px);
   box-shadow: 0 15px 30px -10px rgba(139, 92, 246, 0.6);
}

.detail-box {
   background: var(--app-surface);
   padding: 1.25rem;
   border-radius: 16px;
   border: 1px solid var(--app-border-color);
}

.hover-bg-light:hover {
   background: rgba(255, 255, 255, 0.03) !important;
}

.total-receipt-box {
   background: var(--app-card-bg);
   border: 1.5px solid var(--primary-gradient-start);
   position: relative;
   overflow: hidden;
}

.total-receipt-box::after {
   content: '';
   position: absolute;
   top: 0;
   left: 0;
   width: 100%;
   height: 100%;
   background: linear-gradient(90deg, transparent, rgba(139, 92, 246, 0.1), transparent);
   transform: translateX(-100%);
   animation: shimmer 3s infinite;
}

@keyframes shimmer {
   100% {
      transform: translateX(100%);
   }
}

.premium-download-btn {
   background: rgba(16, 185, 129, 0.08);
   border: 1px solid rgba(16, 185, 129, 0.2);
   color: #10B981;
   transition: all 0.3s;
}

.premium-download-btn:hover {
   background: rgba(16, 185, 129, 0.15);
   border-color: #10B981;
   transform: translateY(-5px);
}

.pulse-green {
   width: 10px;
   height: 10px;
   background: #10B981;
   border-radius: 50%;
   display: inline-block;
   animation: pulse-green 2s infinite;
}

@keyframes pulse-green {
   0% {
      transform: scale(0.95);
      box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7);
   }

   70% {
      transform: scale(1);
      box-shadow: 0 0 0 10px rgba(16, 185, 129, 0);
   }

   100% {
      transform: scale(0.95);
      box-shadow: 0 0 0 0 rgba(16, 185, 129, 0);
   }
}

.animate-pulse {
   animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
}

@keyframes pulse {

   0%,
   100% {
      opacity: 1;
   }

   50% {
      opacity: .5;
   }
}

@media print {
   body {
      background: white !important;
      color: black !important;
   }

   .invoice-page-wrapper {
      background: white !important;
      min-height: auto;
      padding: 0 !important;
   }

   .printable-hidden {
      display: none !important;
   }

   .premium-glass-card {
      background: white !important;
      border: none !important;
      box-shadow: none !important;
      backdrop-filter: none !important;
      color: black !important;
      padding: 0 !important;
   }

   .text-white,
   .text-secondary,
   .text-primary {
      color: black !important;
   }

   .bg-black,
   .bg-dark,
   .total-receipt-box {
      background: white !important;
      border: 1px solid #ddd !important;
      color: black !important;
   }

   .table {
      color: black !important;
      border: 1px solid #eee;
   }

   #printable-area {
      width: 100% !important;
      margin: 0 !important;
   }
}

/* SweetAlert Overrides */
:deep(.premium-swal-popup) {
   background: var(--app-card-bg) !important;
   border: 1px solid var(--app-border-color) !important;
   color: var(--app-text-color) !important;
}
</style>
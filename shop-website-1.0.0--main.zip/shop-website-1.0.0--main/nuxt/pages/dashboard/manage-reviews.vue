<template>
    <div class="dashboard-page-wrapper">
        <div class="container">
            <div class="page-header mb-4">
                <h1 class="page-title">Manajemen Ulasan</h1>
            </div>
        </div>

        <div class="container">
            <div class="content-card-modern shadow-xl">
                <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-3">
                    <h5 class="fw-bold mb-0 d-flex align-items-center gap-2">
                        <i class="bi bi-star-fill text-warning"></i> Daftar Ulasan Global
                    </h5>
                    <div class="d-flex align-items-center gap-2">
                        <span
                            class="badge bg-primary bg-opacity-10 text-primary border border-primary px-3 py-2 rounded-pill shadow-sm">
                            Total: {{ reviews.length }} Ulasan
                        </span>
                    </div>
                </div>

                <div class="card-body position-relative p-0">
                    <div v-if="isLoading" class="text-center py-5">
                        <div class="spinner-border text-primary" role="status"></div>
                        <p class="mt-3 text-secondary tracking-wider fw-semibold">Menyelaraskan data ulasan...</p>
                    </div>
                    <div v-else-if="error" class="alert alert-glass-danger m-4 border-0 shadow-sm">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i> {{ error }}
                    </div>
                    <div v-else>
                        <div class="table-responsive">
                            <table class="table app-table align-middle mb-0">
                                <thead>
                                    <tr>
                                        <th scope="col" class="ps-4">Pembeli</th>
                                        <th scope="col">Produk Detail</th>
                                        <th scope="col" class="text-center">Penilaian</th>
                                        <th scope="col">Komentar</th>
                                        <th scope="col" class="text-center">Tanggal</th>
                                        <th scope="col" class="text-center pe-4">Tindakan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-for="review in reviews" :key="review._id" class="review-row">
                                        <td class="ps-4">
                                            <div class="d-flex align-items-center gap-3">
                                                <div class="avatar-circle">
                                                    {{ review.userName ? review.userName.charAt(0).toUpperCase() :
                                                        review.userEmail.charAt(0).toUpperCase() }}
                                                </div>
                                                <div class="d-flex flex-column">
                                                    <span class="fw-bold user-name-text">{{ review.userName || 'Guest'
                                                    }}</span>
                                                    <small class="text-secondary user-email-text">{{ review.userEmail
                                                    }}</small>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="product-badge">
                                                <i class="bi bi-box-seam text-primary me-2"></i>
                                                <span class="text-truncate d-inline-block fw-semibold"
                                                    style="max-width: 150px; vertical-align: bottom;">
                                                    {{ review.productName || review.productId }}
                                                </span>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="rating-badge" :class="getRatingClass(review.rating)">
                                                <i class="bi bi-star-fill me-1"></i> {{ review.rating }}.0
                                            </div>
                                        </td>
                                        <td>
                                            <div class="comment-box custom-scrollbar">
                                                <span v-if="review.comment">{{ review.comment }}</span>
                                                <span v-else class="text-muted fst-italic"><i class="bi bi-dash"></i>
                                                    Tidak ada teks</span>
                                            </div>
                                        </td>
                                        <td class="text-center text-secondary small fw-medium">
                                            {{ formatDate(review.created_at) }}
                                        </td>
                                        <td class="text-center pe-4">
                                            <button class="btn btn-sm btn-delete-modern"
                                                title="Hapus Ulasan Bintang Rendah/Spam"
                                                @click="deleteReview(review._id, review.productId)">
                                                <i class="bi bi-trash3-fill"></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <tr v-if="reviews.length === 0 && !isLoading">
                                        <td colspan="6" class="p-0 border-0">
                                            <div class="empty-state-modern py-5 text-center">
                                                <div class="empty-icon-wrap mb-3">
                                                    <i class="bi bi-stars text-warning display-4"></i>
                                                </div>
                                                <h5 class="fw-bold text-secondary">Belum Ada Ulasan</h5>
                                                <p class="text-secondary opacity-75 small">Masih sepi, belum ada pembeli
                                                    yang memberikan komentar.</p>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import Swal from 'sweetalert2'

const { $api }: any = useNuxtApp()
useHead({ title: 'Manajemen Ulasan' })

const reviews = ref<any[]>([])
const isLoading = ref(true)
const error = ref<string | null>(null)

const formatDate = (dateString: string) => {
    if (!dateString) return '-'
    return new Date(dateString).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })
}

const getRatingClass = (rating: number) => {
    if (rating >= 4) return 'rating-high';
    if (rating === 3) return 'rating-mid';
    return 'rating-low';
}

const fetchReviews = async () => {
    isLoading.value = true
    error.value = null
    try {
        const response = await $api('/api/v2/reviews')
        if (response && response.status && response.data) {
            reviews.value = response.data
        } else {
            throw new Error(response.msg || 'Gagal memuat data')
        }
    } catch (e: any) {
        error.value = e.message
    } finally {
        isLoading.value = false
    }
}

const deleteReview = (id: string, productId: string) => {
    Swal.fire({
        title: 'Hapus Ulasan?',
        text: 'Ulasan ini akan dihapus secara permanen!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#ef4444',
        cancelButtonColor: '#3b82f6',
        confirmButtonText: '<i class="bi bi-trash3 me-1"></i> Ya, Hapus',
        cancelButtonText: 'Batal',
        background: 'var(--app-card-bg)',
        color: 'var(--app-text-color)',
        customClass: {
            popup: 'modern-swal-popup rounded-4 border border-secondary border-opacity-25 shadow-lg'
        }
    }).then(async (result) => {
        if (result.isConfirmed) {
            try {
                const response = await $api(`/api/v2/reviews/${id}?productId=${productId}`, { method: 'DELETE' })
                if (!response.status) { throw new Error(response.msg) }
                Swal.fire({
                    title: 'Dihapus!',
                    text: 'Ulasan telah berhasil dihapus.',
                    icon: 'success',
                    background: 'var(--app-card-bg)',
                    color: 'var(--app-text-color)',
                    customClass: { popup: 'rounded-4' }
                })
                fetchReviews()
            } catch (e: any) {
                Swal.fire('Gagal!', e.message, 'error')
            }
        }
    })
}

onMounted(() => {
    fetchReviews()
})
</script>

<style scoped>
.dashboard-page-wrapper {
    width: 100%;
    min-height: 100vh;
    padding-top: 2rem;
    padding-bottom: 4rem;
}

.page-header {
    text-align: center;
    margin-bottom: 2rem;
}

.page-title {
    font-size: 1.875rem;
    font-weight: 800;
    background: var(--gradient-primary);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin-bottom: 0.25rem;
}

.content-card-modern {
    background: var(--app-card-bg);
    border: 1px solid var(--app-border-color);
    border-radius: 20px;
    overflow: hidden;
}

.card-header {
    background: rgba(139, 92, 246, 0.03);
    border-bottom: 1px solid var(--app-border-color);
    padding: 1.5rem;
}

.alert-glass-danger {
    background: rgba(239, 68, 68, 0.1);
    color: #ef4444;
    border-radius: 16px;
    padding: 1rem 1.5rem;
}

.review-row {
    transition: all 0.2s ease;
}

.review-row:hover {
    background-color: rgba(139, 92, 246, 0.04);
}

.avatar-circle {
    width: 44px;
    height: 44px;
    min-width: 44px;
    border-radius: 50%;
    background: linear-gradient(135deg, rgba(139, 92, 246, 0.15), rgba(59, 130, 246, 0.15));
    color: var(--primary-gradient-start);
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 800;
    font-size: 1.2rem;
    border: 1px solid rgba(139, 92, 246, 0.2);
    box-shadow: 0 4px 10px rgba(139, 92, 246, 0.1);
}

.user-name-text {
    font-size: 0.95rem;
    color: var(--app-text-color);
    letter-spacing: 0.3px;
}

.user-email-text {
    font-size: 0.8rem;
    opacity: 0.7;
}

.product-badge {
    display: inline-flex;
    align-items: center;
    background: var(--app-surface);
    border: 1px solid var(--app-border-color);
    padding: 0.5rem 0.8rem;
    border-radius: 10px;
    font-size: 0.85rem;
    color: var(--app-text-color);
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
}

.rating-badge {
    display: inline-flex;
    align-items: center;
    padding: 0.4rem 0.8rem;
    border-radius: 50px;
    font-weight: 700;
    font-size: 0.85rem;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
}

.rating-high {
    background: rgba(16, 185, 129, 0.1);
    color: #10b981;
    border: 1px solid rgba(16, 185, 129, 0.2);
}

.rating-mid {
    background: rgba(245, 158, 11, 0.1);
    color: #f59e0b;
    border: 1px solid rgba(245, 158, 11, 0.2);
}

.rating-low {
    background: rgba(239, 68, 68, 0.1);
    color: #ef4444;
    border: 1px solid rgba(239, 68, 68, 0.2);
}

.comment-box {
    background: var(--app-surface);
    border: 1px solid var(--app-border-color);
    border-radius: 12px;
    padding: 0.8rem 1rem;
    font-size: 0.9rem;
    color: var(--app-secondary-text-color);
    max-width: 280px;
    max-height: 60px;
    overflow-y: auto;
    line-height: 1.5;
    scrollbar-width: thin;
    box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.02);
}

.comment-box::-webkit-scrollbar {
    width: 4px;
}

.comment-box::-webkit-scrollbar-thumb {
    background-color: var(--app-border-color);
    border-radius: 4px;
}

.btn-delete-modern {
    width: 40px;
    height: 40px;
    border-radius: 12px;
    background: rgba(239, 68, 68, 0.1);
    color: #ef4444;
    border: 1px solid rgba(239, 68, 68, 0.2);
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    margin: 0 auto;
}

.btn-delete-modern:hover {
    background: #ef4444;
    color: white;
    transform: scale(1.08) translateY(-2px);
    box-shadow: 0 8px 20px rgba(239, 68, 68, 0.35);
}

.empty-state-modern {
    background: var(--app-surface-translucent);
    border-radius: 16px;
    margin: 2rem;
    border: 1px dashed var(--app-border-color);
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.02);
}

.shadow-xl {
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.08) !important;
}
</style>

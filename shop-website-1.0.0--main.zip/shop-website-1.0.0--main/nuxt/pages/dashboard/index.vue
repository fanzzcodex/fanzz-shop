<template>
   <div class="dashboard-page">
      <div class="container px-3 py-4">
         <DashboardAdmin v-if="type === 'admin'" />
         <DashboardUser v-else />
      </div>
   </div>
</template>

<script setup lang="ts">
const { type } = useAuth()
useHead({ title: 'Dashboard' })
</script>

<style scoped>
.dashboard-page {
   padding-bottom: 2rem;
}
</style>
<template>
    <div class="dashboard-page-wrapper">
        <div class="container py-4">
            <div class="d-flex justify-content-between align-items-center mb-4 animate-slide-up">
                <h3 class="fw-bold mb-0 text-white"><i class="bi bi-people-fill me-2 text-primary"></i>Manajemen
                    Pengguna</h3>
                <button @click="$router.push('/dashboard')" class="btn-outline-premium btn-sm"><i
                        class="bi bi-arrow-left me-1"></i>Kembali</button>
            </div>

            <div class="premium-glass-card p-4 mx-auto animate-slide-up" style="animation-delay: 0.1s;">
                <!-- Search & Filter -->
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div class="search-bar position-relative" style="max-width:300px; width:100%">
                        <i
                            class="bi bi-search position-absolute top-50 start-0 translate-middle-y ms-3 text-secondary"></i>
                        <input type="search" v-model="searchQuery" @keyup.enter="fetchUsers"
                            class="form-control premium-input ps-5" placeholder="Cari email atau nama...">
                    </div>
                    <button @click="fetchUsers" class="btn-explore" :disabled="isLoading"><i
                            class="bi bi-arrow-clockwise me-1"></i>Refresh</button>
                </div>

                <!-- Table -->
                <div
                    class="table-responsive rounded shadow-sm border border-secondary border-opacity-25 overflow-hidden">
                    <table class="table table-dark table-hover mb-0 align-middle custom-table">
                        <thead class="table-dark-header">
                            <tr>
                                <th><i class="bi bi-person me-2"></i>Pengguna</th>
                                <th><i class="bi bi-shield-lock me-2"></i>Tipe/Peran</th>
                                <th><i class="bi bi-activity me-2"></i>Status</th>
                                <th><i class="bi bi-calendar-event me-2"></i>Terdaftar</th>
                                <th class="text-end"><i class="bi bi-gear me-2"></i>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-if="isLoading">
                                <td colspan="5" class="text-center py-5">
                                    <div class="spinner-border text-primary" role="status"></div>
                                </td>
                            </tr>
                            <tr v-else-if="users.length === 0">
                                <td colspan="5" class="text-center py-5 text-secondary">Tidak ada pengguna ditemukan.
                                </td>
                            </tr>
                            <tr v-else v-for="user in users" :key="user.email">
                                <td>
                                    <div class="fw-bold text-white">{{ user.name }}</div>
                                    <small class="text-secondary font-monospace">{{ user._id || user.email }}</small>
                                </td>
                                <td>
                                    <span class="badge" :class="user.type === 'admin' ? 'bg-danger' : 'bg-primary'">{{
                                        user.type?.toUpperCase() }}</span>
                                </td>
                                <td>
                                    <span class="status-pill"
                                        :class="user.status === 'blocked' ? 'pill-failed' : 'pill-paid'">
                                        <i
                                            :class="user.status === 'blocked' ? 'bi bi-slash-circle' : 'bi bi-check-circle'"></i>
                                        {{ user.status === 'blocked' ? 'Terblokir' : 'Aktif' }}
                                    </span>
                                </td>
                                <td>
                                    <small class="text-secondary">{{ formatDate(user.joined_at) || 'N/A' }}</small>
                                </td>
                                <td class="text-end">
                                    <button class="btn btn-sm btn-outline-primary me-2 rounded-circle btn-icon"
                                        title="Detail User" @click="viewUserDetail(user)">
                                        <i class="bi bi-eye"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-info me-2 rounded-circle btn-icon"
                                        title="Kirim Pesan" @click="openMessageModal(user)">
                                        <i class="bi bi-envelope"></i>
                                    </button>
                                    <button v-if="user.status !== 'blocked' && user.type !== 'admin'"
                                        class="btn btn-sm btn-outline-danger me-2 rounded-circle btn-icon"
                                        title="Blokir User" @click="toggleBlock(user, 'block')">
                                        <i class="bi bi-slash-circle"></i>
                                    </button>
                                    <button v-else-if="user.status === 'blocked'"
                                        class="btn btn-sm btn-outline-success me-2 rounded-circle btn-icon"
                                        title="Unblock User" @click="toggleBlock(user, 'unblock')">
                                        <i class="bi bi-check2-circle"></i>
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <div v-if="pagination.totalPages > 1" class="d-flex justify-content-between align-items-center mt-3">
                    <small class="text-secondary">Menampilkan {{ users.length }} dari {{ pagination.total }}
                        pengguna</small>
                    <div class="btn-group">
                        <button class="btn btn-outline-secondary btn-sm" :disabled="pagination.page === 1"
                            @click="changePage(pagination.page - 1)"><i class="bi bi-chevron-left"></i></button>
                        <button class="btn btn-secondary btn-sm" disabled>{{ pagination.page }}</button>
                        <button class="btn btn-outline-secondary btn-sm"
                            :disabled="pagination.page === pagination.totalPages"
                            @click="changePage(pagination.page + 1)"><i class="bi bi-chevron-right"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import Swal from 'sweetalert2'

useHead({ title: 'Manajemen Pengguna' })
const { $api } = useNuxtApp()

const isLoading = ref(true)
const users = ref([])
const searchQuery = ref('')
const pagination = ref({ page: 1, limit: 10, totalPages: 1, total: 0 })

const fetchUsers = async () => {
    try {
        isLoading.value = true
        const resp = await $api(`/api/v2/users?page=${pagination.value.page}&search=${searchQuery.value}`)
        if (resp.status) {
            users.value = resp.data.users
            pagination.value = resp.data.pagination
        }
    } catch (e) {
        console.log('Error fetching users:', e)
    } finally {
        isLoading.value = false
    }
}

const changePage = (p) => {
    pagination.value.page = p
    fetchUsers()
}

const viewUserDetail = async (user) => {
    try {
        Swal.fire({
            title: 'Memuat...',
            allowOutsideClick: false,
            didOpen: () => { Swal.showLoading() },
            background: 'var(--app-card-bg)',
            color: 'var(--app-text-color)'
        })
        const resp = await $api(`/api/v2/user/${user.email || user._id}`)
        if (!resp.status) throw new Error(resp.msg)

        const detail = resp.data.user;
        const stats = resp.data.stats;

        Swal.fire({
            title: 'Detail Pengguna',
            html: `
                <div class="text-start mt-3 px-2">
                    <div class="d-flex align-items-center mb-4 pb-3 border-bottom border-secondary border-opacity-25">
                        <div class="avatar-circle-lg me-3" style="width:60px; height:60px; background:linear-gradient(135deg,rgba(139,92,246,0.2),rgba(59,130,246,0.2)); border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:1.8rem; font-weight:bold; color:var(--primary-color)">
                            ${(detail.name || 'G').charAt(0).toUpperCase()}
                        </div>
                        <div>
                            <h4 class="fw-bold mb-0">${detail.name}</h4>
                            <span class="badge ${detail.type === 'admin' ? 'bg-danger' : 'bg-primary'} bg-opacity-10 text-${detail.type === 'admin' ? 'danger' : 'primary'} border border-${detail.type === 'admin' ? 'danger' : 'primary'} fs-6 py-1 px-2 mt-2">${(detail.type || detail.role || 'User').toUpperCase()}</span>
                        </div>
                    </div>
                    
                    <div class="row g-3 mb-4">
                        <div class="col-sm-6">
                            <label class="text-secondary small fw-bold mb-1">Email</label>
                            <p class="font-monospace text-wrap mb-0">${detail._id || detail.email}</p>
                        </div>
                        <div class="col-sm-6">
                            <label class="text-secondary small fw-bold mb-1">Metode Daftar</label>
                            <p class="mb-0 text-capitalize">${detail.registrationType || 'Tidak diketahui'}</p>
                        </div>
                        <div class="col-sm-6">
                            <label class="text-secondary small fw-bold mb-1">Terdaftar Pada</label>
                            <p class="mb-0">${formatDate(detail.joined_at)}</p>
                        </div>
                        <div class="col-sm-6">
                            <label class="text-secondary small fw-bold mb-1">Status</label>
                            <p class="mb-0">
                                <span class="status-pill pb-1 pt-1 ${detail.status === 'blocked' ? 'pill-failed' : 'pill-paid'}">
                                    <i class="${detail.status === 'blocked' ? 'bi bi-slash-circle' : 'bi bi-check-circle'}"></i> 
                                    ${detail.status === 'blocked' ? 'Terblokir' : 'Aktif'}
                                </span>
                            </p>
                        </div>
                    </div>
                    
                    <div class="bg-dark bg-opacity-25 rounded-3 p-3 border border-secondary border-opacity-25">
                        <h6 class="fw-bold text-primary mb-3"><i class="bi bi-graph-up me-2"></i>Aktivitas Pembelian</h6>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="text-secondary">Total Transaksi Selesai</span>
                            <span class="fw-bold fs-5">${stats.totalTransactions} <small class="text-secondary fs-6 fw-normal">Trx</small></span>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="text-secondary">Total Pengeluaran</span>
                            <span class="fw-bold fs-5 text-success">Rp ${Number(stats.totalSpent).toLocaleString('id-ID')}</span>
                        </div>
                    </div>
                </div>
            `,
            confirmButtonText: 'Tutup',
            confirmButtonColor: '#475569',
            customClass: { popup: 'premium-swal-popup rounded-4', htmlContainer: 'custom-scrollbar' },
            background: 'var(--app-card-bg)',
            color: 'var(--app-text-color)',
            width: '500px'
        })
    } catch (e) {
        Swal.fire('Error', e.message || 'Gagal memuat profil', 'error')
    }
}

const toggleBlock = async (user, action) => {
    const actionText = action === 'block' ? 'Blokir' : 'Unblock'
    const btnColor = action === 'block' ? '#dc3545' : '#198754'

    const { value: reason, isConfirmed } = await Swal.fire({
        title: `${actionText} ${user.name}?`,
        input: action === 'block' ? 'text' : undefined,
        inputLabel: action === 'block' ? 'Alasan pemblokiran (Akan tampil pada pengguna)' : '',
        inputPlaceholder: action === 'block' ? 'Contoh: Pelanggaran spam' : '',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: `Ya, ${actionText}`,
        confirmButtonColor: btnColor,
        cancelButtonText: 'Batal'
    })

    if (isConfirmed) {
        try {
            const resp = await $api('/api/v2/users/status', {
                method: 'POST',
                body: { email: user._id || user.email, action, reason: reason || 'Pelanggaran Ketentuan' }
            })
            if (resp.status) {
                Swal.fire('Sukses', resp.msg, 'success')
                fetchUsers()
            } else {
                Swal.fire('Gagal', resp.msg, 'error')
            }
        } catch (e) {
            Swal.fire('Gagal', e.data?.msg || 'Gagal tersambung ke server', 'error')
        }
    }
}

const openMessageModal = async (user) => {
    const { value: formValues } = await Swal.fire({
        title: `Kirim Pesan ke ${user.name}`,
        html: `
         <div class="text-start mt-2">
           <label class="form-label text-secondary small mb-1 fw-bold">Judul Pesan</label>
           <input id="dm-title" class="form-control premium-swal-input mb-3" placeholder="Masukkan judul pesan">
           
           <label class="form-label text-secondary small mb-1 fw-bold">Kategori/Tag</label>
           <select id="dm-tag" class="form-select premium-swal-input mb-3">
              <option value="Info">Info</option>
              <option value="Penting">Penting</option>
              <option value="Diskon">Diskon</option>
           </select>
           
           <label class="form-label text-secondary small mb-1 fw-bold">Isi Pesan</label>
           <textarea id="dm-body" class="form-control premium-swal-input" style="height: 120px; resize:none;" placeholder="Ketik pesan Anda..."></textarea>
         </div>
      `,
        focusConfirm: false,
        showCancelButton: true,
        confirmButtonText: '<i class="bi bi-send-fill me-1"></i> Kirim Pesan',
        cancelButtonText: 'Batal',
        customClass: {
            popup: 'premium-glass-card border-secondary text-white',
            title: 'text-white fs-5 mt-2',
            confirmButton: 'btn-explore btn px-4',
            cancelButton: 'btn-ghost btn px-4 border-secondary text-white'
        },
        background: 'transparent',
        preConfirm: () => {
            return {
                title: document.getElementById('dm-title').value,
                tag: document.getElementById('dm-tag').value,
                message: document.getElementById('dm-body').value
            }
        }
    })

    if (formValues) {
        if (!formValues.title || !formValues.message) return Swal.fire({ icon: 'warning', title: 'Oops', text: 'Judul dan Pesan wajib diisi', background: '#1e293b', color: '#fff' })

        try {
            const res = await $api('/api/v2/direct-message', {
                method: 'POST',
                body: { email: user._id || user.email, ...formValues }
            })
            if (res.status) Swal.fire('Terkirim!', res.msg, 'success')
            else Swal.fire('Error', res.msg, 'error')
        } catch (e) {
            Swal.fire('Error', 'Gagal mengirim pesan', 'error')
        }
    }
}

const formatDate = (dateString) => {
    if (!dateString) return ''
    return new Date(dateString).toLocaleDateString('id-ID', { year: 'numeric', month: 'short', day: 'numeric' })
}

onMounted(fetchUsers)
</script>

<style scoped>
.dashboard-page-wrapper {
    min-height: 100vh;
    width: 100%;
}

.premium-glass-card {
    background: var(--app-card-bg);
    border: 1px solid var(--app-border-color);
    border-radius: 20px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
}

.premium-input {
    background: rgba(0, 0, 0, 0.2) !important;
    border: 1px solid rgba(255, 255, 255, 0.1) !important;
    color: var(--app-text-color) !important;
    border-radius: 10px;
}

.premium-input:focus {
    border-color: var(--primary-color) !important;
    box-shadow: 0 0 0 0.25rem rgba(139, 92, 246, 0.25) !important;
}

body.light-mode .premium-input {
    background: #fff !important;
    border: 1px solid #ced4da !important;
}

.table-dark-header {
    background: rgba(30, 41, 59, 0.9);
}

body.light-mode .table-dark-header {
    background: #f8f9fa;
    color: #212529;
}

body.light-mode .custom-table {
    background-color: #fff !important;
    color: #212529 !important;
}

.status-pill {
    padding: 0.35rem 0.8rem;
    border-radius: 50px;
    font-size: 0.8rem;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    gap: 0.4rem;
}

.pill-paid {
    background: rgba(16, 185, 129, 0.1);
    color: #10B981;
    border: 1px solid rgba(16, 185, 129, 0.2);
}

.pill-failed {
    background: rgba(239, 68, 68, 0.1);
    color: #EF4444;
    border: 1px solid rgba(239, 68, 68, 0.2);
}

.btn-icon {
    width: 32px;
    height: 32px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 0;
}

:deep(.premium-swal-input) {
    background: rgba(0, 0, 0, 0.2) !important;
    border: 1px solid rgba(255, 255, 255, 0.1) !important;
    color: #fff !important;
}

:deep(.premium-swal-input:focus) {
    border-color: #8b5cf6 !important;
    box-shadow: 0 0 0 0.25rem rgba(139, 92, 246, 0.25) !important;
}

body.light-mode :deep(.premium-swal-input) {
    background: #fff !important;
    border: 1px solid #ced4da !important;
    color: #212529 !important;
}
</style>

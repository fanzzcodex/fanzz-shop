<template>
   <div class="profile-page">
      <div class="container px-3 py-4">

         <div class="d-flex align-items-center mb-4 gap-3">
            <NuxtLink to="/dashboard" class="btn-icon bg-glass">
               <i class="bi bi-arrow-left"></i>
            </NuxtLink>
            <h3 class="fw-bold mb-0">Pengaturan Profil</h3>
         </div>

         <div v-if="isLoading" class="loading-container">
            <div class="spinner-border text-primary" role="status">
               <span class="visually-hidden">Loading...</span>
            </div>
         </div>

         <div v-else class="row g-4">
            <!-- Profil Info Card -->
            <div class="col-lg-6">
               <div class="glass-card p-4 h-100 animate-slide-up">
                  <h5 class="fw-bold mb-4"><i class="bi bi-person-lines-fill me-2 text-primary"></i>Informasi Akun</h5>

                  <form @submit.prevent="updateProfile">
                     <!-- Profile Picture Upload UI -->
                     <div class="mb-4 d-flex justify-content-center align-items-center flex-column">
                        <div class="profile-pic-wrapper mb-3">
                           <img :src="form.profilePicture || '/images/profile-yilzi.jpg'" alt="Profile Photo"
                              class="profile-pic" />
                           <label class="camera-btn" for="profile-upload" title="Ubah Foto Profil">
                              <i class="bi bi-camera-fill"></i>
                           </label>
                           <input type="file" id="profile-upload" accept="image/*" class="d-none"
                              @change="handleFileChange">
                        </div>
                        <small class="text-secondary">Klik ikon kamera untuk mengunggah foto</small>
                     </div>

                     <div class="mb-3">
                        <label class="form-label text-secondary small">Email (Tidak bisa diubah)</label>
                        <input type="email" class="form-control" :value="user.email" disabled>
                     </div>
                     <div class="mb-3">
                        <label class="form-label text-secondary small">Nama Lengkap</label>
                        <input type="text" class="form-control" v-model="form.name" required>
                     </div>
                     <div class="mb-3">
                        <label class="form-label text-secondary small">Username</label>
                        <input type="text" class="form-control" v-model="form.username">
                        <small class="text-muted">Username unik untuk profil Anda (opsional)</small>
                     </div>
                     <div class="mb-4">
                        <label class="form-label text-secondary small">Nomor WhatsApp</label>
                        <input type="tel" class="form-control" v-model="form.phone" placeholder="Contoh: 628...">
                        <small class="text-muted">Disarankan menyertakan kode negara (62)</small>
                     </div>
                     <button type="submit"
                        class="btn btn-primary w-100 d-flex align-items-center justify-content-center gap-2"
                        :disabled="isSubmitting">
                        <span v-if="isSubmitting" class="spinner-border spinner-border-sm"></span>
                        <i v-else class="bi bi-save"></i>
                        Simpan Perubahan
                     </button>
                  </form>
               </div>
            </div>

            <!-- Ganti Password Card -->
            <div class="col-lg-6">
               <div class="glass-card p-4 h-100 animate-slide-up" style="animation-delay: 0.1s">
                  <h5 class="fw-bold mb-4"><i class="bi bi-shield-lock-fill me-2 text-danger"></i>Keamanan Akun</h5>

                  <div v-if="!hasPassword" class="alert alert-warning mb-0 border-0">
                     <div class="d-flex align-items-center gap-3">
                        <i class="bi bi-google fs-3"></i>
                        <div>
                           <strong>Login via Google</strong>
                           <p class="mb-0 small">Akun Anda didaftarkan menggunakan Google, sehingga Anda tidak memiliki
                              dan tidak memerlukan password.</p>
                        </div>
                     </div>
                  </div>

                  <form v-else @submit.prevent="updatePassword">
                     <div class="mb-3">
                        <label class="form-label text-secondary small">Password Lama</label>
                        <input type="password" class="form-control" v-model="pwdForm.oldPassword" required
                           placeholder="Masukkan password saat ini">
                     </div>
                     <div class="mb-3">
                        <label class="form-label text-secondary small">Password Baru</label>
                        <input type="password" class="form-control" v-model="pwdForm.newPassword" required
                           placeholder="Minimal 6 karakter" minlength="6">
                     </div>
                     <div class="mb-4">
                        <label class="form-label text-secondary small">Konfirmasi Password Baru</label>
                        <input type="password" class="form-control" v-model="pwdForm.confirmPassword" required
                           placeholder="Ulangi password baru" minlength="6">
                     </div>
                     <button type="submit"
                        class="btn btn-outline-danger w-100 d-flex align-items-center justify-content-center gap-2"
                        :disabled="isPwdSubmitting">
                        <span v-if="isPwdSubmitting" class="spinner-border spinner-border-sm"></span>
                        <i v-else class="bi bi-key"></i>
                        Ganti Password
                     </button>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import Swal from 'sweetalert2'

const { $api } = useNuxtApp()

useHead({ title: 'Profil Saya' })

const isLoading = ref(true)
const isSubmitting = ref(false)
const isPwdSubmitting = ref(false)

const user = ref<any>({})
const hasPassword = ref(false)

const form = ref({
   name: '',
   username: '',
   phone: '',
   profilePicture: ''
})

const pwdForm = ref({
   oldPassword: '',
   newPassword: '',
   confirmPassword: ''
})

const fetchProfile = async () => {
   isLoading.value = true
   try {
      const res = await $api('/api/v1/profile')
      if (res.status && res.data) {
         user.value = res.data
         form.value.name = res.data.name || ''
         form.value.username = res.data.username || ''
         form.value.phone = res.data.phone || ''
         form.value.profilePicture = res.data.profile_picture || ''

         // Assuming backend sends a flag or we can guess based on login type.
         // Let's rely on registrationType setting if available, otherwise just try
         hasPassword.value = res.data.registrationType !== 'google'
      } else {
         throw new Error(res.msg || 'Gagal memuat profil')
      }
   } catch (e: any) {
      Swal.fire({ icon: 'error', title: 'Ups...', text: e.message || e.data?.msg || 'Terjadi kesalahan' })
   } finally {
      isLoading.value = false
   }
}

const updateProfile = async () => {
   isSubmitting.value = true
   try {
      const payload = {
         action: 'updateProfile',
         name: form.value.name,
         username: form.value.username,
         phone: form.value.phone,
         profile_picture: form.value.profilePicture
      }
      const res = await $api('/api/v1/profile', {
         method: 'POST',
         body: payload
      })
      if (res.status) {
         Swal.fire({ icon: 'success', title: 'Berhasil', text: res.msg, timer: 2000, showConfirmButton: false })
         user.value.name = form.value.name
      } else {
         throw new Error(res.msg)
      }
   } catch (e: any) {
      Swal.fire({ icon: 'error', title: 'Gagal', text: e.message || e.data?.msg || 'Terjadi kesalahan' })
   } finally {
      isSubmitting.value = false
   }
}

const updatePassword = async () => {
   if (pwdForm.value.newPassword !== pwdForm.value.confirmPassword) {
      return Swal.fire({ icon: 'warning', title: 'Perhatian', text: 'Konfirmasi password tidak cocok' })
   }

   isPwdSubmitting.value = true
   try {
      const payload = {
         action: 'updatePassword',
         oldPassword: pwdForm.value.oldPassword,
         newPassword: pwdForm.value.newPassword
      }
      const res = await $api('/api/v1/profile', {
         method: 'POST',
         body: payload
      })
      if (res.status) {
         Swal.fire({ icon: 'success', title: 'Berhasil', text: 'Password telah diubah', timer: 2000, showConfirmButton: false })
         pwdForm.value.oldPassword = ''
         pwdForm.value.newPassword = ''
         pwdForm.value.confirmPassword = ''
      } else {
         throw new Error(res.msg)
      }
   } catch (e: any) {
      Swal.fire({ icon: 'error', title: 'Gagal', text: e.message || e.data?.msg || 'Terjadi kesalahan mengubah password' })
   } finally {
      isPwdSubmitting.value = false
   }
}

const handleFileChange = (e: any) => {
   const file = e.target.files[0]
   if (!file) return
   if (!file.type.startsWith('image/')) {
      Swal.fire({ icon: 'error', title: 'File tidak valid', text: 'Silakan pilih gambar' })
      return
   }

   const reader = new FileReader()
   reader.onload = (event) => {
      const img = new Image()
      img.onload = () => {
         const canvas = document.createElement('canvas')
         const MAX_SIZE = 200
         let width = img.width
         let height = img.height

         if (width > height) {
            if (width > MAX_SIZE) {
               height *= MAX_SIZE / width
               width = MAX_SIZE
            }
         } else {
            if (height > MAX_SIZE) {
               width *= MAX_SIZE / height
               height = MAX_SIZE
            }
         }

         canvas.width = width
         canvas.height = height
         const ctx = canvas.getContext('2d')
         ctx?.drawImage(img, 0, 0, width, height)

         // Compress to JPEG 80% to keep it small
         form.value.profilePicture = canvas.toDataURL('image/jpeg', 0.8)
      }
      img.src = event.target?.result as string
   }
   reader.readAsDataURL(file)
}

onMounted(() => {
   fetchProfile()
})
</script>

<style scoped>
.profile-page {
   padding-top: 1.5rem;
   padding-bottom: 2rem;
}

.glass-card {
   border-radius: 20px;
}

.btn-icon {
   width: 40px;
   height: 40px;
   display: inline-flex;
   align-items: center;
   justify-content: center;
   border-radius: 50%;
   color: var(--app-text-color);
   transition: all 0.3s;
   text-decoration: none;
}

.bg-glass {
   background: var(--app-surface);
   border: 1px solid var(--app-border-color);
}

.bg-glass:hover {
   background: var(--app-border-color);
}

.loading-container {
   display: flex;
   justify-content: center;
   padding: 5rem 0;
}

.form-control {
   background: var(--app-surface);
   border: 1px solid var(--app-border-color);
   color: var(--app-text-color);
   padding: 0.75rem 1rem;
   border-radius: 10px;
   transition: all 0.3s ease;
}

.form-control:focus {
   border-color: #3b82f6;
   box-shadow: 0 0 0 0.25rem rgba(59, 130, 246, 0.25);
}

.form-control:disabled {
   background: rgba(0, 0, 0, 0.05);
   opacity: 0.7;
}

:global(body.dark-mode) .form-control:disabled {
   background: rgba(255, 255, 255, 0.05);
}

.btn {
   padding: 0.75rem 1.5rem;
   border-radius: 10px;
   font-weight: 600;
   transition: all 0.3s ease;
}

.btn-primary {
   background: linear-gradient(135deg, #3b82f6, #60a5fa);
   border: none;
   box-shadow: 0 4px 15px rgba(59, 130, 246, 0.3);
}

.btn-primary:hover {
   transform: translateY(-2px);
   box-shadow: 0 8px 25px rgba(59, 130, 246, 0.4);
}

.profile-pic-wrapper {
   position: relative;
   width: 120px;
   height: 120px;
   border-radius: 50%;
   padding: 4px;
   background: linear-gradient(135deg, #8B5CF6, #06B6D4);
   box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
}

.profile-pic {
   width: 100%;
   height: 100%;
   border-radius: 50%;
   object-fit: cover;
   background: var(--app-surface);
   border: 3px solid var(--app-surface);
}

.camera-btn {
   position: absolute;
   bottom: 0;
   right: 0;
   width: 36px;
   height: 36px;
   border-radius: 50%;
   background: var(--primary-gradient-start);
   color: white;
   display: flex;
   align-items: center;
   justify-content: center;
   cursor: pointer;
   border: 3px solid var(--app-surface);
   transition: all 0.3s ease;
}

.camera-btn:hover {
   background: var(--primary-gradient-end);
   transform: scale(1.1);
}
</style>

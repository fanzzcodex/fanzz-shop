<template>
    <div class="dashboard-page overflow-hidden">
        <div class="container-fluid px-3 py-4">
            <div class="d-flex align-items-center mb-4 animate-slide-up">
                <div>
                    <h3 class="fw-bold mb-0">Server Health & Console</h3>
                    <p class="text-secondary mb-0">Live monitoring activities and OS terminal command execution.</p>
                </div>
                <div class="ms-auto d-flex gap-2">
                    <button class="btn btn-outline-danger btn-sm" @click="serverLogs = []">
                        <i class="bi bi-trash"></i> Clear Console
                    </button>
                </div>
            </div>

            <!-- Terminal Window -->
            <div class="terminal-card animate-slide-up" style="animation-delay: 0.1s">
                <div class="terminal-header d-flex justify-content-between align-items-center">
                    <div class="d-flex align-items-center gap-2">
                        <span class="status-dot"></span>
                        <span class="terminal-title">admin@yilzicode:~</span>
                    </div>
                    <div class="d-flex gap-2">
                        <div class="circle circle-yellow"></div>
                        <div class="circle circle-green"></div>
                    </div>
                </div>

                <!-- Terminal Output -->
                <div class="terminal-body custom-scrollbar" ref="terminalBodyRef">
                    <div v-if="serverLogs.length === 0" class="terminal-empty">
                        Menunggu log jaringan dan internal server...
                    </div>
                    <div v-else class="log-container">
                        <div v-for="(log, idx) in serverLogs" :key="idx" class="log-line" :class="`log-${log.type}`">
                            <span class="log-time">[{{ new Date(log.timestamp).toLocaleTimeString() }}]</span>
                            <span class="log-type">[{{ log.type.toUpperCase() }}]</span>
                            <span class="log-message">{{ log.message }}</span>
                        </div>
                    </div>
                </div>

                <!-- Terminal Input -->
                <div class="terminal-footer">
                    <div class="input-group">
                        <span class="input-group-text terminal-prompt">➜ ~</span>
                        <input type="text" class="form-control terminal-input" v-model="commandInput"
                            @keyup.enter="sendCommand"
                            placeholder="Ketik perintah (node, npm, ls, ping, eval...) lalu tekan Enter"
                            autocomplete="off" spellcheck="false" autofocus />
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, nextTick } from 'vue'
import { io } from 'socket.io-client'

useHead({ title: 'Server Health & Console' })

const serverLogs = ref([])
const terminalBodyRef = ref(null)
const commandInput = ref('')
let socket = null

const sendCommand = () => {
    const cmd = commandInput.value.trim()
    if (!cmd) return

    // Simulasikan echo commmand
    serverLogs.value.push({
        type: 'command',
        message: cmd,
        timestamp: new Date().toISOString()
    })

    if (socket) {
        socket.emit('execute-command', cmd)
    }
    commandInput.value = ''
    scrollToBottom()
}

const scrollToBottom = () => {
    nextTick(() => {
        if (terminalBodyRef.value) {
            terminalBodyRef.value.scrollTop = terminalBodyRef.value.scrollHeight
        }
    })
}

onMounted(() => {
    const config = useRuntimeConfig()
    socket = io(config.public.baseURL || '', {
        transports: ['websocket', 'polling']
    })

    socket.on('connect_error', () => {
        console.warn('Socket connection failed on Vercel Serverless context.')
    })

    socket.on('server-log', (log) => {
        serverLogs.value.push(log)
        if (serverLogs.value.length > 500) {
            serverLogs.value.shift()
        }
        scrollToBottom()
    })

    serverLogs.value.push({
        type: 'info',
        message: 'Console environment terhubung. Ketik perintah Anda di bawah lalu tekan enter.',
        timestamp: new Date().toISOString()
    })
})

onUnmounted(() => {
    if (socket) socket.disconnect()
})
</script>

<style scoped>
.dashboard-page {
    height: 100%;
}

.terminal-card {
    background: #0f172a;
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
    display: flex;
    flex-direction: column;
    height: calc(100vh - 160px);
}

.terminal-header {
    background: #1e293b;
    padding: 0.75rem 1rem;
    border-bottom: 1px solid rgba(255, 255, 255, 0.05);
}

.status-dot {
    width: 10px;
    height: 10px;
    background: #10B981;
    border-radius: 50%;
    box-shadow: 0 0 10px rgba(16, 185, 129, 0.5);
    animation: pulse 2s infinite;
}

@keyframes pulse {
    0% {
        opacity: 1;
    }

    50% {
        opacity: 0.5;
    }

    100% {
        opacity: 1;
    }
}

.terminal-title {
    font-family: 'Consolas', 'Monaco', monospace;
    color: #e2e8f0;
    font-size: 0.9rem;
    letter-spacing: 0.5px;
}

.circle {
    width: 12px;
    height: 12px;
    border-radius: 50%;
}

.circle-yellow {
    background: #facc15;
}

.circle-green {
    background: #4ade80;
}

.terminal-body {
    flex-grow: 1;
    padding: 1rem;
    overflow-y: auto;
    font-family: 'Consolas', 'Monaco', monospace;
    font-size: 0.9rem;
    color: #f8fafc;
    background: #0f172a;
}

.terminal-empty {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100%;
    color: #64748b;
    font-style: italic;
}

.log-container {
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.log-line {
    word-break: break-all;
    line-height: 1.5;
    padding-bottom: 4px;
    border-bottom: 1px dashed rgba(255, 255, 255, 0.05);
}

.log-line:last-child {
    border-bottom: none;
}

.log-time {
    color: #94a3b8;
    margin-right: 8px;
    font-size: 0.8rem;
}

.log-type {
    font-weight: bold;
    margin-right: 8px;
}

.log-info .log-type {
    color: #3b82f6;
}

.log-warn .log-type {
    color: #f59e0b;
}

.log-error .log-type {
    color: #ef4444;
}

.log-command .log-type {
    color: #10b981;
}

.log-info .log-message {
    color: #e2e8f0;
}

.log-warn .log-message {
    color: #fde68a;
}

.log-error .log-message {
    color: #fca5a5;
}

.log-command .log-message {
    color: #10b981;
    font-weight: bold;
}

.terminal-footer {
    background: #0b1120;
    padding: 0.75rem 1rem;
    border-top: 1px solid rgba(255, 255, 255, 0.05);
}

.terminal-prompt {
    background: transparent;
    border: none;
    color: #10b981;
    font-weight: bold;
    font-family: 'Consolas', 'Monaco', monospace;
    padding-left: 0;
}

.terminal-input {
    background: transparent;
    border: none;
    box-shadow: none !important;
    color: #f8fafc;
    font-family: 'Consolas', 'Monaco', monospace;
    font-size: 1rem;
    padding-left: 0.5rem;
}

.terminal-input:focus {
    background: transparent;
    border: none;
    color: #f8fafc;
}

.terminal-input::placeholder {
    color: #475569;
}
</style>

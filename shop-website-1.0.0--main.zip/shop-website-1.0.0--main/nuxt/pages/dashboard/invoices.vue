<template>
   <div class="dashboard-page-wrapper">
      <div class="container">
      <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
         <h1 class="fw-bold mb-0">Manajemen Invoice</h1>
         <NuxtLink to="/dashboard" class="btn btn-outline-primary">
            <i class="bi bi-arrow-left me-2"></i>Kembali ke Dashboard
         </NuxtLink>
      </div>

      <div v-if="isLoadingInitial" class="d-flex justify-content-center align-items-center py-5">
         <div class="spinner-border product-loader-spinner" role="status"></div>
         <p class="ms-3 mb-0">Memuat data...</p>
      </div>

      <div v-else-if="errorInitial" class="content-card text-center p-5 text-danger">
         <i class="bi bi-exclamation-triangle-fill display-4 mb-3"></i>
         <h5 class="fw-bold">Gagal Memuat Data</h5>
         <p class="text-secondary">{{ errorInitial }}</p>
         <button @click="fetchInitialData" class="btn btn-custom-accent mt-3">Coba Lagi</button>
      </div>

      <div v-else>
         <div class="row g-4 mb-4">
            <div class="col-lg-6 col-md-6">
               <div class="content-card stat-card">
                  <i class="bi bi-graph-down icon"></i>
                  <div class="text-content">
                     <div class="label">Pendapatan Bulan Lalu</div>
                     <div class="value">Rp {{ formatCurrency(monthlyRevenue.lastMonth) }}</div>
                  </div>
               </div>
            </div>
            <div class="col-lg-6 col-md-6">
               <div class="content-card stat-card">
                  <i class="bi bi-graph-up icon"></i>
                  <div class="text-content">
                     <div class="label">Pendapatan Bulan Ini</div>
                     <div class="value">Rp {{ formatCurrency(monthlyRevenue.currentMonth) }}</div>
                  </div>
               </div>
            </div>
         </div>

         <div class="content-card position-relative">
            <div class="card-header">
               <h5 class="fw-bold mb-0">Daftar Semua Invoice</h5>
            </div>
            <div class="table-responsive">
               <table class="table app-table align-middle">
                  <thead>
                     <tr>
                        <th>ID Transaksi</th>
                        <th>Customer</th>
                        <th>Tanggal</th>
                        <th class="text-center">Status</th>
                        <th class="text-center">Aksi</th>
                     </tr>
                  </thead>
                  <tbody>
                     <tr v-if="transactions.length === 0 && !isTransactionsLoading">
                        <td colspan="5" class="text-center text-secondary py-4">
                           Tidak ada invoice yang ditemukan.
                        </td>
                     </tr>
                     <tr v-else v-for="sale in transactions" :key="sale._id">
                        <td class="text-secondary fw-bold">{{ sale._id }}</td>
                        <td class="text-truncate" style="max-width: 250px;">{{ sale.email || '-' }}</td>
                        <td class="text-secondary">{{ formatDateInvoice(sale.created_at) }}</td>
                        <td class="text-center">
                           <span class="status-badge" :class="`status-${sale.status.toLowerCase()}`">
                              {{ sale.status }}
                           </span>
                        </td>
                        <td class="text-center">
                           <button @click="showTransactionDetails(sale)" class="btn btn-sm btn-action-default me-1"
                              title="Lihat Detail"><i class="bi bi-info-circle"></i></button>
                           <button @click="$router.push(`/invoice/${sale._id}`)" class="btn btn-sm btn-action-default"
                              title="Buka Invoice"><i class="bi bi-box-arrow-up-right"></i></button>
                        </td>
                     </tr>
                  </tbody>
               </table>
            </div>
            <div class="card-footer">
               <div class="search-container">
                  <i class="bi bi-search search-icon"></i>
                  <input type="search" v-model="transactionSearchQuery" class="form-control search-input"
                     placeholder="Cari berdasarkan ID atau Email..." :disabled="isTransactionsLoading">
               </div>
               <nav v-if="totalTransactionPages > 1" class="pagination-container"
                  :class="{ 'pe-none opacity-50': isTransactionsLoading }">
                  <ul class="pagination">
                     <li :class="['page-item', { disabled: transactionCurrentPage === 1 }]"><a class="page-link"
                           href="#" @click.prevent="goToTransactionPage(transactionCurrentPage - 1)">Prev</a></li>
                     <li class="page-item pagination-summary"><span class="page-link">{{ transactionCurrentPage }} / {{
                           totalTransactionPages }}</span></li>
                     <li :class="['page-item', { disabled: transactionCurrentPage === totalTransactionPages }]"><a
                           class="page-link" href="#"
                           @click.prevent="goToTransactionPage(transactionCurrentPage + 1)">Next</a></li>
                  </ul>
               </nav>
            </div>
            <div v-if="isTransactionsLoading" class="table-overlay">
               <div class="spinner-border" role="status" style="color: var(--app-accent-color)"><span
                     class="visually-hidden">Loading...</span></div>
               <p class="ms-3 mb-0 fw-bold" style="color: var(--app-text-color)">Memuat data...</p>
            </div>
         </div>
      </div>
      </div>
   </div>

   <div class="modal fade" ref="transactionModalRef" tabindex="-1" aria-labelledby="transactionModalLabel"
      aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
         <div v-if="selectedTransaction" class="modal-content">
            <div class="modal-header">
               <h5 class="modal-title" id="transactionModalLabel">Detail Transaksi</h5>
               <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
               <table class="sys-info-table w-100">
                  <tbody>
                     <tr>
                        <td class="label">ID Transaksi</td>
                        <td class="colon">:</td>
                        <td class="value fw-bold">{{ selectedTransaction._id }}</td>
                     </tr>
                     <tr>
                        <td class="label">Customer</td>
                        <td class="colon">:</td>
                        <td class="value fw-bold">{{ selectedTransaction.email }}</td>
                     </tr>
                     <tr>
                        <td class="label">Tanggal</td>
                        <td class="colon">:</td>
                        <td class="value">{{ formatDateInvoice(selectedTransaction.created_at) }}</td>
                     </tr>
                     <tr>
                        <td class="label">Status</td>
                        <td class="colon">:</td>
                        <td class="value"><span class="status-badge"
                              :class="`status-${selectedTransaction.status.toLowerCase()}`">{{
                              selectedTransaction.status }}</span></td>
                     </tr>
                     <tr>
                        <td class="label">Produk</td>
                        <td class="colon">:</td>
                        <td class="value">
                           <ul class="list-unstyled mb-0">
                              <li v-for="name in selectedTransaction.productNames" :key="name">{{ name }}</li>
                           </ul>
                        </td>
                     </tr>
                     <tr>
                        <td class="label">Total Belanja</td>
                        <td class="colon">:</td>
                        <td class="value fw-bold">Rp {{ formatCurrency(selectedTransaction.amount) }}</td>
                     </tr>
                  </tbody>
               </table>
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
            </div>
         </div>
      </div>
   </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted, computed, watch } from 'vue'
import { useRouter, useRoute, type LocationQueryValue } from 'vue-router'
import { Modal } from 'bootstrap'

const { $api }: any = useNuxtApp()
const router = useRouter()
const route = useRoute()

useHead({ title: 'Manajemen Invoice' })

interface Invoice {
   _id: string
   email: string
   amount: number
   created_at: string
   status: string
   productNames?: string[]
}

interface MonthlyRevenue {
   currentMonth: number
   lastMonth: number
}

const getQueryParamAsString = (param: LocationQueryValue | LocationQueryValue[]): string => {
   if (Array.isArray(param)) {
      return param[0] || ''
   }
   return param || ''
}

const getQueryParamAsNumber = (param: LocationQueryValue | LocationQueryValue[]): number => {
   const str = getQueryParamAsString(param)
   return parseInt(str) || 1
}

const isLoadingInitial = ref(true)
const errorInitial = ref<string | null>(null)
const monthlyRevenue = ref<MonthlyRevenue>({ currentMonth: 0, lastMonth: 0 })

const transactions = ref<Invoice[]>([])
const totalTransactions = ref(0)
const isTransactionsLoading = ref(true)
const transactionSearchQuery = ref(getQueryParamAsString(route.query.search))
const transactionCurrentPage = ref(getQueryParamAsNumber(route.query.page))
const transactionItemsPerPage = ref(10)

const selectedTransaction = ref<Invoice | null>(null)
const transactionModalRef = ref<HTMLElement | null>(null)
let modalInstance: Modal | null = null

const totalTransactionPages = computed(() => Math.ceil(totalTransactions.value / transactionItemsPerPage.value) || 1)

const formatCurrency = (value: number) => Number(value || 0).toLocaleString('id-ID')
const formatDateInvoice = (dateString: string) => new Date(dateString).toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })

const goToTransactionPage = async (page: number) => {
   if (page >= 1 && page <= totalTransactionPages.value && page !== transactionCurrentPage.value) {
      await router.push({ query: { ...route.query, page: page } })
   }
}

const showTransactionDetails = (transaction: Invoice) => {
   selectedTransaction.value = transaction
   modalInstance?.show()
}

const fetchTransactions = async () => {
   isTransactionsLoading.value = true
   try {
      const params = new URLSearchParams({
         page: transactionCurrentPage.value.toString(),
         limit: transactionItemsPerPage.value.toString(),
         search: transactionSearchQuery.value,
      })
      const response = await $api(`/api/v2/invoices?${params.toString()}`)
      if (response && response.status && response.data) {
         transactions.value = response.data.invoices
         totalTransactions.value = response.data.total
      } else {
         transactions.value = []
         totalTransactions.value = 0
      }
   } catch (e: any) {
      console.error("Error fetching invoices:", e)
      transactions.value = []
      totalTransactions.value = 0
   } finally {
      isTransactionsLoading.value = false
   }
}

let transactionSearchTimeout: NodeJS.Timeout
watch(transactionSearchQuery, (newSearchQuery) => {
   clearTimeout(transactionSearchTimeout)
   transactionSearchTimeout = setTimeout(async () => {
      const query = { ...route.query, page: 1, search: newSearchQuery || undefined }
      await router.push({ query })
   }, 300)
})

watch(() => route.query, (newQuery) => {
   transactionCurrentPage.value = getQueryParamAsNumber(newQuery.page)
   transactionSearchQuery.value = getQueryParamAsString(newQuery.search)
   fetchTransactions()
}, { deep: true })

const fetchInitialData = async () => {
   isLoadingInitial.value = true
   errorInitial.value = null
   try {
      const revenuePromise = $api('/api/v2/statistic').then(res => {
         if (res.status && res.data) {
            monthlyRevenue.value = res.data.monthlyRevenue
         }
      })
      await Promise.all([
         revenuePromise,
         fetchTransactions()
      ])
   } catch (e: any) {
      errorInitial.value = e.message || 'Gagal memuat data awal.'
   } finally {
      isLoadingInitial.value = false
   }
}

onMounted(() => {
   fetchInitialData()
   if (transactionModalRef.value) {
      modalInstance = new Modal(transactionModalRef.value)
      transactionModalRef.value.addEventListener('hidden.bs.modal', () => {
         selectedTransaction.value = null
      })
   }
})

onUnmounted(() => {
   modalInstance?.dispose()
})
</script>

<style scoped>
.stat-card .icon {
   font-size: 2.8rem;
   color: var(--app-accent-color);
}

.stat-card .text-content .value {
   font-size: 2rem;
   font-weight: 600;
   line-height: 1.2;
   color: var(--app-text-color);
}

.stat-card .text-content .label {
   font-size: .9rem;
   text-transform: uppercase;
   color: var(--app-secondary-text-color);
   font-weight: 500;
}

.dashboard-page-wrapper {
   width: 100%;
   min-height: 100vh;
   padding-top: 2rem;
   padding-bottom: 4rem;
}
</style>
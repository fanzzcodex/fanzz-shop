<template>
   <div class="dashboard-page-wrapper">
      <div class="container">
         <div class="page-header mb-4">
            <h1 class="page-title">Tambah Produk Baru</h1>
            <p class="text-muted">Isi semua informasi produk Anda di bawah ini</p>
         </div>
      </div>
      
      <div class="container">
         <div class="content-card-modern p-4">
         <form @submit.prevent="handleSubmit">
            <div class="row g-4">
               <div class="col-md-7">
                  <div class="mb-3">
                     <label for="productName" class="form-label">Nama Produk</label>
                     <input type="text" class="form-control" id="productName" v-model="productData.name" required>
                  </div>
                  <div class="mb-3">
                     <label for="productDescription" class="form-label">Deskripsi (Markdown)</label>
                     <div class="editor-toolbar">
                        <button type="button" @click="formatText('bold')" title="Bold (Ctrl+B)"><i
                              class="bi bi-type-bold"></i></button>
                        <button type="button" @click="formatText('italic')" title="Italic (Ctrl+I)"><i
                              class="bi bi-type-italic"></i></button>
                        <button type="button" @click="formatText('heading')" title="Heading"><i
                              class="bi bi-type-h2"></i></button>
                        <button type="button" @click="formatText('list')" title="Unordered List"><i
                              class="bi bi-list-ul"></i></button>
                     </div>
                     <textarea class="form-control editor-textarea" id="productDescription" rows="8"
                        v-model="productData.description" ref="descriptionTextarea"></textarea>
                  </div>
                  <div class="row">
                     <div class="col-sm-6 mb-3">
                        <label for="productPrice" class="form-label">Harga</label>
                        <input type="number" class="form-control" id="productPrice" v-model="productData.price"
                           required>
                     </div>
                     <div class="col-sm-6 mb-3">
                        <label for="originalPrice" class="form-label">Harga Asli (Opsional)</label>
                        <input type="number" class="form-control" id="originalPrice"
                           v-model="productData.original_price" placeholder="Contoh: 500000">
                     </div>
                  </div>
                  <div class="mb-3">
                     <label for="productTag" class="form-label">Tag Produk (Opsional)</label>
                     <select class="form-select" id="productTag" v-model="productData.tag_id">
                        <option value="">-- Pilih tag --</option>
                        <option v-for="tag in allTags" :key="tag._id" :value="tag._id">
                           {{ tag.name }}
                        </option>
                     </select>
                  </div>

                  <div class="form-block-container mb-3">
                     <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" role="switch" id="stockUnlimited"
                           v-model="isStockUnlimited">
                        <label class="form-check-label" for="stockUnlimited">
                           <strong>Stok Tidak Terbatas</strong>
                        </label>
                     </div>
                     <p class="label-description mt-1">
                        Jika aktif, produk tidak akan pernah habis. Nonaktifkan untuk menentukan jumlah stok yang
                        tersedia.
                     </p>
                     <div v-if="!isStockUnlimited" class="mt-3">
                        <label for="productStock" class="form-label small mb-1">Jumlah Stok</label>
                        <input type="number" class="form-control" id="productStock" v-model="productData.stock"
                           placeholder="e.g., 50" min="0">
                     </div>
                  </div>

                  <div class="form-block-container mb-3">
                     <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" role="switch" id="isFeaturedSwitch"
                           v-model="productData.is_featured">
                        <label class="form-check-label" for="isFeaturedSwitch">
                           <strong>Jadikan Produk Unggulan</strong>
                        </label>
                     </div>
                     <p class="label-description mt-1">
                        Aktifkan untuk menampilkan produk ini di bagian khusus pada halaman utama.
                     </p>
                  </div>
               </div>

               <div class="col-md-5 d-flex flex-column">
                  <div class="mb-4">
                     <label class="form-label">Gambar Utama</label>
                     <div v-if="imagePreviewUrl" class="image-preview-container mb-2">
                        <img :src="imagePreviewUrl" alt="Preview Gambar Produk" class="img-preview">
                     </div>
                     <div class="image-upload-box text-center" @click="triggerFileInput" @dragover.prevent
                        @drop.prevent="handleFileDrop">
                        <div v-if="productData.image">
                           <i class="bi bi-file-earmark-image-fill upload-icon text-success"></i>
                           <p class="mb-0 text-truncate px-2" :title="productData.image.name">{{ productData.image.name
                           }}</p>
                           <button type="button" class="btn btn-sm btn-outline-danger mt-2"
                              @click.stop="removeImage">Ganti Gambar</button>
                        </div>
                        <div velse>
                           <i class="bi bi-cloud-arrow-up-fill upload-icon"></i>
                           <p class="text-secondary small">Klik atau seret gambar ke sini</p>
                        </div>
                     </div>
                     <input type="file" ref="fileInput" @change="handleFileChange"
                        accept="image/png, image/jpeg, image/gif, image/webp" class="d-none">
                  </div>

                  <div>
                     <label class="form-label d-flex justify-content-between">
                        Gambar Preview <span>{{ previewFiles.length }}/6</span>
                     </label>
                     <div class="preview-grid">
                        <div v-for="(slot, index) in 6" :key="index" class="preview-slot">
                           <div v-if="previewUrls[index]" class="slot-content">
                              <img :src="previewUrls[index]">
                              <button type="button" class="btn-remove-preview" @click="removePreview(index)">
                                 <i class="bi bi-x"></i>
                              </button>
                           </div>
                           <div velse-if="index === previewFiles.length" class="slot-add" @click="triggerPreviewInput">
                              <i class="bi bi-plus-lg"></i>
                           </div>
                           <div velse class="slot-empty"></div>
                        </div>
                     </div>
                     <input type="file" ref="previewInput" @change="handlePreviewChange" accept="image/*" class="d-none"
                        multiple>
                  </div>
               </div>
            </div>

            <hr class="my-4">

            <div class="mb-4">
               <h5 class="mb-3">File Produk (Opsional)</h5>
               <p class="small">Sediakan file digital yang akan diterima pembeli. Bisa berupa file upload atau link
                  eksternal.</p>
               <ul class="nav nav-tabs mb-3">
                  <li class="nav-item"><button class="nav-link" :class="{ active: fileSourceType === 'upload' }"
                        type="button" @click="setFileSourceType('upload')">Upload File</button></li>
                  <li class="nav-item"><button class="nav-link" :class="{ active: fileSourceType === 'url' }"
                        type="button" @click="setFileSourceType('url')">Gunakan URL</button></li>
               </ul>
               <div class="tab-content border-0">
                  <div v-if="fileSourceType === 'upload'">
                     <div class="mb-3">
                        <label class="form-label small">Tujuan Upload : &nbsp;</label>
                        <div class="form-check form-check-inline"><input class="form-check-input" type="radio"
                              id="uploadLocal" value="local" v-model="uploadDestination"><label class="form-check-label"
                              for="uploadLocal">Local</label></div>
                        <div class="form-check form-check-inline"><input class="form-check-input" type="radio"
                              id="uploadCloud" value="cloud" v-model="uploadDestination"><label class="form-check-label"
                              for="uploadCloud">Cloud</label></div>
                     </div>
                     <div class="image-upload-box text-center" @click="triggerProductFileInput">
                        <div v-if="productData.file && typeof productData.file === 'object'">
                           <i class="bi bi-file-zip-fill upload-icon text-success"></i>
                           <p class="mb-0 text-truncate px-2" :title="productData.file.name">{{ productData.file.name }}
                           </p>
                           <button type="button" class="btn btn-sm btn-outline-danger mt-2"
                              @click.stop="removeProductFile">Ganti File</button>
                        </div>
                        <div velse>
                           <i class="bi bi-cloud-arrow-up-fill upload-icon"></i>
                           <p class="text-secondary small">Klik atau seret file ke sini</p>
                        </div>
                     </div>
                     <input type="file" ref="productFileInput" @change="handleProductFileChange" class="d-none">
                  </div>
                  <div v-if="fileSourceType === 'url'">
                     <label for="fileUrl" class="form-label">Link File Produk</label>
                     <input type="url" class="form-control" id="fileUrl" v-model="productData.file"
                        placeholder="https://contoh.com/file-produk.zip">
                  </div>
               </div>
            </div>

            <div class="mb-4">
               <h5 class="mb-3">Informasi Tambahan dari Pembeli</h5>
               <p class="small">Tentukan label input yang harus diisi oleh pembeli.</p>
               <div v-for="(info, index) in productData.additional_information" :key="index"
                  class="row g-2 mb-2 align-items-center">
                  <div class="col"><input type="text" class="form-control" v-model="info.name"
                        placeholder="Nama Label (Contoh: Username Github)"></div>
                  <div class="col-auto"><button type="button" class="btn btn-md btn-action-default"
                        @click="removeInfo(index)" title="Hapus Label"><i class="bi bi-trash-fill"></i></button></div>
               </div>
               <button type="button" class="btn btn-sm btn-outline-secondary" @click="addInfo"><i
                     class="bi bi-plus-circle"></i> Tambah Label</button>
            </div>

            <div class="d-flex justify-content-end">
               <button type="submit" class="btn btn-custom-accent btn-md" :disabled="isLoading">
                  <span v-if="isLoading" class="spinner-border spinner-border-sm" role="status"
                     aria-hidden="true"></span>
                  <span v-else>Simpan Produk</span>
               </button>
            </div>
            <div v-if="error" class="alert alert-danger mt-3">{{ error }}</div>
         </form>
      </div>
      </div>
   </div>
</template>

<style scoped>
.dashboard-page-wrapper {
   width: 100%;
   min-height: 100vh;
   padding-top: 2rem;
   padding-bottom: 4rem;
}

.page-header {
   text-align: center;
   margin-bottom: 3rem;
}

.page-title {
   font-size: 2rem;
   font-weight: 800;
   background: var(--gradient-primary);
   -webkit-background-clip: text;
   -webkit-text-fill-color: transparent;
   background-clip: text;
   margin-bottom: 0.5rem;
}

.content-card-modern {
   background: var(--app-card-bg);
   border: 1px solid var(--app-border-color);
   border-radius: 16px;
}
</style>

<script setup lang="ts">
import { ref, reactive, watch, onMounted } from 'vue'
import Swal from 'sweetalert2'

interface Tag { _id: string; name: string }
interface AdditionalInfo { name: string }
interface ProductFormData { name: string; description: string; price: number | null; original_price: number | null; tag_id: string; image: File | null; additional_information: AdditionalInfo[]; file: File | string | null; stock: number; is_featured: boolean }

const productData = reactive<ProductFormData>({ name: '', description: '', price: null, original_price: null, tag_id: '', image: null, additional_information: [], file: null, stock: -1, is_featured: false })
const previewFiles = ref<File[]>([])
const previewUrls = ref<string[]>([])
const previewInput = ref<HTMLInputElement | null>(null)

const allTags = ref<Tag[]>([])
const isStockUnlimited = ref(true)
const fileSourceType = ref('upload')
const uploadDestination = ref('local')
const productFileInput = ref<HTMLInputElement | null>(null)
const isLoading = ref(false)
const error = ref<string>('')
const imagePreviewUrl = ref<string | null>(null)
const fileInput = ref<HTMLInputElement | null>(null)
const descriptionTextarea = ref<HTMLTextAreaElement | null>(null)
const { $api }: any = useNuxtApp()

watch(isStockUnlimited, (newValue) => {
   if (newValue) { productData.stock = -1 }
   else { productData.stock = 0 }
})

onMounted(async () => {
   try {
      const res = await $api('/api/v2/tags')
      if (res.status) {
         allTags.value = res.data
      }
   } catch (e) {
      Swal.fire({ icon: 'error', title: 'Gagal Memuat Tags', text: 'Tidak dapat mengambil daftar tag.' })
   }
})

const triggerPreviewInput = () => previewInput.value?.click()
const handlePreviewChange = (e: Event) => {
   const target = e.target as HTMLInputElement
   if (!target.files) return
   const remain = 6 - previewFiles.value.length
   Array.from(target.files).slice(0, remain).forEach(f => {
      previewFiles.value.push(f)
      previewUrls.value.push(URL.createObjectURL(f))
   })
   target.value = ''
}
const removePreview = (i: number) => {
   URL.revokeObjectURL(previewUrls.value[i])
   previewFiles.value.splice(i, 1)
   previewUrls.value.splice(i, 1)
}

const setFileSourceType = (type: 'upload' | 'url') => {
   fileSourceType.value = type
   productData.file = null
   removeProductFile()
}
const triggerProductFileInput = () => productFileInput.value?.click()
const handleProductFileChange = (event: Event) => {
   const target = event.target as HTMLInputElement
   const file = target.files?.[0] || null
   if (file) { productData.file = file }
}
const removeProductFile = () => {
   productData.file = null
   if (productFileInput.value) { productFileInput.value.value = '' }
}
const addInfo = () => productData.additional_information.push({ name: '' })
const removeInfo = (index: number) => productData.additional_information.splice(index, 1)
const triggerFileInput = () => fileInput.value?.click()
const processFile = (file: File | null) => {
   if (file && file.type.startsWith('image/')) {
      productData.image = file
      imagePreviewUrl.value = URL.createObjectURL(file)
   }
}
const handleFileChange = (event: Event) => processFile((event.target as HTMLInputElement).files?.[0] || null)
const handleFileDrop = (event: DragEvent) => processFile(event.dataTransfer?.files[0] || null)
const removeImage = () => {
   productData.image = null
   if (imagePreviewUrl.value) URL.revokeObjectURL(imagePreviewUrl.value)
   imagePreviewUrl.value = null
   if (fileInput.value) fileInput.value.value = ''
}
const formatText = (type: 'bold' | 'italic' | 'heading' | 'list') => {
   const textarea = descriptionTextarea.value
   if (!textarea) return
   const start = textarea.selectionStart
   const end = textarea.selectionEnd
   const selectedText = textarea.value.substring(start, end)
   let replacement = ''
   switch (type) {
      case 'bold': replacement = `**${selectedText}**`; break
      case 'italic': replacement = `*${selectedText}*`; break
      case 'heading':
         const startOfLine = textarea.value.lastIndexOf('\n', start - 1) + 1
         const lineText = textarea.value.substring(startOfLine, end)
         replacement = `## ${lineText}`
         textarea.setSelectionRange(startOfLine, end)
         break
      case 'list':
         const lines = selectedText.split('\n')
         replacement = lines.map(line => `- ${line}`).join('\n')
         break
   }
   textarea.setRangeText(replacement, textarea.selectionStart, textarea.selectionEnd, 'end')
   productData.description = textarea.value
   textarea.focus()
}

const handleSubmit = async () => {
   isLoading.value = true
   error.value = ''

   if (!productData.name || !productData.price || !productData.image) {
      error.value = "Nama, harga, dan gambar produk wajib diisi."
      isLoading.value = false
      return
   }
   const formData = new FormData()
   formData.append('name', productData.name)
   formData.append('description', productData.description)
   formData.append('price', String(productData.price))
   if (productData.original_price) formData.append('original_price', String(productData.original_price))
   if (productData.tag_id) formData.append('tag_id', productData.tag_id)
   formData.append('image', productData.image)

   previewFiles.value.forEach(f => {
      formData.append('previews', f)
   })

   formData.append('type', 'add')
   formData.append('is_featured', String(productData.is_featured))
   formData.append('stock', String(productData.stock))
   const validInfo = productData.additional_information.filter(info => info.name.trim())
   if (validInfo.length > 0) { formData.append('additional_information', JSON.stringify(validInfo)) }

   if (productData.file) {
      if (fileSourceType.value === 'upload' && typeof productData.file === 'object') {
         formData.append('file', productData.file)
         formData.append('file_upload_destination', uploadDestination.value)
      }
      else if (fileSourceType.value === 'url' && typeof productData.file === 'string') {
         formData.append('file_url', productData.file)
      }
   }

   try {
      const response = await $api('/api/v2/product', { method: 'POST', body: formData })
      if (!response.status) throw new Error(response.msg)

      await Swal.fire({ icon: 'success', title: 'Berhasil!', text: 'Produk telah ditambahkan.', timer: 2000, showConfirmButton: false })
      // location.reload()
   } catch (e: any) {
      error.value = e.data?.msg || "Gagal menambahkan produk."
      Swal.fire({ icon: 'error', title: 'Gagal', text: error.value })
   } finally {
      isLoading.value = false
   }
}
</script>
<template>
   <div class="dashboard-page-wrapper">
      <div class="container">
         <div class="page-header mb-4">
            <h1 class="page-title">Manajemen Produk</h1>
         </div>
      </div>
      
      <div class="container">
      <div class="content-card-modern">
         <div class="card-header">
            <h5 class="fw-bold mb-0">Daftar Produk</h5>
            <div class="d-flex align-items-center gap-2">
               <NuxtLink to="/dashboard/add" class="btn btn-sm btn-custom-accent">
                  <i class="bi bi-plus-lg me-1"></i> Tambah Baru
               </NuxtLink>
            </div>
         </div>

         <div class="card-body position-relative">
            <div v-if="isLoading && !products.length" class="text-center py-5">
               <div class="spinner-border product-loader-spinner" role="status"></div>
               <p class="mt-3">Memuat produk...</p>
            </div>
            <div v-else-if="error" class="alert alert-danger">{{ error }}</div>
            <div v-else>
               <div class="table-responsive">
                  <table class="table app-table align-middle">
                     <thead>
                        <tr>
                           <th class="text-center"></th>
                           <th scope="col">ID</th>
                           <th scope="col">Nama Produk</th>
                           <th scope="col">Harga</th>
                           <th scope="col" class="text-center">Terjual</th>
                           <th scope="col" class="text-center">Stok</th>
                           <th scope="col" class="text-center">Aksi</th>
                        </tr>
                     </thead>
                     <tbody ref="tbodyRef">
                        <tr v-for="(product, index) in products" :key="product._id"
                           :class="{ 'is-dragging': isDragging && draggedIndex === index }" class="draggable-row">
                           <td>
                              <i class="bi bi-grip-vertical drag-handle" @mousedown="onDragStart($event, index)"
                                 @touchstart.prevent="onDragStart($event, index)"></i>
                           </td>
                           <td>{{ product._id }}</td>
                           <td>
                              <div class="text-truncate" style="max-width: 250px;">{{ product.name }}</div>
                           </td>
                           <td>{{ formatCurrency(product.price) }}</td>
                           <td class="text-center">{{ product.sales || 0 }}x</td>
                           <td class="text-center">
                              <span v-if="product.stock === -1"
                                 class="status-badge text-bg-success-outline">Unlimited</span>
                              <span v-else-if="product.stock === 0" class="status-badge text-bg-danger-outline">{{
                                 product.stock }}</span>
                              <span v-else-if="product.stock > 0 && product.stock <= 10"
                                 class="status-badge text-bg-warning-outline">{{ product.stock }}</span>
                              <span v-else>{{ product.stock }}</span>
                           </td>
                           <td>
                              <div class="d-flex justify-content-center gap-1">
                                 <button class="btn btn-sm btn-action-default" title="Lihat"
                                    @click="actions.view(product._id)"><i class="bi bi-eye-fill"></i></button>
                                 <button class="btn btn-sm btn-action-default" title="Edit"
                                    @click="actions.edit(product._id)"><i class="bi bi-pencil-fill"></i></button>
                                 <button class="btn btn-sm btn-action-default" title="Hapus"
                                    @click="actions.delete(product._id, product.name)"><i
                                       class="bi bi-trash-fill"></i></button>
                              </div>
                           </td>
                        </tr>
                        <tr v-if="products.length === 0 && !isLoading">
                           <td :colspan="7" class="text-center text-secondary py-4">
                              Tidak ada produk yang ditemukan.
                           </td>
                        </tr>
                     </tbody>
                  </table>
               </div>
               <div v-if="isFetchingMore" class="text-center py-3">
                  <div class="spinner-border spinner-border-sm me-1"></div> Memuat lebih banyak...
               </div>
               <div v-if="!error && !hasMoreProducts && products.length > 0 && !isLoading"
                  class="text-center text-secondary py-3">
                  Semua produk telah ditampilkan.
               </div>
               <div v-if="!error" class="card-footer">
                  <div class="search-container">
                     <i class="bi bi-search search-icon"></i>
                     <input type="search" v-model="searchQuery" class="form-control search-input"
                        placeholder="Cari produk..." :disabled="isLoading || isFetchingMore">
                  </div>
               </div>
            </div>

            <div v-if="isSavingOrder" class="table-overlay">
               <div class="spinner-border" role="status" style="color: var(--app-accent-color)">
                  <span class="visually-hidden">Loading...</span>
               </div>
               <p class="ms-3 mb-0 fw-bold" style="color: var(--app-text-color)">Menyimpan urutan...</p>
            </div>

         </div>
      </div>
      </div>
   </div>
</template>

<style scoped>
.dashboard-page-wrapper {
   width: 100%;
   min-height: 100vh;
   padding-top: 2rem;
   padding-bottom: 4rem;
}

.page-header {
   text-align: left;
   margin-bottom: 2rem;
}

.page-title {
   font-size: 1.875rem;
   font-weight: 800;
   background: var(--gradient-primary);
   -webkit-background-clip: text;
   -webkit-text-fill-color: transparent;
   background-clip: text;
   margin-bottom: 0.25rem;
}

.content-card-modern {
   background: var(--app-card-bg);
   border: 1px solid var(--app-border-color);
   border-radius: 16px;
}
</style>

<script setup lang="ts">
import { ref, onMounted, onUnmounted, computed, watch } from 'vue'
import { useRouter } from 'vue-router'
import Swal from 'sweetalert2'

const { $api }: any = useNuxtApp()
useHead({ title: 'Daftar Produk' })

interface Product { _id: string; name: string; price: number; sales: number; stock: number; order: number }

const products = ref<Product[]>([])
const totalProducts = ref(0)
const isLoading = ref(true)
const isFetchingMore = ref(false)
const isSavingOrder = ref(false)
const error = ref<string | null>(null)
const router = useRouter()
const searchQuery = ref('')
const currentPage = ref(1)
const itemsPerPage = ref(10)

const tbodyRef = ref<HTMLTableSectionElement | null>(null)
const draggedIndex = ref<number | null>(null)
const isDragging = ref(false)

const hasMoreProducts = computed(() => products.value.length < totalProducts.value)

const onDragStart = (event: MouseEvent | TouchEvent, index: number) => {
   if (event.type === 'mousedown') {
      (event as MouseEvent).preventDefault()
   }

   draggedIndex.value = index
   isDragging.value = true

   window.addEventListener('mousemove', onDragMove)
   window.addEventListener('touchmove', onDragMove, { passive: false })
   window.addEventListener('mouseup', onDragEnd)
   window.addEventListener('touchend', onDragEnd)
}

const onDragMove = (event: MouseEvent | TouchEvent) => {
   if (!isDragging.value || draggedIndex.value === null) return

   if (event.type === 'touchmove') {
      event.preventDefault()
   }

   const clientY = 'touches' in event ? event.touches[0].clientY : event.clientY
   const rows = Array.from(tbodyRef.value?.querySelectorAll('tr.draggable-row') || [])

   for (const [index, row] of rows.entries()) {
      const rect = row.getBoundingClientRect()
      if (clientY > rect.top && clientY < rect.bottom) {
         if (index !== draggedIndex.value) {
            const draggedItem = products.value.splice(draggedIndex.value, 1)[0]
            products.value.splice(index, 0, draggedItem)
            draggedIndex.value = index
         }
         break
      }
   }
}

const onDragEnd = () => {
   if (!isDragging.value) return

   window.removeEventListener('mousemove', onDragMove)
   window.removeEventListener('touchmove', onDragMove)
   window.removeEventListener('mouseup', onDragEnd)
   window.removeEventListener('touchend', onDragEnd)

   handleOrderUpdate()

   isDragging.value = false
   draggedIndex.value = null
}

const handleOrderUpdate = async () => {
   isSavingOrder.value = true
   try {
      const orderedIds = products.value.map(p => p._id)
      const response = await $api('/api/v2/products/order', {
         method: 'PUT',
         body: { orderedIds }
      })
      if (!response.status) { throw new Error(response.msg) }
      return
   } catch (e: any) {
      Swal.fire('Gagal Menyimpan Urutan', e.data.msg, 'error')
      fetchProducts(false)
   } finally {
      isSavingOrder.value = false
   }
}

const fetchProducts = async (append = false) => {
   if (!append) {
      if (isLoading.value && products.value.length > 0) return
      isLoading.value = true
      products.value = []
      currentPage.value = 1
   } else {
      if (isFetchingMore.value) return
      isFetchingMore.value = true
      currentPage.value++
   }

   error.value = null
   try {
      const params = new URLSearchParams({ page: currentPage.value.toString(), limit: itemsPerPage.value.toString(), search: searchQuery.value })
      const response = await $api(`/api/v2/products?${params.toString()}`)
      if (response && response.status && response.data) {
         if (append) {
            products.value = [...products.value, ...response.data.products]
         } else {
            products.value = response.data.products
         }
         totalProducts.value = response.data.total
      } else {
         throw new Error(response.msg || 'Gagal memuat data')
      }
   } catch (e: any) {
      error.value = e.message
      if (append) {
         currentPage.value--
      }
   } finally {
      isLoading.value = false
      isFetchingMore.value = false
   }
}

const handleScroll = () => {
   const { scrollTop, clientHeight, scrollHeight } = document.documentElement
   if (scrollTop + clientHeight >= scrollHeight - 200 && hasMoreProducts.value && !isFetchingMore.value && !isLoading.value) {
      fetchProducts(true)
   }
}

let searchTimeout: NodeJS.Timeout
watch(searchQuery, () => {
   clearTimeout(searchTimeout)
   searchTimeout = setTimeout(() => {
      currentPage.value = 1
      fetchProducts(false)
   }, 300)
})

const actions = {
   view: (id: string | number) => router.push(`/product/${id}`),
   edit: (id: string | number) => router.push(`/dashboard/product/${id}`),
   delete: (id: string | number, name: string) => {
      Swal.fire({
         title: 'Anda Yakin?',
         text: `Produk "${name}" akan dihapus secara permanen!`,
         icon: 'warning',
         showCancelButton: true,
         confirmButtonColor: '#d33',
         cancelButtonColor: '#3085d6',
         confirmButtonText: 'Ya, hapus!',
         cancelButtonText: 'Batal'
      }).then(async (result) => {
         if (result.isConfirmed) {
            try {
               const response = await $api(`/api/v2/product/${id}`, { method: 'DELETE' })
               if (!response.status) { throw new Error(response.msg) }
               Swal.fire('Dihapus!', 'Produk telah berhasil dihapus.', 'success')
               fetchProducts(false)
            } catch (e: any) {
               Swal.fire('Gagal!', e.message, 'error')
            }
         }
      })
   }
}

const formatCurrency = (value: number) => {
   if (typeof value !== 'number') return 'Rp 0'
   return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(value)
}

onMounted(() => {
   fetchProducts(false)
   window.addEventListener('scroll', handleScroll)
})

onUnmounted(() => {
   window.removeEventListener('scroll', handleScroll)
})
</script>

<style scoped>
.drag-handle {
   cursor: grab;
   color: var(--app-secondary-text-color);
}

.draggable-row.is-dragging {
   background-color: var(--app-accent-color);
   color: var(--app-accent-text-color);
}

.draggable-row.is-dragging .drag-handle {
   cursor: grabbing;
}
</style>
<template>
   <div class="reviews-page">
      <div class="container px-3 py-4">

         <div class="d-flex align-items-center mb-4 gap-3">
            <NuxtLink to="/dashboard" class="btn-icon bg-glass">
               <i class="bi bi-arrow-left"></i>
            </NuxtLink>
            <h3 class="fw-bold mb-0">Ulasan Produk</h3>
         </div>

         <div v-if="isLoading" class="loading-container">
            <div class="spinner-border text-primary" role="status">
               <span class="visually-hidden">Loading...</span>
            </div>
         </div>

         <div v-else class="glass-card p-4 animate-slide-up">
            <div v-if="purchasedProducts.length === 0" class="text-center py-5">
               <i class="bi bi-box-seam display-1 text-secondary opacity-50 mb-3"></i>
               <h5>Anda belum memiliki produk</h5>
               <p class="text-secondary">Beli produk untuk memberikan ulasan pertama Anda.</p>
               <NuxtLink to="/products" class="btn btn-primary mt-2">Telusuri Produk</NuxtLink>
            </div>

            <div v-else class="row g-4">
               <div v-for="product in purchasedProducts" :key="product.id" class="col-md-6 col-lg-4">
                  <div class="review-item-card p-4 h-100 d-flex flex-column">
                     <div class="d-flex align-items-start gap-3 mb-3">
                        <div
                           class="product-icon bg-primary bg-opacity-10 text-primary rounded-circle d-flex align-items-center justify-content-center"
                           style="width: 48px; height: 48px; min-width: 48px;">
                           <i class="bi bi-bag-check-fill fs-4"></i>
                        </div>
                        <div>
                           <h6 class="fw-bold mb-1">{{ product.name }}</h6>
                           <small class="text-secondary">Dibeli pada: {{ formatDate(product.purchaseDate) }}</small>
                        </div>
                     </div>

                     <div class="mt-auto">
                        <button class="btn btn-outline-primary w-100" @click="openReviewModal(product)">
                           <i class="bi bi-star-fill me-2"></i>Beri Ulasan
                        </button>
                     </div>
                  </div>
               </div>
            </div>
         </div>

      </div>

      <!-- Review Modal -->
      <div class="modal fade" id="reviewModal" tabindex="-1" aria-hidden="true" ref="modalRef">
         <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content premium-modal">
               <div class="modal-header border-bottom-0 pb-0">
                  <h5 class="modal-title fw-bold">Beri Ulasan</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
               </div>
               <div class="modal-body">
                  <p class="text-secondary mb-4">Bagaimana pendapat Anda tentang <strong>{{ selectedProduct?.name
                        }}</strong>?</p>

                  <form @submit.prevent="submitReview">
                     <div class="mb-4 text-center">
                        <div class="star-rating d-inline-flex flex-row-reverse justify-content-center">
                           <!-- CSS trick for rating -->
                           <input type="radio" id="star5" name="rating" value="5" v-model="form.rating"
                              class="d-none" />
                           <label for="star5" title="5 bintang"><i class="bi bi-star-fill"></i></label>

                           <input type="radio" id="star4" name="rating" value="4" v-model="form.rating"
                              class="d-none" />
                           <label for="star4" title="4 bintang"><i class="bi bi-star-fill"></i></label>

                           <input type="radio" id="star3" name="rating" value="3" v-model="form.rating"
                              class="d-none" />
                           <label for="star3" title="3 bintang"><i class="bi bi-star-fill"></i></label>

                           <input type="radio" id="star2" name="rating" value="2" v-model="form.rating"
                              class="d-none" />
                           <label for="star2" title="2 bintang"><i class="bi bi-star-fill"></i></label>

                           <input type="radio" id="star1" name="rating" value="1" v-model="form.rating" class="d-none"
                              required />
                           <label for="star1" title="1 bintang"><i class="bi bi-star-fill"></i></label>
                        </div>
                     </div>

                     <div class="mb-3">
                        <label class="form-label text-secondary small">Komentar (Opsional)</label>
                        <textarea class="form-control" v-model="form.comment" rows="3"
                           placeholder="Ceritakan pengalaman Anda..."></textarea>
                     </div>

                     <button type="submit" class="btn btn-primary w-100 mt-2" :disabled="isSubmitting || !form.rating">
                        <span v-if="isSubmitting" class="spinner-border spinner-border-sm me-2"></span>
                        Kirim Ulasan
                     </button>
                  </form>
               </div>
            </div>
         </div>
      </div>

   </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted } from 'vue'
import { Modal } from 'bootstrap'
import Swal from 'sweetalert2'

useHead({ title: 'Ulasan Produk' })
const { $api } = useNuxtApp()

const isLoading = ref(true)
const isSubmitting = ref(false)
const purchasedProducts = ref<any[]>([])
const selectedProduct = ref<any>(null)
const modalRef = ref(null)
let bsModal: Modal | null = null

const form = ref({
   rating: '',
   comment: ''
})

const formatDate = (dateString: string) => {
   if (!dateString) return '-'
   return new Date(dateString).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })
}

const fetchProducts = async () => {
   isLoading.value = true
   try {
      const res = await $api('/api/v1/statistic')
      if (res.status && res.data) {
         // Deduplicate products based on original ID. ID format in dashboard is `${invoiceId}-${name}`.
         // Wait, the action review needs `productId`. The statistic only provides names. 
         // Let's modify purchasedProducts mapping to include real item id if possible. 
         // Since v1-statistic might not hold the real ID, we'll try to get it.
         // Note: in previous file v1-statistic.js we didn't populate item.id correctly, let's fix it later. For now, try.
         purchasedProducts.value = res.data.purchasedProducts || []
      }
   } catch (e: any) {
      console.error(e)
   } finally {
      isLoading.value = false
   }
}

const openReviewModal = (product: any) => {
   selectedProduct.value = product
   form.value = { rating: '', comment: '' }
   bsModal?.show()
}

const submitReview = async () => {
   if (!form.value.rating) return
   isSubmitting.value = true
   try {
      // Find real product ID. If product.id is 'inv-name', just send product.id and backend will handle it,
      // but backend expects real productId. So we extract real productId.
      // Wait, in v1-statistic we set id: `${tx._id}-${productName}`, which is bad for this.
      // I will fix v1-statistic.js later if needed. For now sending product.realId
      const targetId = selectedProduct.value.realId || selectedProduct.value.id

      const res = await $api('/api/v1/review', {
         method: 'POST',
         body: {
            productId: targetId,
            rating: form.value.rating,
            comment: form.value.comment
         }
      })
      if (res.status) {
         Swal.fire({ icon: 'success', title: 'Berhasil', text: 'Ulasan Anda telah dikirim', timer: 2000, showConfirmButton: false })
         bsModal?.hide()
      } else {
         throw new Error(res.msg)
      }
   } catch (e: any) {
      Swal.fire({ icon: 'error', title: 'Ups...', text: e.data?.msg || e.message || 'Terjadi kesalahan' })
   } finally {
      isSubmitting.value = false
   }
}

onMounted(() => {
   fetchProducts()
   if (modalRef.value) {
      bsModal = new Modal(modalRef.value)
   }
})

onUnmounted(() => {
   bsModal?.dispose()
})
</script>

<style scoped>
.reviews-page {
   padding-bottom: 2rem;
}

.btn-icon {
   width: 40px;
   height: 40px;
   display: inline-flex;
   align-items: center;
   justify-content: center;
   border-radius: 50%;
   color: var(--app-text-color);
   transition: all 0.3s;
   text-decoration: none;
}

.bg-glass {
   background: var(--app-surface);
   border: 1px solid var(--app-border-color);
}

.glass-card {
   border-radius: 20px;
}

.review-item-card {
   background: var(--app-surface);
   border: 1px solid var(--app-border-color);
   border-radius: 14px;
   transition: transform 0.2s, box-shadow 0.2s;
}

.review-item-card:hover {
   transform: translateY(-2px);
   box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
}

/* Star Rating CSS Trick */
.star-rating label {
   font-size: 2rem;
   color: #e4e5e9;
   cursor: pointer;
   padding: 0 0.1rem;
   transition: color 0.2s;
}

.star-rating label:hover,
.star-rating label:hover~label,
.star-rating input:checked~label {
   color: #ffc107;
}

.premium-modal .modal-content {
   background: var(--app-bg);
   border: 1px solid var(--app-border-color);
   border-radius: 16px;
}
</style>

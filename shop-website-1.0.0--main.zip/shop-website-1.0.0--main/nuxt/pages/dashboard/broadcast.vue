<template>
    <div class="dashboard-page-wrapper">
        <div class="container py-4">
            <div class="d-flex justify-content-between align-items-center mb-4 animate-slide-up">
                <h3 class="fw-bold mb-0 text-white"><i class="bi bi-megaphone-fill me-2 text-warning"></i>Kirim
                    Broadcast</h3>
                <button @click="$router.push('/dashboard')" class="btn-outline-premium btn-sm"><i
                        class="bi bi-arrow-left me-1"></i>Kembali</button>
            </div>

            <div class="premium-glass-card p-4 p-md-5 mx-auto animate-slide-up"
                style="max-width: 800px; animation-delay: 0.1s;">
                <h5 class="fw-bold text-gradient mb-4">Informasikan Pengguna Anda</h5>

                <form @submit.prevent="sendBroadcast">
                    <div class="mb-4">
                        <label class="form-label text-secondary small">Judul Pesan</label>
                        <input type="text" v-model="form.title" class="form-control premium-input"
                            placeholder="Masukkan judul..." required>
                    </div>

                    <div class="mb-4">
                        <label class="form-label text-secondary small">Kategori (Tag)</label>
                        <div class="premium-select-wrapper">
                            <select v-model="form.tag" class="form-select premium-select custom-select-arrow" required>
                                <option value="Info">ℹ️ Informasi Umum (Info)</option>
                                <option value="Penting">⚠️ Prioritas Tinggi (Penting)</option>
                                <option value="Diskon">🎁 Promosi & Kupon (Diskon)</option>
                                <option value="Maintenance">🔧 Perbaikan Sistem (Maintenance)</option>
                            </select>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label text-secondary small">Isi Pesan Broadcast</label>
                        <textarea v-model="form.message" class="form-control premium-input" rows="5"
                            placeholder="Tulis pesan lengkap di sini..." required></textarea>
                        <div class="form-text text-secondary mt-2"><i class="bi bi-info-circle me-1"></i>Pesan ini akan
                            dikirim ke Inbox seluruh pengguna yang terdaftar (non-admin).</div>
                    </div>

                    <div class="text-end">
                        <button type="submit" class="btn-explore" :disabled="isSending">
                            <span v-if="isSending" class="spinner-border spinner-border-sm me-2"></span>
                            <i v-else class="bi bi-send-fill me-2"></i> {{ isSending ? 'Mengirim...' : 'Kirim Sekarang'
                            }}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>

<script setup>
import { ref } from 'vue'
import Swal from 'sweetalert2'

useHead({ title: 'Broadcast Admin' })
const { $api } = useNuxtApp()
const isSending = ref(false)

const form = ref({
    title: '',
    tag: 'Info',
    message: ''
})

const sendBroadcast = async () => {
    if (!form.value.title || !form.value.message) {
        return Swal.fire('Oops!', 'Semua kolom harus diisi.', 'warning')
    }

    const res = await Swal.fire({
        title: 'Kirim Broadcast?',
        text: "Pesan akan masuk ke seluruh pengguna, tidak dapat ditarik kembali.",
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#10B981',
        cancelButtonColor: '#EF4444',
        confirmButtonText: '<i class="bi bi-send me-1"></i> Kirim!'
    })

    if (res.isConfirmed) {
        try {
            isSending.value = true
            const resp = await $api('/api/v2/broadcast', { method: 'POST', body: form.value })
            if (resp.status) {
                Swal.fire('Berhasil!', resp.msg, 'success')
                form.value = { title: '', tag: 'Info', message: '' }
            } else {
                throw new Error(resp.msg)
            }
        } catch (err) {
            Swal.fire('Gagal!', err.message || err.data?.msg, 'error')
        } finally {
            isSending.value = false
        }
    }
}
</script>

<style scoped>
.dashboard-page-wrapper {
    min-height: 100vh;
    width: 100%;
}

.premium-glass-card {
    background: var(--app-card-bg);
    border: 1px solid var(--app-border-color);
    border-radius: 20px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
}

.premium-input,
.premium-select {
    background: rgba(0, 0, 0, 0.2) !important;
    border: 1px solid rgba(255, 255, 255, 0.1) !important;
    color: var(--app-text-color) !important;
    border-radius: 10px;
}

.premium-input:focus,
.premium-select:focus {
    border-color: var(--primary-color) !important;
    box-shadow: 0 0 0 0.25rem rgba(139, 92, 246, 0.25) !important;
}

body.light-mode .premium-input,
body.light-mode .premium-select {
    background: #fff !important;
    border: 1px solid #ced4da !important;
}

.text-gradient {
    background: var(--gradient-primary);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}
</style>

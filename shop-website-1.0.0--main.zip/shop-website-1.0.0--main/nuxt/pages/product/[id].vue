<template>
   <div class="product-detail-page d-flex flex-column min-vh-100">
      <div v-if="isLoading" class="d-flex flex-column justify-content-center align-items-center min-vh-100">
         <div class="spinner-grow text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="visually-hidden">Loading...</span>
         </div>
         <p class="mt-3 text-secondary tracking-wider fs-5">Menyiapkan Informasi Produk...</p>
      </div>

      <div v-else-if="error" class="container py-5">
         <div class="alert alert-glass-danger border-0 d-flex flex-column align-items-center text-center py-5">
            <i class="bi bi-exclamation-triangle-fill display-1 mb-3"></i>
            <h2 class="fw-bold mb-2">Terjadi Kesalahan</h2>
            <p class="lead mb-4">{{ error }}</p>
            <button @click="$router.push('/products')" class="btn-premium px-4 py-2 rounded-pill d-inline-flex gap-2">
               <i class="bi bi-arrow-left"></i> Kembali ke Katalog
            </button>
         </div>
      </div>

      <div v-else-if="product" class="flex-grow-1">
         <!-- Hero Background Blur -->
         <div class="product-hero-blur">
            <div class="blur-img"
               :style="{ backgroundImage: `url(${product.imageUrl || 'https://via.placeholder.com/800'})` }"></div>
            <div class="blur-overlay"></div>
         </div>

         <div class="container position-relative z-1" style="padding-top: 2rem; padding-bottom: 5rem;">
            <!-- Breadcrumbs -->
            <nav aria-label="breadcrumb" class="mb-4 d-none d-md-block">
               <ol class="breadcrumb glass-breadcrumb px-4 py-2 rounded-pill d-inline-flex">
                  <li class="breadcrumb-item">
                     <NuxtLink to="/">Beranda</NuxtLink>
                  </li>
                  <li class="breadcrumb-item">
                     <NuxtLink to="/products">Produk</NuxtLink>
                  </li>
                  <li class="breadcrumb-item active" aria-current="page">{{ product.name.substring(0, 20)
                  }}...</li>
               </ol>
            </nav>

            <div class="row g-4 g-lg-5">
               <!-- Left Column: Media & Content -->
               <div class="col-lg-8 animate-slide-up">

                  <!-- Main Image Card -->
                  <div class="glass-panel main-media-panel mb-5 overflow-hidden position-relative">
                     <div class="main-image-wrapper p-2 p-md-4" @click="openLightbox(product.imageUrl || '')">
                        <img :src="product.imageUrl || 'https://via.placeholder.com/1200x800.png?text=Premium+Design'"
                           :alt="product.name"
                           class="img-fluid w-100 object-fit-cover rounded-4 shadow-lg cursor-pointer hero-product-img"
                           @contextmenu.prevent>

                        <div class="media-hover-hint">
                           <i class="bi bi-arrows-fullscreen fs-3"></i>
                           <span>Perbesar Gambar</span>
                        </div>
                     </div>
                  </div>

                  <!-- Details Panel -->
                  <div class="glass-panel content-panel p-4 p-md-5 mb-5">
                     <div class="d-flex align-items-center gap-3 mb-4 flex-wrap">
                        <span class="badge-glow-primary px-3 py-2"><i class="bi bi-shield-check me-1"></i> Original By
                           Yilzi</span>
                        <span v-if="product.tag" class="badge-glass px-3 py-2 text-white">{{ product.tag.name }}</span>
                     </div>

                     <h1 class="display-5 fw-black mb-4">{{ product.name }}</h1>

                     <div class="description-content custom-scrollbar pe-md-3 mb-5" v-html="renderedDescription"></div>

                     <!-- Premium Bento Gallery -->
                     <div v-if="product.preview_images && product.preview_images.length > 0">
                        <h4 class="fw-bold mb-4 d-flex align-items-center gap-2">
                           <i class="bi bi-grid-1x2 text-primary"></i> Galeri Tangkapan Layar
                        </h4>
                        <div :class="['premium-bento-grid', `layout-${Math.min(product.preview_images.length, 5)}`]">
                           <div v-for="(img, index) in product.preview_images.slice(0, 5)" :key="index"
                              class="bento-item shadow-hover" @click="openLightbox(img)">
                              <img :src="img" class="bento-img" @contextmenu.prevent>

                              <div class="bento-overlay">
                                 <div class="zoom-circle">
                                    <i class="bi bi-arrows-fullscreen"></i>
                                 </div>
                              </div>

                              <div v-if="index === 4 && product.preview_images.length > 5"
                                 class="more-count-overlay d-flex flex-column align-items-center justify-content-center">
                                 <span class="fs-1 fw-bold">+{{ product.preview_images.length - 5 }}</span>
                                 <span class="small tracking-widest text-uppercase fw-semibold">Eksplor Galeri</span>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>

                  <!-- Reviews Panel -->
                  <div class="glass-panel content-panel p-4 p-md-5 mb-5 mt-4">
                     <div class="d-flex align-items-center justify-content-between mb-4">
                        <h4 class="fw-bold mb-0 d-flex align-items-center gap-2">
                           <i class="bi bi-star-half text-warning"></i> Ulasan Pembeli
                        </h4>
                        <div v-if="reviews.length > 0" class="d-flex align-items-center gap-2">
                           <span class="fs-4 fw-bold">{{ averageRating }}</span>
                           <div class="text-warning fs-5">
                              <i class="bi bi-star-fill"></i>
                           </div>
                           <span class="text-secondary ms-1">({{ reviews.length }} ulasan)</span>
                        </div>
                     </div>

                     <div v-if="reviews.length === 0" class="text-center py-4 bg-glass-light rounded-4">
                        <i class="bi bi-chat-square-stars display-4 text-secondary opacity-50 mb-3"></i>
                        <h6 class="text-secondary">Belum ada ulasan untuk produk ini.</h6>
                     </div>

                     <div v-else class="reviews-list">
                        <div v-for="review in reviews" :key="review._id"
                           class="review-item mb-4 pb-4 border-bottom border-light">
                           <div class="d-flex align-items-start gap-3">
                              <div
                                 class="user-avatar bg-primary bg-opacity-10 text-primary fw-bold rounded-circle d-flex align-items-center justify-content-center"
                                 style="width: 48px; height: 48px; min-width: 48px; font-size: 1.2rem;">
                                 {{ review.userName.charAt(0).toUpperCase() }}
                              </div>
                              <div class="flex-grow-1">
                                 <div class="d-flex justify-content-between align-items-center mb-1">
                                    <h6 class="fw-bold mb-0">{{ review.userName }}</h6>
                                    <small class="text-secondary">{{ new
                                       Date(review.created_at).toLocaleDateString('id-ID', {
                                          day: 'numeric', month:
                                       'short', year: 'numeric'}) }}</small>
                                 </div>
                                 <div class="text-warning small mb-2">
                                    <i v-for="i in 5" :key="i" class="bi"
                                       :class="i <= review.rating ? 'bi-star-fill' : 'bi-star'"></i>
                                 </div>
                                 <p class="mb-0 text-secondary" style="font-size: 0.95rem;">{{ review.comment ||
                                    'Pemberi ulasan tidak meninggalkan komentar.' }}</p>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>

               <!-- Right Column: Sidebar (Buy Card) -->
               <div class="col-lg-4 animate-slide-up" style="animation-delay: 0.2s">
                  <div class="sticky-sidebar">
                     <BuyCard :product="product" class="glass-buy-card shadow-lg" />

                     <div class="mt-4 px-3 text-center text-secondary small opacity-75">
                        <p class="mb-1"><i class="bi bi-lock-fill me-1"></i> Pembayaran Aman Terenkripsi</p>
                        <p class="mb-1"><i class="bi bi-lightning-charge-fill me-1"></i> Pengiriman Otomatis Instan</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>

         <!-- Lightbox -->
         <Transition name="fade">
            <div v-if="lightbox.isOpen" class="lightbox-hero" @click.self="closeLightbox">
               <button class="btn-close-lightbox" @click="closeLightbox">
                  <i class="bi bi-x-lg"></i>
               </button>

               <button v-if="hasMultipleImages" class="nav-btn prev" @click="prevImage">
                  <i class="bi bi-chevron-left"></i>
               </button>

               <div class="lightbox-content" @click.self="closeLightbox">
                  <img :src="lightbox.currentImage" class="img-lightbox rounded-4 shadow-xl" @contextmenu.prevent>
               </div>

               <button v-if="hasMultipleImages" class="nav-btn next" @click="nextImage">
                  <i class="bi bi-chevron-right"></i>
               </button>

               <div class="lightbox-counter badge rounded-pill bg-dark bg-opacity-75 px-3 py-2 fw-bold text-white fs-5">
                  {{ currentIndex + 1 }} <span class="text-white-50">/</span> {{ allImages.length }}
               </div>
            </div>
         </Transition>
      </div>
   </div>
   <Footer />
</template>

<script setup lang="ts">
import { ref, onMounted, computed, reactive, watch } from 'vue'
import { useRoute } from 'vue-router'
import MarkdownIt from 'markdown-it'

const { $api }: any = useNuxtApp()
const md = new MarkdownIt({ breaks: true })
const route = useRoute()
const id = route.params.id

const product = ref<any>(null)
const isLoading = ref(true)
const error = ref<string | null>(null)
const reviews = ref<any[]>([])

const averageRating = computed(() => {
   if (!reviews.value.length) return 0
   const sum = reviews.value.reduce((acc, r) => acc + r.rating, 0)
   return (sum / reviews.value.length).toFixed(1)
})

const lightbox = reactive({
   isOpen: false,
   currentImage: ''
})

const allImages = computed(() => {
   if (!product.value) return []
   const images = [product.value.imageUrl]
   if (product.value.preview_images) images.push(...product.value.preview_images)
   return images.filter(Boolean)
})

const currentIndex = computed(() => allImages.value.indexOf(lightbox.currentImage))
const hasMultipleImages = computed(() => allImages.value.length > 1)
const renderedDescription = computed(() => product.value?.description ? md.render(product.value.description) : '')

const openLightbox = (url: string) => {
   lightbox.currentImage = url
   lightbox.isOpen = true
   document.body.style.overflow = 'hidden'
}

const closeLightbox = () => {
   lightbox.isOpen = false
   document.body.style.overflow = ''
}

const nextImage = () => {
   const nextIdx = (currentIndex.value + 1) % allImages.value.length
   lightbox.currentImage = allImages.value[nextIdx]
}

const prevImage = () => {
   const prevIdx = (currentIndex.value - 1 + allImages.value.length) % allImages.value.length
   lightbox.currentImage = allImages.value[prevIdx]
}

onMounted(() => {
   window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') closeLightbox()
      if (lightbox.isOpen) {
         if (e.key === 'ArrowRight') nextImage()
         if (e.key === 'ArrowLeft') prevImage()
      }
   })
})

onMounted(async () => {
   try {
      const response = await $api(`/api/v1/products?id=${id}`)
      if (!response.status) throw new Error(response.msg)
      product.value = response.data

      try {
         const revRes = await $api(`/api/v1/reviews/${id}`)
         if (revRes.status && revRes.data) {
            reviews.value = revRes.data
         }
      } catch (e) {
         console.error('Gagal memuat ulasan:', e)
      }

      useHead({
         title: `${product.value.name} - Yilzi Shop`,
         meta: [
            { name: 'description', content: product.value.description.substring(0, 150) }
         ]
      })

   } catch (e: any) {
      error.value = e.message
   } finally {
      isLoading.value = false
   }
})
</script>

<style scoped>
.product-detail-page {
   width: 100%;
   flex-grow: 1;
   position: relative;
}

/* Helpers */
.fw-black {
   font-weight: 900;
}

.tracking-wider {
   letter-spacing: 0.1em;
}

.text-gradient {
   background: linear-gradient(135deg, #a78bfa, #60a5fa);
   -webkit-background-clip: text;
   -webkit-text-fill-color: transparent;
   background-clip: text;
}

/* Alert */
.alert-glass-danger {
   background: rgba(239, 68, 68, 0.1);
   backdrop-filter: blur(10px);
   color: #ef4444;
   border-radius: 24px;
}

/* Hero Blur Background */
.product-hero-blur {
   position: absolute;
   top: 0;
   left: 0;
   right: 0;
   height: 60vh;
   overflow: hidden;
   z-index: 0;
   pointer-events: none;
}

.blur-img {
   position: absolute;
   inset: -5%;
   background-size: cover;
   background-position: center;
   filter: blur(40px) saturate(2);
   opacity: 0.4;
   transform: scale(1.1);
}

.dark-mode .blur-img {
   opacity: 0.2;
}

.blur-overlay {
   position: absolute;
   inset: 0;
   background: linear-gradient(to bottom, transparent 0%, var(--app-bg) 100%);
}

.glass-breadcrumb {
   background: var(--app-surface-translucent);
   backdrop-filter: blur(12px);
   border: 1px solid var(--app-border-color);
}

.glass-breadcrumb a {
   color: var(--app-secondary-text-color);
   text-decoration: none;
   transition: color 0.3s;
}

.glass-breadcrumb a:hover,
.glass-breadcrumb .active {
   color: var(--app-text-color) !important;
}



.breadcrumb-item+.breadcrumb-item::before {
   color: #64748b;
}

/* Panels */
.glass-panel {
   background: var(--app-card-bg);
   border: 1px solid var(--app-border-color);
   border-radius: 24px;
   box-shadow: 0 20px 50px rgba(0, 0, 0, 0.05);
   backdrop-filter: blur(20px);
   -webkit-backdrop-filter: blur(20px);
}

.dark-mode .glass-panel {
   box-shadow: 0 20px 50px rgba(0, 0, 0, 0.3);
}

/* Main Image */
.main-media-panel {
   border-radius: 32px;
}

.hero-product-img {
   transition: transform 0.8s cubic-bezier(0.16, 1, 0.3, 1), filter 0.5s ease;
}

.main-image-wrapper:hover .hero-product-img {
   transform: scale(1.02);
   filter: brightness(1.1);
}

.media-hover-hint {
   position: absolute;
   inset: 0;
   background: rgba(0, 0, 0, 0.4);
   backdrop-filter: blur(4px);
   display: flex;
   flex-direction: column;
   align-items: center;
   justify-content: center;
   color: white;
   opacity: 0;
   transition: opacity 0.4s ease;
   border-radius: 32px;
   pointer-events: none;
}

.main-image-wrapper:hover .media-hover-hint {
   opacity: 1;
}

.media-hover-hint span {
   font-weight: 700;
   letter-spacing: 1px;
   margin-top: 0.5rem;
   text-transform: uppercase;
}

/* Content */
.badge-glow-primary {
   background: linear-gradient(135deg, #8b5cf6, #3b82f6);
   color: white;
   border-radius: 50px;
   font-size: 0.8rem;
   font-weight: 700;
   box-shadow: 0 4px 15px rgba(139, 92, 246, 0.4);
}

.badge-glass {
   background: rgba(139, 92, 246, 0.2);
   border: 1px solid rgba(139, 92, 246, 0.3);
   color: var(--primary-gradient-start);
   border-radius: 50px;
   font-size: 0.8rem;
   font-weight: 600;
}

:deep(.description-content h1),
:deep(.description-content h2),
:deep(.description-content h3) {
   color: var(--app-text-color);
   font-weight: 800;
   margin-top: 2rem;
   margin-bottom: 1rem;
}

:deep(.description-content p),
:deep(.description-content li) {
   color: var(--app-secondary-text-color);
   line-height: 1.8;
   font-size: 1.1rem;
}

:deep(.description-content a) {
   color: #8b5cf6;
   text-decoration: none;
   font-weight: 600;
}

:deep(.description-content a:hover) {
   text-decoration: underline;
}

:deep(.description-content blockquote) {
   border-left: 4px solid #8b5cf6;
   padding-left: 1rem;
   margin-left: 0;
   color: #94a3b8;
   font-style: italic;
   background: rgba(139, 92, 246, 0.05);
   padding: 1rem;
   border-radius: 0 12px 12px 0;
}

:deep(.description-content pre) {
   background: #1e1e24;
   color: #e2e8f0;
   padding: 1rem;
   border-radius: 12px;
   overflow-x: auto;
   border: 1px solid rgba(255, 255, 255, 0.1);
}

:deep(.description-content code) {
   font-family: monospace;
   color: #ec4899;
}

/* Superior Bento Gallery Layout */
.premium-bento-grid {
   display: grid;
   grid-template-columns: repeat(12, 1fr);
   grid-auto-rows: minmax(100px, auto);
   gap: 16px;
   margin-bottom: 2rem;
}

.bento-item {
   position: relative;
   overflow: hidden;
   border-radius: 20px;
   cursor: pointer;
   background: var(--app-surface);
   box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
   transform-style: preserve-3d;
   transition: all 0.5s cubic-bezier(0.2, 0.8, 0.2, 1);
}

.bento-item::after {
   content: '';
   position: absolute;
   inset: 0;
   border-radius: 20px;
   border: 1px solid rgba(255, 255, 255, 0.1);
   pointer-events: none;
   z-index: 2;
}

.bento-img {
   width: 100%;
   height: 100%;
   object-fit: cover;
   transform: scale(1.05);
   transition: transform 0.8s cubic-bezier(0.2, 0.8, 0.2, 1), filter 0.8s ease;
   filter: brightness(0.85);
}

.bento-item:hover {
   transform: translateY(-5px) scale(1.02);
   box-shadow: 0 20px 40px rgba(139, 92, 246, 0.2);
   z-index: 10;
}

.bento-item:hover .bento-img {
   transform: scale(1.1);
   filter: brightness(1.1);
}

.bento-overlay {
   position: absolute;
   inset: 0;
   opacity: 0;
   background: radial-gradient(circle at center, rgba(139, 92, 246, 0.1) 0%, rgba(0, 0, 0, 0.4) 100%);
   display: flex;
   align-items: center;
   justify-content: center;
   transition: opacity 0.5s ease;
   z-index: 1;
}

.zoom-circle {
   width: 60px;
   height: 60px;
   background: rgba(255, 255, 255, 0.1);
   backdrop-filter: blur(10px);
   border-radius: 50%;
   display: flex;
   align-items: center;
   justify-content: center;
   color: white;
   font-size: 1.5rem;
   transform: scale(0.5);
   opacity: 0;
   transition: all 0.5s cubic-bezier(0.2, 0.8, 0.2, 1);
}

.bento-item:hover .bento-overlay {
   opacity: 1;
}

.bento-item:hover .zoom-circle {
   transform: scale(1);
   opacity: 1;
   box-shadow: 0 0 20px rgba(139, 92, 246, 0.4);
}

.more-count-overlay {
   position: absolute;
   inset: 0;
   background: rgba(15, 23, 42, 0.85);
   backdrop-filter: blur(8px);
   color: white;
   z-index: 3;
}

/* Dynamic Layouts based on Image Count */
/* 1 Image */
.layout-1 .bento-item:nth-child(1) {
   grid-column: span 12;
   grid-row: span 3;
   height: 350px;
}

/* 2 Images */
.layout-2 .bento-item:nth-child(1) {
   grid-column: span 6;
   grid-row: span 3;
   height: 350px;
}

.layout-2 .bento-item:nth-child(2) {
   grid-column: span 6;
   grid-row: span 3;
   height: 350px;
}

/* 3 Images (Stunning Apple-style asymmetry) */
.layout-3 .bento-item:nth-child(1) {
   grid-column: span 8;
   grid-row: span 4;
   height: 420px;
}

.layout-3 .bento-item:nth-child(2) {
   grid-column: span 4;
   grid-row: span 2;
   height: 202px;
}

.layout-3 .bento-item:nth-child(3) {
   grid-column: span 4;
   grid-row: span 2;
   height: 202px;
}

/* 4 Images */
.layout-4 .bento-item:nth-child(1) {
   grid-column: span 12;
   grid-row: span 3;
   height: 300px;
}

.layout-4 .bento-item:nth-child(2) {
   grid-column: span 4;
   grid-row: span 2;
   height: 200px;
}

.layout-4 .bento-item:nth-child(3) {
   grid-column: span 4;
   grid-row: span 2;
   height: 200px;
}

.layout-4 .bento-item:nth-child(4) {
   grid-column: span 4;
   grid-row: span 2;
   height: 200px;
}

/* 5 Images (Bento Grid Masterpiece) */
.layout-5 .bento-item:nth-child(1) {
   grid-column: span 6;
   grid-row: span 4;
   height: 420px;
}

.layout-5 .bento-item:nth-child(2) {
   grid-column: span 3;
   grid-row: span 2;
   height: 202px;
}

.layout-5 .bento-item:nth-child(3) {
   grid-column: span 3;
   grid-row: span 2;
   height: 202px;
}

.layout-5 .bento-item:nth-child(4) {
   grid-column: span 3;
   grid-row: span 2;
   height: 202px;
}

.layout-5 .bento-item:nth-child(5) {
   grid-column: span 3;
   grid-row: span 2;
   height: 202px;
}

/* Sidebar */
.sticky-sidebar {
   position: sticky;
   top: 100px;
}

.glass-buy-card {
   border-radius: 24px;
   border: 1px solid var(--app-border-color);
   overflow: hidden;
}

/* Lightbox Premium 3D */
.lightbox-hero {
   position: fixed;
   inset: 0;
   z-index: 9999;
   background: rgba(15, 23, 42, 0.95);
   backdrop-filter: blur(20px);
   display: flex;
   align-items: center;
   justify-content: center;
}

.lightbox-content {
   max-width: 90vw;
   max-height: 90vh;
   display: flex;
   align-items: center;
   justify-content: center;
}

.img-lightbox {
   max-width: 100%;
   max-height: 85vh;
   object-fit: contain;
   box-shadow: 0 30px 100px rgba(0, 0, 0, 0.5);
   transition: transform 0.4s ease;
}

.btn-close-lightbox {
   position: absolute;
   top: 2rem;
   right: 2rem;
   width: 50px;
   height: 50px;
   border-radius: 50%;
   border: 1px solid rgba(255, 255, 255, 0.2);
   background: rgba(255, 255, 255, 0.1);
   color: white;
   font-size: 1.5rem;
   display: flex;
   align-items: center;
   justify-content: center;
   cursor: pointer;
   transition: all 0.3s ease;
}

.btn-close-lightbox:hover {
   background: white;
   color: black;
   transform: rotate(90deg);
}

.nav-btn {
   position: absolute;
   top: 50%;
   transform: translateY(-50%);
   width: 60px;
   height: 60px;
   border-radius: 50%;
   border: 1px solid rgba(255, 255, 255, 0.2);
   background: rgba(255, 255, 255, 0.1);
   color: white;
   font-size: 1.5rem;
   display: flex;
   align-items: center;
   justify-content: center;
   cursor: pointer;
   transition: all 0.3s ease;
}

.nav-btn:hover {
   background: white;
   color: black;
   scale: 1.1;
}

.nav-btn.prev {
   left: 2rem;
}

.nav-btn.next {
   right: 2rem;
}

.lightbox-counter {
   position: absolute;
   bottom: 2rem;
   left: 50%;
   transform: translateX(-50%);
}

.fade-enter-active,
.fade-leave-active {
   transition: opacity 0.4s ease, backdrop-filter 0.4s ease;
}

.fade-enter-from,
.fade-leave-to {
   opacity: 0;
   backdrop-filter: blur(0px);
}

/* Animation */
.animate-slide-up {
   animation: slideUp 0.8s cubic-bezier(0.16, 1, 0.3, 1) both;
}

@keyframes slideUp {
   0% {
      opacity: 0;
      transform: translateY(40px);
   }

   100% {
      opacity: 1;
      transform: translateY(0);
   }
}

@media (max-width: 768px) {
   .product-hero-blur {
      height: 40vh;
   }

   .premium-bento-grid {
      display: flex;
      flex-direction: column;
      gap: 12px;
   }

   .bento-item {
      height: auto !important;
      aspect-ratio: 16/9;
   }

   :deep(.description-content p),
   :deep(.description-content li) {
      font-size: 1rem;
   }

   .nav-btn {
      width: 44px;
      height: 44px;
   }

   .nav-btn.prev {
      left: 1rem;
   }

   .nav-btn.next {
      right: 1rem;
   }
}

.bg-glass-light {
   background: rgba(255, 255, 255, 0.05);
   border: 1px solid rgba(255, 255, 255, 0.1);
}

.border-light {
   border-color: var(--app-border-color) !important;
}

.review-item:last-child {
   border-bottom: none !important;
   margin-bottom: 0 !important;
   padding-bottom: 0 !important;
}
</style>
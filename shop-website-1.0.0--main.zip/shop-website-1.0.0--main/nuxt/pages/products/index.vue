<template>
   <div class="products-page d-flex flex-column min-vh-100">
      <div class="page-header">
         <div class="container">
            <h1 class="page-title">Semua Produk</h1>
            <p class="page-subtitle">Temukan berbagai produk digital dan script berkualitas untuk kebutuhan bisnis Anda.
            </p>
         </div>
      </div>

      <div class="flex-grow-1">
         <div class="container products-content">
            <ProductList />
         </div>

         <div class="container faq-content">
            <FaqSection />
         </div>
      </div>

      <Footer />
   </div>
</template>

<script setup lang="ts">

useHead({ title: 'Daftar Produk - Yilzi Shop' })
</script>

<style scoped>
.products-page {
   flex-grow: 1;
}

.page-header {
   padding: 2rem 0 1.5rem;
   border-bottom: 1px solid var(--app-border-color);
}

.page-title {
   font-size: 1.75rem;
   font-weight: 800;
   color: var(--app-text-color);
   margin-bottom: 0.5rem;
}

.page-subtitle {
   font-size: 0.9375rem;
   color: var(--app-secondary-text-color);
   margin: 0;
}

.products-content {
   padding-top: 2rem;
   padding-bottom: 2rem;
}

.faq-content {
   padding-bottom: 3rem;
}
</style>

<template>
   <div>
      <nav class="navbar-modern fixed-top" :class="{ 'scrolled': isScrolled }">
         <div class="nav-container">
            <div class="navbar-content">
               <NuxtLink to="/" class="navbar-brand-link">
                  <div class="brand-logo-ring">
                     <div class="ring-glow"></div>
                     <img src="/images/profile-yilzi.jpg" alt="Yilzi Logo" class="brand-logo-img" />
                  </div>
                  <span class="navbar-brand-text">{{ title }}</span>
               </NuxtLink>

               <div class="navbar-center">
                  <ul class="nav-links">
                     <template v-for="link in visibleLinks" :key="link.text">
                        <li>
                           <a v-if="isExternalLink(link.href)" class="nav-link-item" :href="link.href" target="_blank">
                              {{ link.text }}
                              <i class="bi bi-box-arrow-up-right" style="font-size: 0.7rem; opacity: 0.5;"></i>
                           </a>
                           <NuxtLink v-else class="nav-link-item" :to="link.href"
                              :class="{ 'is-active': isActiveRoute(link.href) }">
                              {{ link.text }}
                           </NuxtLink>
                        </li>
                     </template>
                     <li v-if="isLogin">
                        <a class="nav-link-item" href="#" @click.prevent="logout">Logout</a>
                     </li>
                  </ul>
               </div>

               <div class="navbar-end">
                  <div v-if="isLogin" class="inbox-container">
                     <button class="btn-inbox position-relative" @click="toggleInbox">
                        <i class="bi bi-bell-fill"></i>
                        <span v-if="unreadCount > 0"
                           class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger"
                           style="font-size: 0.65rem;">
                           {{ unreadCount > 99 ? '99+' : unreadCount }}
                        </span>
                     </button>

                     <!-- Inbox Dropdown -->
                     <Transition name="dropdown-fade">
                        <div v-if="showInbox" class="inbox-dropdown premium-glass-card shadow-lg">
                           <div
                              class="inbox-header d-flex justify-content-between align-items-center p-3 border-bottom border-secondary border-opacity-25">
                              <h6 class="fw-bold mb-0"><i class="bi bi-inbox-fill me-2 text-primary"></i>Kotak Masuk
                              </h6>
                              <button v-if="unreadCount > 0" @click="markAsRead"
                                 class="btn btn-sm btn-link text-decoration-none p-0 text-secondary"
                                 style="font-size: 0.8rem;">Tandai
                                 Dibaca</button>
                           </div>
                           <div class="inbox-body p-2">
                              <div v-if="inboxes.length === 0" class="text-center p-4 text-secondary">
                                 <i class="bi bi-envelope-open display-6 d-block mb-2 opacity-50"></i>
                                 <small>Belum ada pesan</small>
                              </div>
                              <div v-else class="inbox-list">
                                 <div v-for="msg in inboxes" :key="msg.id" class="inbox-item p-3 mb-2 rounded"
                                    :class="{ 'unread-item': !msg.read }">
                                    <div class="d-flex justify-content-between align-items-start mb-1">
                                       <span class="badge" :class="getTagClass(msg.tag)">{{ msg.tag }}</span>
                                       <small class="text-secondary" style="font-size:0.7rem">{{
                                          formatTime(msg.timestamp) }}</small>
                                    </div>
                                    <h6 class="fw-bold mb-1 text-white" style="font-size:0.9rem">{{ msg.title }}</h6>
                                    <p class="mb-0 text-secondary" style="font-size:0.8rem; line-height: 1.4;">{{
                                       msg.message }}</p>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </Transition>
                  </div>

                  <Theme />
                  <button class="mobile-menu-btn" @click="toggleSidebar" aria-label="Menu">
                     <i class="bi bi-list"></i>
                  </button>
               </div>
            </div>
         </div>
      </nav>

      <!-- Mobile sidebar overlay -->
      <Transition name="overlay-fade">
         <div v-if="isSidebarOpen" class="sidebar-overlay" @click="closeSidebar"></div>
      </Transition>

      <!-- Mobile sidebar -->
      <Transition name="sidebar-slide">
         <div v-if="isSidebarOpen" class="mobile-sidebar">
            <div class="sidebar-header">
               <div class="sidebar-brand-wrap">
                  <div class="sidebar-logo-ring">
                     <img src="/images/profile-yilzi.jpg" alt="Yilzi Logo" class="sidebar-logo-img" />
                  </div>
                  <span class="sidebar-brand">{{ title }}</span>
               </div>
               <button class="sidebar-close" @click="closeSidebar" aria-label="Close">
                  <i class="bi bi-x-lg"></i>
               </button>
            </div>
            <nav class="sidebar-nav">
               <template v-for="link in allLinks" :key="link.text">
                  <a v-if="isExternalLink(link.href) && shouldShowLink(link)" class="sidebar-link" :href="link.href"
                     target="_blank" @click="closeSidebar">
                     <i class="bi" :class="link.icon"></i>
                     <span>{{ link.text }}</span>
                     <i class="bi bi-box-arrow-up-right"
                        style="font-size: 0.7rem; opacity: 0.4; margin-left: auto;"></i>
                  </a>
                  <NuxtLink v-else-if="shouldShowLink(link)" class="sidebar-link" :to="link.href" @click="closeSidebar"
                     :class="{ 'is-active': isActiveRoute(link.href) }">
                     <i class="bi" :class="link.icon"></i>
                     <span>{{ link.text }}</span>
                  </NuxtLink>
               </template>
               <a v-if="isLogin" class="sidebar-link" href="#" @click.prevent="logout">
                  <i class="bi bi-box-arrow-left"></i>
                  <span>Logout</span>
               </a>
            </nav>
            <div class="sidebar-footer-area">
               <a href="https://shop.yilzicode.com" class="sidebar-cta" target="_blank">
                  <span>Visit Store</span>
                  <i class="bi bi-box-arrow-up-right"></i>
               </a>
            </div>
         </div>
      </Transition>

      <NuxtPage />
      <AssistantChat />
   </div>
</template>

<script setup lang="ts">
import { computed, ref, watch, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { usePageEffects } from '@/composables/usePageEffects'
import { useAuth } from '@/composables/useAuth'


const config = useRuntimeConfig()
const title = config.public.title
const route = useRoute()
const router = useRouter()
const { $api }: any = useNuxtApp()

const { theme } = usePageEffects()
const { clearAuth, isLogin } = useAuth()

const showInbox = ref(false)
const inboxes = ref([])
const unreadCount = computed(() => inboxes.value.filter(i => !i.read).length)

const toggleInbox = async () => {
   showInbox.value = !showInbox.value
   if (showInbox.value) await fetchInbox()
}

const fetchInbox = async () => {
   if (!isLogin.value) return
   try {
      const res = await $api('/api/v1/inbox')
      if (res.status) {
         inboxes.value = res.data || []
      }
   } catch (e) { console.error('Gagal memuat inbox') }
}

const markAsRead = async () => {
   try {
      await $api('/api/v1/inbox/read', { method: 'POST' })
      inboxes.value.forEach(i => i.read = true)
   } catch (e) { }
}

const getTagClass = (tag) => {
   switch (tag) {
      case 'Penting': return 'bg-danger'
      case 'Diskon': return 'bg-success'
      case 'Maintenance': return 'bg-warning text-dark'
      default: return 'bg-primary'
   }
}

const formatTime = (ts) => {
   if (!ts) return ''
   return new Date(ts).toLocaleDateString('id-ID', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
}

const isSidebarOpen = ref(false)
const closeSidebar = () => { isSidebarOpen.value = false }
const toggleSidebar = () => { isSidebarOpen.value = !isSidebarOpen.value }

const allLinks = ref([
   { icon: 'bi-house-door', text: 'Beranda', href: '/' },
   { icon: 'bi-speedometer2', text: 'Dashboard', href: '/dashboard', requiresAuth: true },
   { icon: 'bi-box-seam', text: 'Produk', href: '/products' },
   { icon: 'bi-cloud-arrow-up', text: 'TempFile', href: 'https://upload.yilzicode.com' },
   { icon: 'bi-envelope', text: 'Kontak', href: '/contact' },
   { icon: 'bi-arrow-right-circle', text: 'Login', href: '/login', hideWhenLoggedIn: true }
])

const visibleLinks = computed(() => allLinks.value.filter(l => shouldShowLink(l)))

const isActiveRoute = (href: string) => {
   if (href === '/') return route.path === '/'
   return route.path.startsWith(href)
}

const isExternalLink = (href: any) => href.startsWith('http')
const shouldShowLink = (link: any) => {
   if (link.requiresAuth) return isLogin.value
   if (link.hideWhenLoggedIn) return !isLogin.value
   return true
}

const logout = async () => {
   closeSidebar()
   clearAuth()
   try {
      await $api('/api/v1/logout', { method: 'POST' })
   } catch (err) {
      console.error('Logout gagal:', err)
   } finally {
      router.push('/login')
   }
}

const isScrolled = ref(false)

watch(() => route.path, () => { closeSidebar() })

const checkTokenValidity = async () => {
   if (!isLogin.value) return
   try {
      const response = await $api('/api/v1/check-token', {
         method: 'POST',
         body: { token: localStorage.getItem('token') }
      })
      if (!response.status) {
         if (response.isBlocked) {
            clearAuth()
            window.location.href = '/banned'
            return
         }
         forceLogout('Your session has expired. Please log in again.')
      }
   } catch (error: any) {
      console.error('Token validation failed:', error)
      const data = error.response?._data || error.data
      if (data?.isBlocked) {
         clearAuth()
         window.location.href = '/banned'
         return
      }
      if (error.response?.status === 401) {
         forceLogout('Invalid session detected. Please log in again.')
      }
   }
}

const forceLogout = (message: string) => {
   clearAuth()
   if (process.client) {
      alert(message)
      window.location.href = '/login'
   }
}

onMounted(() => {
   checkTokenValidity()
   if (isLogin.value) {
      fetchInbox()
      setInterval(fetchInbox, 60000) // Auto refresh inbox every minute
   }
})
</script>

<style scoped>
/* Navbar */
.navbar-modern {
   background: var(--app-surface-translucent);
   border-bottom: 1px solid var(--app-border-color);
   padding: 0;
   z-index: 1000;
   transition: all 0.3s ease;
   backdrop-filter: blur(12px);
   -webkit-backdrop-filter: blur(12px);
}

.navbar-modern.scrolled {
   box-shadow: 0 1px 12px rgba(0, 0, 0, 0.08);
}

.nav-container {
   max-width: 1200px;
   margin: 0 auto;
   padding: 0 1.5rem;
}

.navbar-content {
   display: flex;
   align-items: center;
   height: 64px;
}

.navbar-brand-link {
   text-decoration: none;
   flex-shrink: 0;
   display: flex;
   align-items: center;
   gap: 0.625rem;
}

/* === Navbar Logo Ring with 3D + Orbit === */
.brand-logo-ring {
   position: relative;
   width: 42px;
   height: 42px;
   border-radius: 50%;
   display: flex;
   align-items: center;
   justify-content: center;
   flex-shrink: 0;
   transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
   transform-style: preserve-3d;
   perspective: 400px;
}

/* Gradient border ring */
.brand-logo-ring::before {
   content: '';
   position: absolute;
   inset: -2px;
   border-radius: 50%;
   background: var(--gradient-primary);
   z-index: 0;
   opacity: 0.8;
   transition: opacity 0.3s ease;
}

/* Inner bg circle to clip the gradient border */
.brand-logo-ring::after {
   content: '';
   position: absolute;
   inset: 0;
   border-radius: 50%;
   background: var(--app-card-bg);
   z-index: 0;
}

.brand-logo-ring:hover {
   transform: scale(1.08) rotateY(8deg);
}

/* Orbiting ring line */
.ring-glow {
   position: absolute;
   inset: -6px;
   border-radius: 50%;
   border: 1.5px dashed var(--primary-gradient-start);
   opacity: 0;
   z-index: 3;
   animation: nav-ring-orbit 6s linear infinite;
   pointer-events: none;
   transition: opacity 0.4s ease;
}

.brand-logo-ring:hover .ring-glow {
   opacity: 0.45;
}

@keyframes nav-ring-orbit {
   from {
      transform: rotate(0deg);
   }

   to {
      transform: rotate(360deg);
   }
}

.brand-logo-img {
   width: 30px;
   height: 30px;
   object-fit: cover;
   position: relative;
   z-index: 1;
   border-radius: 50%;
   box-shadow: 0 2px 10px rgba(139, 92, 246, 0.2);
   transition: box-shadow 0.3s ease;
}

.brand-logo-ring:hover .brand-logo-img {
   box-shadow: 0 4px 20px rgba(139, 92, 246, 0.4);
}

/* Brand text adapts: dark mode = white, light mode = dark */
.navbar-brand-text {
   font-size: 1.2rem;
   font-weight: 800;
   color: var(--app-text-color);
   letter-spacing: -0.02em;
   text-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
   transition: color 0.3s ease;
}

.navbar-center {
   flex: 1;
   display: flex;
   justify-content: flex-end;
   margin-right: 1rem;
}

.nav-links {
   display: none;
   list-style: none;
   margin: 0;
   padding: 0;
   gap: 0.25rem;
   align-items: center;
}

.nav-link-item {
   display: inline-flex;
   align-items: center;
   gap: 0.25rem;
   padding: 0.5rem 0.875rem;
   font-size: 0.9rem;
   font-weight: 500;
   color: var(--app-text-color);
   text-decoration: none;
   border-radius: 8px;
   transition: all 0.2s ease;
}

.nav-link-item:hover,
.nav-link-item.is-active {
   color: var(--primary-gradient-start);
   background: rgba(139, 92, 246, 0.08);
}

.navbar-end {
   display: flex;
   align-items: center;
   gap: 1rem;
   flex-shrink: 0;
   position: relative;
}

.inbox-container {
   position: relative;
}

.btn-inbox {
   background: rgba(139, 92, 246, 0.1);
   border: 1px solid rgba(139, 92, 246, 0.2);
   color: var(--primary-gradient-start);
   width: 40px;
   height: 40px;
   border-radius: 12px;
   display: flex;
   align-items: center;
   justify-content: center;
   font-size: 1.2rem;
   cursor: pointer;
   transition: all 0.3s;
}

.btn-inbox:hover {
   background: var(--primary-gradient-start);
   color: #fff;
   box-shadow: 0 4px 15px rgba(139, 92, 246, 0.4);
}

.inbox-dropdown {
   position: absolute;
   top: calc(100% + 15px);
   right: -10px;
   width: 380px;
   max-height: 450px;
   display: flex;
   flex-direction: column;
   z-index: 1050;
   border-radius: 20px;
   transform-origin: top right;
   background: #0f172a;
   border: 1px solid rgba(139, 92, 246, 0.4);
   box-shadow: 0 25px 50px rgba(0, 0, 0, 0.8), 0 0 0 1px rgba(255, 255, 255, 0.05) inset;
}

body.light-mode .inbox-dropdown {
   background: #ffffff;
   border: 1px solid #cbd5e1;
   box-shadow: 0 20px 50px rgba(0, 0, 0, 0.15);
}

@media (max-width: 576px) {
   .inbox-dropdown {
      right: -80px;
      width: 300px;
   }
}

.inbox-body {
   overflow-y: auto;
   flex: 1;
   max-height: 380px;
   scrollbar-width: thin;
}

.inbox-item {
   background: rgba(30, 41, 59, 0.8);
   border: 1px solid rgba(255, 255, 255, 0.08);
   transition: all 0.2s;
   border-radius: 12px;
}

body.light-mode .inbox-item {
   background: rgba(0, 0, 0, 0.02);
}

body.light-mode .inbox-item h6 {
   color: #212529 !important;
}

.unread-item {
   background: rgba(139, 92, 246, 0.1);
   border-left: 3px solid var(--primary-gradient-start);
}

.dropdown-fade-enter-active,
.dropdown-fade-leave-active {
   transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.dropdown-fade-enter-from,
.dropdown-fade-leave-to {
   opacity: 0;
   transform: translateY(-10px) scale(0.95);
}

.mobile-menu-btn {
   width: 40px;
   height: 40px;
   border-radius: 10px;
   border: 1px solid var(--app-border-color);
   background: var(--app-card-bg);
   color: var(--app-text-color);
   font-size: 1.25rem;
   cursor: pointer;
   display: flex;
   align-items: center;
   justify-content: center;
   transition: all 0.2s ease;
}

.mobile-menu-btn:hover {
   border-color: var(--primary-gradient-start);
}

@media (min-width: 768px) {
   .nav-links {
      display: flex;
   }

   .mobile-menu-btn {
      display: none;
   }
}

/* Sidebar overlay */
.sidebar-overlay {
   position: fixed;
   inset: 0;
   background: rgba(0, 0, 0, 0.5);
   z-index: 1001;
   backdrop-filter: blur(4px);
}

.overlay-fade-enter-active,
.overlay-fade-leave-active {
   transition: opacity 0.3s ease;
}

.overlay-fade-enter-from,
.overlay-fade-leave-to {
   opacity: 0;
}

/* Mobile sidebar */
.mobile-sidebar {
   position: fixed;
   top: 0;
   right: 0;
   width: 300px;
   max-width: 85vw;
   height: 100vh;
   background: var(--app-card-bg);
   border-left: 1px solid var(--app-border-color);
   z-index: 1002;
   display: flex;
   flex-direction: column;
   box-shadow: -8px 0 30px rgba(0, 0, 0, 0.15);
}

.sidebar-slide-enter-active,
.sidebar-slide-leave-active {
   transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.sidebar-slide-enter-from,
.sidebar-slide-leave-to {
   transform: translateX(100%);
}

.sidebar-header {
   display: flex;
   align-items: center;
   justify-content: space-between;
   padding: 1.25rem 1.5rem;
   border-bottom: 1px solid var(--app-border-color);
}

.sidebar-brand-wrap {
   display: flex;
   align-items: center;
   gap: 0.625rem;
}

/* === Sidebar Logo Ring 3D === */
.sidebar-logo-ring {
   position: relative;
   width: 38px;
   height: 38px;
   border-radius: 50%;
   display: flex;
   align-items: center;
   justify-content: center;
   flex-shrink: 0;
}

.sidebar-logo-ring::before {
   content: '';
   position: absolute;
   inset: -2px;
   border-radius: 50%;
   background: var(--gradient-primary);
   z-index: 0;
   opacity: 0.7;
}

.sidebar-logo-ring::after {
   content: '';
   position: absolute;
   inset: 0;
   border-radius: 50%;
   background: var(--app-card-bg);
   z-index: 0;
}

.sidebar-logo-img {
   width: 26px;
   height: 26px;
   object-fit: cover;
   border-radius: 50%;
   position: relative;
   z-index: 1;
   box-shadow: 0 2px 8px rgba(139, 92, 246, 0.2);
}

.sidebar-brand {
   font-size: 1.125rem;
   font-weight: 800;
   color: var(--app-text-color);
}

.sidebar-close {
   width: 36px;
   height: 36px;
   border-radius: 10px;
   border: 1px solid var(--app-border-color);
   background: var(--app-surface);
   color: var(--app-text-color);
   display: flex;
   align-items: center;
   justify-content: center;
   cursor: pointer;
   transition: all 0.2s ease;
}

.sidebar-close:hover {
   background: rgba(239, 68, 68, 0.1);
   border-color: #ef4444;
   color: #ef4444;
}

.sidebar-nav {
   flex: 1;
   padding: 1rem;
   overflow-y: auto;
   display: flex;
   flex-direction: column;
   gap: 0.25rem;
}

.sidebar-link {
   display: flex;
   align-items: center;
   gap: 0.875rem;
   padding: 0.875rem 1rem;
   border-radius: 12px;
   font-size: 0.9375rem;
   font-weight: 500;
   color: var(--app-text-color);
   text-decoration: none;
   transition: all 0.2s ease;
}

.sidebar-link:hover,
.sidebar-link.is-active {
   background: rgba(139, 92, 246, 0.08);
   color: var(--primary-gradient-start);
}

.sidebar-link i:first-child {
   font-size: 1.125rem;
   width: 24px;
   text-align: center;
}

.sidebar-footer-area {
   padding: 1rem 1.5rem;
   border-top: 1px solid var(--app-border-color);
}

.sidebar-cta {
   display: flex;
   align-items: center;
   justify-content: center;
   gap: 0.5rem;
   padding: 0.75rem;
   background: var(--gradient-primary);
   color: white;
   border-radius: 12px;
   font-weight: 600;
   font-size: 0.9rem;
   text-decoration: none;
   transition: all 0.3s ease;
}

.sidebar-cta:hover {
   transform: translateY(-1px);
   box-shadow: 0 4px 16px rgba(139, 92, 246, 0.4);
   color: white;
}
</style>

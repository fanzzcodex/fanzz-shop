export default defineNuxtRouteMiddleware((to) => {
   if (process.server) return

   const config = useRuntimeConfig()
   const session = useCookie<{ token: string, type: string } | null>('session_token', {
      default: () => null,
      maxAge: config.public.session_expires as number,
      path: '/',
      sameSite: 'lax'
   })
   const token = session.value?.token
   const type = session.value?.type

   if (to.path.startsWith('/dashboard') && !token) {
      return navigateTo('/login')
   }

   if (to.path.startsWith('/login') && token) {
      return navigateTo('/dashboard')
   }

   if (type !== 'admin' && token) {
      if (
         to.path.startsWith('/dashboard/products') ||
         to.path.startsWith('/dashboard/product') ||
         to.path.startsWith('/dashboard/add')
      ) {
         return navigateTo('/dashboard')
      }
   }
})

<template>
   <section class="testimonials-section">
      <div class="container">
         <div class="section-header">
            <span class="section-badge">TESTIMONIALS</span>
            <h2 class="section-title">What Our Clients Say</h2>
            <p class="section-subtitle">Trusted by hundreds of satisfied customers</p>
         </div>

         <div class="carousel-3d">
            <div class="carousel-viewport">
               <div v-for="(t, i) in testimonials" :key="i" class="carousel-card" :class="getCardClass(i)"
                  :style="getCardStyle(i)" @click="goTo(i)">
                  <div class="card-body-3d">
                     <div class="card-quote-icon">
                        <i class="bi bi-quote"></i>
                     </div>
                     <p class="card-text-3d">{{ t.text }}</p>
                     <div class="card-stars">
                        <i v-for="n in 5" :key="n" class="bi bi-star-fill"></i>
                     </div>
                     <div class="card-author-3d">
                        <img :src="t.avatar" :alt="t.name" class="card-avatar" />
                        <div>
                           <h4 class="card-name">{{ t.name }}</h4>
                           <span class="card-role">{{ t.role }}</span>
                        </div>
                     </div>
                  </div>
               </div>
            </div>

            <div class="carousel-controls">
               <button class="ctrl-btn" @click="prev" aria-label="Previous">
                  <i class="bi bi-chevron-left"></i>
               </button>
               <div class="carousel-dots">
                  <button v-for="(_, i) in testimonials" :key="i" class="dot-btn"
                     :class="{ 'dot-active': i === current }" @click="goTo(i)"></button>
               </div>
               <button class="ctrl-btn" @click="next" aria-label="Next">
                  <i class="bi bi-chevron-right"></i>
               </button>
            </div>
         </div>
      </div>
   </section>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'

const current = ref(0)
let interval = null

const testimonials = [
   {
      name: 'Andre',
      role: 'Freelance Developer',
      text: 'Kualitas code sangat rapi dan mudah dikustomisasi. Support dari tim Yilzi juga super responsif. Sangat direkomendasikan untuk sistem e-commerce cepat!',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Andre&backgroundColor=b6e3f4'
   },
   {
      name: 'Nisa',
      role: 'Online Shop Owner',
      text: 'Pelayanan cepat dan responsif. Produk digital berkualitas tinggi dengan dokumentasi lengkap. Sudah beli beberapa produk dan semuanya works perfectly!',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Nisa&backgroundColor=c0aede'
   },
   {
      name: 'Rifki Hermawan',
      role: 'Startup Founder',
      text: 'Script yang paling lengkap dan mudah digunakan. Fitur-fiturnya sangat powerful dan harga sangat terjangkau untuk kualitas UI/UX semewah ini!',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Rifki&backgroundColor=ffd5dc'
   },
   {
      name: 'Neomi Naiva',
      role: 'Business Owner',
      text: 'Automasi transaksinya luar biasa! Sangat membantu bisnis dalam mengelola pesanan tanpa perlu dicek satu-satu manual tiap hari.',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Neomi&backgroundColor=d1d4f9'
   },
   {
      name: 'Fannstore',
      role: 'Top Reseller',
      text: 'Sistem sangat mendukung operasional toko e-commerce dengan lancar. Tidak ada lagi hambatan proses transaksi di tengah malam.',
      avatar: 'https://api.dicebear.com/7.x/initials/svg?seed=Fannstore&backgroundColor=c1f4c5'
   },
   {
      name: 'Elstore',
      role: 'Business Partner',
      text: 'Platform andalan untuk kelola produk digital. Kecepatan loading websitenya juga luar biasa cepat, bikin pelanggan selalu puas!',
      avatar: 'https://api.dicebear.com/7.x/initials/svg?seed=Elstore&backgroundColor=ffc8dd'
   }
]

const totalCards = testimonials.length

const getCardClass = (index) => {
   const diff = index - current.value
   if (diff === 0) return 'card-center'
   if (diff === 1 || diff === -(totalCards - 1)) return 'card-right'
   if (diff === -1 || diff === (totalCards - 1)) return 'card-left'
   return 'card-hidden'
}

const getCardStyle = (index) => {
   const diff = index - current.value
   if (diff === 0) return { transform: 'translateX(0) scale(1) rotateY(0deg)', opacity: 1, zIndex: 3 }
   if (diff === 1 || diff === -(totalCards - 1)) return { transform: 'translateX(60%) scale(0.85) rotateY(-8deg)', opacity: 0.6, zIndex: 2 }
   if (diff === -1 || diff === (totalCards - 1)) return { transform: 'translateX(-60%) scale(0.85) rotateY(8deg)', opacity: 0.6, zIndex: 2 }
   return { transform: 'translateX(0) scale(0.7)', opacity: 0, zIndex: 1 }
}

const next = () => {
   current.value = (current.value + 1) % totalCards
   resetInterval()
}

const prev = () => {
   current.value = (current.value - 1 + totalCards) % totalCards
   resetInterval()
}

const goTo = (i) => {
   current.value = i
   resetInterval()
}

const resetInterval = () => {
   if (interval) clearInterval(interval)
   interval = setInterval(next, 5000)
}

onMounted(() => { interval = setInterval(next, 5000) })
onUnmounted(() => { if (interval) clearInterval(interval) })
</script>

<style scoped>
.testimonials-section {
   padding: 5rem 0;
   overflow: hidden;
}

.section-header {
   text-align: center;
   margin-bottom: 3rem;
}

.section-badge {
   display: inline-block;
   padding: 0.4rem 1.25rem;
   background: var(--gradient-primary);
   color: white;
   font-size: 0.75rem;
   font-weight: 700;
   letter-spacing: 1.5px;
   border-radius: 50px;
   margin-bottom: 1rem;
}

.section-title {
   font-size: 2.25rem;
   font-weight: 800;
   color: var(--app-text-color);
   margin-bottom: 0.5rem;
}

.section-subtitle {
   font-size: 1rem;
   color: var(--app-secondary-text-color);
   margin: 0;
}

/* 3D Carousel */
.carousel-3d {
   max-width: 900px;
   margin: 0 auto;
}

.carousel-viewport {
   position: relative;
   height: 360px;
   perspective: 1200px;
}

.carousel-card {
   position: absolute;
   top: 0;
   left: 50%;
   width: 100%;
   max-width: 520px;
   margin-left: -260px;
   transition: all 0.7s cubic-bezier(0.4, 0, 0.2, 1);
   cursor: pointer;
   transform-style: preserve-3d;
}

.card-body-3d {
   background: var(--app-card-bg);
   border: 1px solid var(--app-border-color);
   border-radius: 20px;
   padding: 2rem 2.25rem;
   box-shadow: 0 8px 32px rgba(0, 0, 0, 0.08);
   transition: box-shadow 0.4s ease;
}

.card-center .card-body-3d {
   box-shadow: 0 20px 60px rgba(99, 102, 241, 0.15);
}

.card-quote-icon {
   font-size: 2rem;
   color: var(--primary-gradient-start);
   opacity: 0.3;
   margin-bottom: 0.75rem;
   line-height: 1;
}

.card-text-3d {
   font-size: 1rem;
   line-height: 1.75;
   color: var(--app-text-color);
   margin-bottom: 1rem;
   font-style: italic;
}

.card-stars {
   display: flex;
   gap: 0.2rem;
   margin-bottom: 1.25rem;
   color: #fbbf24;
   font-size: 1rem;
}

.card-author-3d {
   display: flex;
   align-items: center;
   gap: 0.875rem;
   padding-top: 1rem;
   border-top: 1px solid var(--app-border-color);
}

.card-avatar {
   width: 48px;
   height: 48px;
   border-radius: 50%;
   border: 2px solid var(--primary-gradient-start);
   background: var(--app-surface);
   flex-shrink: 0;
}

.card-name {
   font-size: 0.9375rem;
   font-weight: 700;
   color: var(--app-text-color);
   margin: 0 0 0.1rem 0;
}

.card-role {
   font-size: 0.8125rem;
   color: var(--primary-gradient-start);
   font-weight: 500;
}

/* Controls */
.carousel-controls {
   display: flex;
   align-items: center;
   justify-content: center;
   gap: 1.5rem;
   margin-top: 2rem;
}

.ctrl-btn {
   width: 44px;
   height: 44px;
   border-radius: 50%;
   background: var(--app-card-bg);
   border: 1px solid var(--app-border-color);
   color: var(--app-text-color);
   font-size: 1.125rem;
   display: flex;
   align-items: center;
   justify-content: center;
   cursor: pointer;
   transition: all 0.3s ease;
}

.ctrl-btn:hover {
   background: var(--primary-gradient-start);
   color: white;
   border-color: var(--primary-gradient-start);
}

.carousel-dots {
   display: flex;
   gap: 0.5rem;
}

.dot-btn {
   width: 10px;
   height: 10px;
   border-radius: 50%;
   background: var(--app-border-color);
   border: none;
   cursor: pointer;
   transition: all 0.3s ease;
   padding: 0;
}

.dot-btn.dot-active {
   background: var(--primary-gradient-start);
   width: 28px;
   border-radius: 5px;
}

@media (max-width: 768px) {
   .carousel-viewport {
      height: 400px;
   }

   .carousel-card {
      max-width: calc(100vw - 3rem);
      margin-left: calc(-50vw + 1.5rem);
   }

   .card-body-3d {
      padding: 1.5rem;
   }

   .section-title {
      font-size: 1.75rem;
   }

   .card-center .card-body-3d {
      box-shadow: 0 12px 40px rgba(99, 102, 241, 0.12);
   }
}
</style>

<template>
   <div class="admin-dashboard">
      <!-- Hero Header -->
      <div class="admin-hero">
         <div class="hero-gradient-orb orb-1"></div>
         <div class="hero-gradient-orb orb-2"></div>
         <div class="hero-content">
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
               <div class="animate-slide-up">
                  <div class="greeting-badge"><i class="bi bi-shield-check me-2"></i>Admin Panel</div>
                  <h1 class="hero-title">Selamat Datang, <span class="gradient-text">Admin</span>!</h1>
                  <p class="hero-subtitle">Kelola produk, transaksi, dan pengguna dari satu tempat.</p>
               </div>
               <div class="d-flex gap-2 animate-slide-up" style="animation-delay:0.1s">
                  <button @click.prevent="$router.push('/dashboard/products')" class="btn-outline-premium">
                     <i class="bi bi-list-ul me-2"></i>List Produk
                  </button>
                  <button @click.prevent="$router.push('/dashboard/add')" class="btn-explore">
                     <i class="bi bi-plus-lg me-2"></i>Tambah Produk
                  </button>
                  <button @click.prevent="$router.push('/dashboard/manage-reviews')" class="btn-outline-premium">
                     <i class="bi bi-star me-2"></i>Kelola Ulasan
                  </button>
                  <button @click.prevent="$router.push('/dashboard/users')" class="btn-outline-premium">
                     <i class="bi bi-people-fill me-2"></i>Kelola Pengguna
                  </button>
                  <button @click.prevent="$router.push('/dashboard/broadcast')" class="btn-outline-premium">
                     <i class="bi bi-megaphone-fill me-2"></i>Kirim Broadcast
                  </button>
                  <button @click.prevent="$router.push('/dashboard/health')" class="btn-outline-premium btn-icon-only"
                     title="Health Console">
                     <i class="bi bi-terminal text-success"></i>
                  </button>
               </div>
            </div>
         </div>
      </div>

      <!-- Loading -->
      <div v-if="isLoading" class="loading-container">
         <div class="loading-pulse">
            <div class="pulse-dot"></div>
            <div class="pulse-dot"></div>
            <div class="pulse-dot"></div>
         </div>
         <p class="loading-text">Memuat dashboard...</p>
      </div>

      <!-- Error -->
      <div v-else-if="errorMsg" class="glass-card error-card text-center animate-fade-in">
         <div class="error-icon-wrap"><i class="bi bi-cloud-slash"></i></div>
         <h5 class="fw-bold mt-3">Gagal Memuat Data</h5>
         <p class="text-secondary">{{ errorMsg }}</p>
         <button @click="fetchInitialData" class="btn-explore mt-2"><i class="bi bi-arrow-clockwise me-2"></i>Coba
            Lagi</button>
      </div>

      <!-- Main Content -->
      <div v-else class="dashboard-content">
         <!-- Stats Cards -->
         <div class="stats-grid animate-slide-up" style="animation-delay:0.15s">
            <div v-for="(stat, key) in statsCards" :key="key" class="stat-card-premium">
               <div class="stat-icon-wrap" :style="{ '--icon-gradient': stat.gradient }">
                  <i :class="`bi ${stat.icon}`"></i>
               </div>
               <div class="stat-info">
                  <span class="stat-label">{{ stat.label }}</span>
                  <span class="stat-value">{{ stat.prefix || '' }}{{ formatCurrency(stat.value) }}{{ stat.suffix || ''
                  }}</span>
               </div>
               <div class="stat-decoration"></div>
            </div>
         </div>

         <!-- Charts Row -->
         <div class="charts-grid animate-slide-up" style="animation-delay:0.25s">
            <div class="glass-card">
               <div class="card-header-premium">
                  <div class="d-flex align-items-center gap-2">
                     <div class="header-icon"><i class="bi bi-graph-up-arrow"></i></div>
                     <div>
                        <h5 class="fw-bold mb-0">Pendapatan Bulanan</h5>
                        <small class="text-secondary">6 bulan terakhir</small>
                     </div>
                  </div>
               </div>
               <div class="chart-body">
                  <canvas ref="revenueChartRef"></canvas>
               </div>
            </div>
            <div class="glass-card">
               <div class="card-header-premium">
                  <div class="d-flex align-items-center gap-2">
                     <div class="header-icon" style="--icon-gradient:linear-gradient(135deg,#06B6D4,#22D3EE)">
                        <i class="bi bi-people-fill"></i>
                     </div>
                     <div>
                        <h5 class="fw-bold mb-0">Registrasi User</h5>
                        <small class="text-secondary">6 bulan terakhir</small>
                     </div>
                  </div>
               </div>
               <div class="chart-body">
                  <canvas ref="userChartRef"></canvas>
               </div>
            </div>
         </div>

         <!-- Main Grid -->
         <div class="main-grid">
            <!-- Transactions -->
            <div class="glass-card transactions-card animate-slide-up" style="animation-delay:0.3s">
               <div class="card-header-premium">
                  <div class="d-flex align-items-center gap-2">
                     <div class="header-icon"><i class="bi bi-clock-history"></i></div>
                     <div>
                        <h5 class="fw-bold mb-0">Transaksi Terbaru</h5>
                        <small class="text-secondary">{{ totalTransactions }} total</small>
                     </div>
                  </div>
                  <div class="d-flex gap-2 align-items-center">
                     <div class="search-bar">
                        <i class="bi bi-search"></i>
                        <input type="search" v-model="transactionSearchQuery" placeholder="Cari..."
                           :disabled="isTransactionsLoading">
                     </div>
                     <NuxtLink v-if="transactions.length > 0" to="/dashboard/invoices"
                        class="btn-outline-premium btn-sm">Semua</NuxtLink>
                  </div>
               </div>

               <div class="transactions-list" :class="{ 'is-loading': isTransactionsLoading }">
                  <div v-if="transactions.length === 0 && !isTransactionsLoading" class="empty-state">
                     <i class="bi bi-inbox"></i>
                     <p>Belum ada transaksi</p>
                  </div>
                  <div v-else v-for="(sale, index) in transactions" :key="sale._id" class="transaction-item"
                     :style="{ animationDelay: `${index * 0.05}s` }">
                     <div class="transaction-left">
                        <div class="transaction-status-icon" :class="`status-icon-${sale.status.toLowerCase()}`">
                           <i
                              :class="sale.status === 'Paid' ? 'bi bi-check-circle-fill' : sale.status === 'Pending' ? 'bi bi-hourglass-split' : 'bi bi-x-circle-fill'"></i>
                        </div>
                        <div class="transaction-details">
                           <span class="transaction-id">{{ sale._id }}</span>
                           <span class="transaction-date">{{ formatDateInvoice(sale.created_at) }}</span>
                        </div>
                     </div>
                     <div class="transaction-right">
                        <span class="status-pill" :class="`pill-${sale.status.toLowerCase()}`">{{ sale.status }}</span>
                        <div class="transaction-actions">
                           <button @click="showTransactionDetails(sale)" class="btn-icon" title="Detail"><i
                                 class="bi bi-eye"></i></button>
                           <button @click="$router.push(`/invoice/${sale._id}`)" class="btn-icon" title="Invoice"><i
                                 class="bi bi-box-arrow-up-right"></i></button>
                        </div>
                     </div>
                  </div>
               </div>

               <div v-if="isTransactionsLoading" class="loading-overlay">
                  <div class="loading-pulse small">
                     <div class="pulse-dot"></div>
                     <div class="pulse-dot"></div>
                     <div class="pulse-dot"></div>
                  </div>
               </div>

               <div v-if="totalTransactionPages > 1" class="pagination-bar">
                  <button @click="goToTransactionPage(transactionCurrentPage - 1)"
                     :disabled="transactionCurrentPage === 1" class="btn-page"><i
                        class="bi bi-chevron-left"></i></button>
                  <span class="page-info">{{ transactionCurrentPage }} / {{ totalTransactionPages }}</span>
                  <button @click="goToTransactionPage(transactionCurrentPage + 1)"
                     :disabled="transactionCurrentPage === totalTransactionPages" class="btn-page"><i
                        class="bi bi-chevron-right"></i></button>
               </div>
            </div>

            <!-- Right Sidebar -->
            <div class="sidebar-stack">
               <!-- Top Products -->
               <div class="glass-card animate-slide-up" style="animation-delay:0.35s">
                  <div class="card-header-premium">
                     <div class="d-flex align-items-center gap-2">
                        <div class="header-icon" style="--icon-gradient:linear-gradient(135deg,#F59E0B,#FBBF24)">
                           <i class="bi bi-trophy-fill"></i>
                        </div>
                        <h5 class="fw-bold mb-0">Produk Terlaris</h5>
                     </div>
                  </div>
                  <div class="products-list">
                     <div v-if="topProducts.length === 0" class="empty-state small-empty">
                        <i class="bi bi-box-seam"></i>
                        <p>Data belum cukup</p>
                     </div>
                     <div v-for="(product, index) in topProducts" :key="product.id" class="product-rank-item">
                        <div class="rank-badge" :class="`rank-${index + 1}`">{{ index + 1 }}</div>
                        <div class="product-info">
                           <span class="product-name">{{ product.name }}</span>
                           <span class="product-sales">{{ product.sales }} terjual</span>
                        </div>
                        <a @click.prevent="$router.push(`/product/${product.id}`)" class="btn-icon" title="Lihat"><i
                              class="bi bi-eye"></i></a>
                     </div>
                  </div>
               </div>

               <!-- Top Users -->
               <div class="glass-card animate-slide-up" style="animation-delay:0.4s">
                  <div class="card-header-premium">
                     <div class="d-flex align-items-center gap-2">
                        <div class="header-icon" style="--icon-gradient:linear-gradient(135deg,#EC4899,#F472B6)">
                           <i class="bi bi-star-fill"></i>
                        </div>
                        <h5 class="fw-bold mb-0">Top Pembeli</h5>
                     </div>
                  </div>
                  <div class="products-list">
                     <div v-if="topUsers.length === 0" class="empty-state small-empty">
                        <i class="bi bi-people"></i>
                        <p>Belum ada data</p>
                     </div>
                     <div v-for="(user, index) in topUsers" :key="user.email" class="product-rank-item">
                        <div class="rank-badge" :class="`rank-${index + 1}`">{{ index + 1 }}</div>
                        <div class="product-info">
                           <span class="product-name">{{ user.name }}</span>
                           <span class="product-sales">Rp {{ formatCurrency(user.totalSpending) }}</span>
                        </div>
                     </div>
                  </div>
               </div>

               <!-- Tag Manager -->
               <div class="glass-card animate-slide-up" style="animation-delay:0.45s">
                  <div class="card-header-premium">
                     <div class="d-flex align-items-center gap-2">
                        <div class="header-icon" style="--icon-gradient:linear-gradient(135deg,#10B981,#34D399)">
                           <i class="bi bi-tags-fill"></i>
                        </div>
                        <h5 class="fw-bold mb-0">Tag Manager</h5>
                     </div>
                  </div>
                  <div class="tag-manager-body">
                     <div class="tag-input-wrap">
                        <input type="text" v-model="newTagName" @keyup.enter="addTag" placeholder="Nama tag baru...">
                        <button @click="addTag" :disabled="isSubmittingTag" class="btn-explore btn-sm">
                           <span v-if="isSubmittingTag" class="spinner-border spinner-border-sm"></span>
                           <span v-else>Tambah</span>
                        </button>
                     </div>
                     <div v-if="tags.length === 0" class="empty-state small-empty">
                        <p>Belum ada tag</p>
                     </div>
                     <div v-else class="tag-list">
                        <div v-for="tag in tags" :key="tag._id" class="tag-chip">
                           <span>{{ tag.name }}</span>
                           <button @click="deleteTag(tag._id, tag.name)" class="tag-delete"><i
                                 class="bi bi-x"></i></button>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>

         <!-- Transaction Modal -->
         <div class="modal fade" ref="transactionModalRef" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
               <div v-if="selectedTransaction" class="modal-content premium-modal">
                  <div class="modal-header premium-modal-header">
                     <div>
                        <h5 class="modal-title fw-bold">Detail Transaksi</h5>
                        <small class="text-secondary">{{ selectedTransaction._id }}</small>
                     </div>
                     <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                  </div>
                  <div class="modal-body premium-modal-body">
                     <div class="modal-status-banner" :class="`banner-${selectedTransaction.status.toLowerCase()}`">
                        <i
                           :class="selectedTransaction.status === 'Paid' ? 'bi bi-check-circle-fill' : 'bi bi-hourglass-split'"></i>
                        <span>{{ selectedTransaction.status === 'Paid' ? 'Pembayaran Berhasil' : 'Menunggu Pembayaran'
                           }}</span>
                     </div>
                     <div class="modal-detail-grid">
                        <div class="detail-item">
                           <span class="detail-label"><i class="bi bi-person me-2"></i>Customer</span>
                           <span class="detail-value">{{ selectedTransaction.email }}</span>
                        </div>
                        <div class="detail-item">
                           <span class="detail-label"><i class="bi bi-calendar3 me-2"></i>Tanggal</span>
                           <span class="detail-value">{{ formatDateInvoice(selectedTransaction.created_at) }}</span>
                        </div>
                        <div class="detail-item">
                           <span class="detail-label"><i class="bi bi-box-seam me-2"></i>Produk</span>
                           <span class="detail-value">
                              <span v-for="name in selectedTransaction.productNames" :key="name" class="product-tag">{{
                                 name }}</span>
                           </span>
                        </div>
                        <div class="detail-item total-item">
                           <span class="detail-label"><i class="bi bi-cash-stack me-2"></i>Total</span>
                           <span class="detail-value total-value">Rp {{ formatCurrency(selectedTransaction.amount)
                              }}</span>
                        </div>
                     </div>
                  </div>
                  <div class="modal-footer premium-modal-footer">
                     <button type="button" class="btn-ghost" data-bs-dismiss="modal">Tutup</button>
                     <button class="btn-explore" @click="$router.push(`/invoice/${selectedTransaction._id}`)"
                        data-bs-dismiss="modal">
                        <i class="bi bi-box-arrow-up-right me-2"></i>Invoice
                     </button>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</template>

<script setup>
import { ref, reactive, onMounted, onUnmounted, computed, watch, nextTick } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { Modal } from 'bootstrap'
import Swal from 'sweetalert2'
import Chart from 'chart.js/auto'
import { io } from 'socket.io-client'

const { $api } = useNuxtApp()
const router = useRouter()
const route = useRoute()

const isLoading = ref(true)
const errorMsg = ref(null)
const statsCards = ref({})
const topProducts = ref([])
const topUsers = ref([])
const tags = ref([])
const newTagName = ref('')
const isSubmittingTag = ref(false)

// Chart data
const monthlyRevenue = ref([])
const userTrend = ref([])
const revenueChartRef = ref(null)
const userChartRef = ref(null)
let revenueChart = null
let userChart = null

// Transactions
const transactions = ref([])
const totalTransactions = ref(0)
const isTransactionsLoading = ref(true)
const transactionSearchQuery = ref(route.query.search || '')
const transactionCurrentPage = ref(parseInt(route.query.page) || 1)
const transactionItemsPerPage = ref(10)
const selectedTransaction = ref(null)
const transactionModalRef = ref(null)
let modalInstance = null

const totalTransactionPages = computed(() => Math.ceil(totalTransactions.value / transactionItemsPerPage.value) || 1)
const formatCurrency = value => Number(value || 0).toLocaleString('id-ID')
const formatDateInvoice = dateString => new Date(dateString).toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })

const goToTransactionPage = async (page) => {
   if (page >= 1 && page <= totalTransactionPages.value && page !== transactionCurrentPage.value) {
      await router.push({ query: { ...route.query, page } })
   }
}

const showTransactionDetails = (transaction) => {
   selectedTransaction.value = transaction
   modalInstance?.show()
}

const initCharts = () => {
   const isDark = document.body.classList.contains('dark-mode')
   const textColor = isDark ? '#94A3B8' : '#64748B'
   const gridColor = isDark ? 'rgba(51,65,85,0.5)' : 'rgba(226,232,240,0.8)'

   // Revenue chart
   if (revenueChartRef.value) {
      revenueChart?.destroy()
      const ctx = revenueChartRef.value.getContext('2d')
      const gradient = ctx.createLinearGradient(0, 0, 0, 250)
      gradient.addColorStop(0, 'rgba(139,92,246,0.3)')
      gradient.addColorStop(1, 'rgba(139,92,246,0)')

      revenueChart = new Chart(ctx, {
         type: 'line',
         data: {
            labels: monthlyRevenue.value.map(d => d.month),
            datasets: [{
               label: 'Pendapatan (Rp)',
               data: monthlyRevenue.value.map(d => d.revenue),
               borderColor: '#8B5CF6',
               backgroundColor: gradient,
               borderWidth: 2.5,
               fill: true,
               tension: 0.4,
               pointRadius: 4,
               pointBackgroundColor: '#8B5CF6',
               pointBorderColor: '#fff',
               pointBorderWidth: 2
            }]
         },
         options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
               legend: { display: false },
               tooltip: {
                  backgroundColor: isDark ? '#1E293B' : '#fff',
                  titleColor: isDark ? '#F8FAFC' : '#0F172A',
                  bodyColor: isDark ? '#94A3B8' : '#64748B',
                  borderColor: isDark ? '#334155' : '#E2E8F0',
                  borderWidth: 1,
                  padding: 12,
                  cornerRadius: 10,
                  callbacks: {
                     label: ctx => `Rp ${Number(ctx.parsed.y).toLocaleString('id-ID')}`
                  }
               }
            },
            scales: {
               x: { ticks: { color: textColor }, grid: { display: false } },
               y: {
                  ticks: {
                     color: textColor,
                     callback: v => v >= 1000000 ? `${(v / 1000000).toFixed(1)}M` : v >= 1000 ? `${(v / 1000).toFixed(0)}K` : v
                  },
                  grid: { color: gridColor }
               }
            }
         }
      })
   }

   // User trend chart
   if (userChartRef.value) {
      userChart?.destroy()
      userChart = new Chart(userChartRef.value, {
         type: 'bar',
         data: {
            labels: userTrend.value.map(d => d.month),
            datasets: [{
               label: 'User Baru',
               data: userTrend.value.map(d => d.count),
               backgroundColor: 'rgba(6,182,212,0.6)',
               borderColor: '#06B6D4',
               borderWidth: 1.5,
               borderRadius: 8,
               maxBarThickness: 40
            }]
         },
         options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
               x: { ticks: { color: textColor }, grid: { display: false } },
               y: { ticks: { color: textColor, stepSize: 1 }, grid: { color: gridColor } }
            }
         }
      })
   }
}

const fetchTransactions = async () => {
   isTransactionsLoading.value = true
   try {
      const params = new URLSearchParams({
         page: transactionCurrentPage.value,
         limit: transactionItemsPerPage.value,
         search: transactionSearchQuery.value
      })
      const res = await $api(`/api/v2/invoices?${params.toString()}`)
      if (res.status && res.data) {
         transactions.value = res.data.invoices
         totalTransactions.value = res.data.total
      } else {
         transactions.value = []
         totalTransactions.value = 0
      }
   } catch (err) {
      console.error("Gagal mengambil invoices:", err)
   } finally {
      isTransactionsLoading.value = false
   }
}

let transactionSearchTimeout
watch(transactionSearchQuery, (q) => {
   clearTimeout(transactionSearchTimeout)
   transactionSearchTimeout = setTimeout(async () => {
      await router.push({ query: { ...route.query, page: 1, search: q || undefined } })
   }, 300)
})

watch(() => route.query, (q) => {
   transactionCurrentPage.value = parseInt(q.page) || 1
   fetchTransactions()
}, { deep: true })

const fetchInitialData = async (initialLoad = true) => {
   if (initialLoad) isLoading.value = true
   errorMsg.value = null
   try {
      const [statsRes, tagsRes] = await Promise.all([
         $api('/api/v2/statistic'),
         $api('/api/v2/tags')
      ])

      if (statsRes?.status && statsRes.data) {
         const s = statsRes.data.stats
         statsCards.value = {
            totalRevenue: { label: 'Total Pendapatan', value: s.totalRevenue, icon: 'bi-cash-stack', prefix: 'Rp ', gradient: 'linear-gradient(135deg,#8B5CF6,#A855F7)' },
            totalSales: { label: 'Total Penjualan', value: s.totalSales, icon: 'bi-cart-check', suffix: ' Unit', gradient: 'linear-gradient(135deg,#3B82F6,#60A5FA)' },
            totalProducts: { label: 'Jumlah Produk', value: s.totalProducts, icon: 'bi-box-seam', gradient: 'linear-gradient(135deg,#06B6D4,#22D3EE)' },
            totalUsers: { label: 'Total Pengguna', value: s.totalUsers || 0, icon: 'bi-people', gradient: 'linear-gradient(135deg,#10B981,#34D399)' },
         }
         topProducts.value = statsRes.data.topProducts || []
         topUsers.value = statsRes.data.topUsers || []
         monthlyRevenue.value = statsRes.data.monthlyRevenue || []
         userTrend.value = statsRes.data.userTrend || []
      }
      if (tagsRes?.status) { tags.value = tagsRes.data }

      await fetchTransactions()

      if (initialLoad) isLoading.value = false
      await nextTick()
      initCharts()
   } catch (err) {
      errorMsg.value = err.data?.msg || err.message || 'Terjadi kesalahan'
      if (initialLoad) isLoading.value = false
   }
}

const addTag = async () => {
   if (!newTagName.value.trim()) return
   isSubmittingTag.value = true
   try {
      const res = await $api('/api/v2/tags', { method: 'POST', body: { name: newTagName.value.trim() } })
      if (res.status) {
         tags.value.push(res.data)
         tags.value.sort((a, b) => a.name.localeCompare(b.name))
         newTagName.value = ''
         Swal.fire({ icon: 'success', title: 'Tag Ditambahkan', timer: 1500, showConfirmButton: false })
      } else throw new Error(res.msg)
   } catch (err) {
      Swal.fire({ icon: 'error', title: 'Gagal', text: err.data?.msg || err.message })
   } finally { isSubmittingTag.value = false }
}

const deleteTag = (tagId, tagName) => {
   Swal.fire({
      title: 'Anda Yakin?',
      html: `Menghapus tag "<b>${tagName}</b>" akan <b>menghapus semua produk</b> yang menggunakan tag ini!`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#3085d6',
      confirmButtonText: 'Ya, hapus!',
      cancelButtonText: 'Batal'
   }).then(async (result) => {
      if (result.isConfirmed) {
         try {
            const res = await $api(`/api/v2/tags/${tagId}`, { method: 'DELETE' })
            if (res.status) {
               tags.value = tags.value.filter(t => t._id !== tagId)
               Swal.fire('Dihapus!', res.msg, 'success')
               fetchInitialData(false)
            } else throw new Error(res.msg)
         } catch (err) {
            Swal.fire('Gagal!', err.data?.msg || err.message, 'error')
         }
      }
   })
}

onMounted(() => {
   fetchInitialData(true)
   if (transactionModalRef.value) {
      modalInstance = new Modal(transactionModalRef.value)
      transactionModalRef.value.addEventListener('hidden.bs.modal', () => { selectedTransaction.value = null })
   }
})

onUnmounted(() => {
   modalInstance?.dispose()
   revenueChart?.destroy()
   userChart?.destroy()
})
</script>

<style scoped>
.admin-dashboard {
   min-height: 100vh;
}

/* Hero */
.admin-hero {
   position: relative;
   padding: calc(64px + 2.5rem) 0 2rem;
   overflow: hidden;
}

.hero-gradient-orb {
   position: absolute;
   border-radius: 50%;
   filter: blur(100px);
   opacity: 0.3;
   animation: float 10s ease-in-out infinite;
}

.orb-1 {
   width: 350px;
   height: 350px;
   background: var(--primary-gradient-start);
   top: -120px;
   right: -50px;
}

.orb-2 {
   width: 250px;
   height: 250px;
   background: var(--primary-gradient-end);
   bottom: -80px;
   left: 20%;
   animation-delay: 3s;
}

.hero-content {
   position: relative;
   z-index: 1;
}

.greeting-badge {
   display: inline-flex;
   align-items: center;
   padding: 0.4rem 1rem;
   background: linear-gradient(135deg, rgba(139, 92, 246, 0.12), rgba(59, 130, 246, 0.12));
   color: var(--primary-gradient-start);
   border-radius: 50px;
   font-weight: 600;
   font-size: 0.8rem;
   border: 1px solid rgba(139, 92, 246, 0.2);
   margin-bottom: 1rem;
   letter-spacing: 0.5px;
   text-transform: uppercase;
}

.hero-title {
   font-size: 2rem;
   font-weight: 800;
   color: var(--app-text-color);
   margin-bottom: 0.5rem;
}

.gradient-text {
   background: var(--gradient-primary);
   -webkit-background-clip: text;
   -webkit-text-fill-color: transparent;
   background-clip: text;
}

.hero-subtitle {
   color: var(--app-secondary-text-color);
   font-size: 1rem;
   margin: 0;
}

/* Buttons */
.btn-explore {
   display: inline-flex;
   align-items: center;
   padding: 0.6rem 1.25rem;
   background: var(--gradient-primary);
   color: #fff;
   border: none;
   border-radius: 12px;
   font-weight: 600;
   font-size: 0.85rem;
   cursor: pointer;
   transition: all 0.3s;
   text-decoration: none;
   box-shadow: 0 4px 15px rgba(139, 92, 246, 0.3);
}

.btn-explore:hover {
   transform: translateY(-2px);
   box-shadow: 0 8px 25px rgba(139, 92, 246, 0.4);
   color: #fff;
}

.btn-explore.btn-sm {
   padding: 0.4rem 0.9rem;
   font-size: 0.8rem;
   border-radius: 8px;
}

.btn-outline-premium {
   display: inline-flex;
   align-items: center;
   padding: 0.6rem 1.25rem;
   background: transparent;
   border: 1.5px solid var(--app-border-color);
   border-radius: 12px;
   color: var(--app-text-color);
   font-weight: 600;
   font-size: 0.85rem;
   cursor: pointer;
   transition: all 0.3s;
   text-decoration: none;
}

.btn-outline-premium:hover {
   border-color: var(--primary-gradient-start);
   color: var(--primary-gradient-start);
}

.btn-outline-premium.btn-sm {
   padding: 0.35rem 0.8rem;
   font-size: 0.78rem;
   border-radius: 8px;
}

/* Loading */
.loading-container {
   display: flex;
   flex-direction: column;
   align-items: center;
   padding: 5rem 0;
}

.loading-pulse {
   display: flex;
   gap: 8px;
}

.loading-pulse.small .pulse-dot {
   width: 8px;
   height: 8px;
}

.pulse-dot {
   width: 12px;
   height: 12px;
   background: var(--gradient-primary);
   border-radius: 50%;
   animation: pulse-bounce 1.4s ease-in-out infinite;
}

.pulse-dot:nth-child(2) {
   animation-delay: 0.2s;
}

.pulse-dot:nth-child(3) {
   animation-delay: 0.4s;
}

.loading-text {
   margin-top: 1.5rem;
   color: var(--app-secondary-text-color);
   font-weight: 500;
}

/* Stats */
.stats-grid {
   display: grid;
   grid-template-columns: repeat(4, 1fr);
   gap: 1.25rem;
   margin-bottom: 1.5rem;
}

.stat-card-premium {
   position: relative;
   display: flex;
   align-items: center;
   gap: 1rem;
   padding: 1.25rem 1.5rem;
   background: var(--app-card-bg);
   border: 1px solid var(--app-border-color);
   border-radius: 16px;
   overflow: hidden;
   transition: all 0.3s;
}

.stat-card-premium:hover {
   transform: translateY(-3px);
   box-shadow: 0 12px 30px rgba(0, 0, 0, 0.08);
   border-color: rgba(139, 92, 246, 0.3);
}

.stat-decoration {
   position: absolute;
   top: -20px;
   right: -20px;
   width: 80px;
   height: 80px;
   border-radius: 50%;
   background: var(--gradient-primary);
   opacity: 0.05;
}

.stat-icon-wrap {
   width: 48px;
   height: 48px;
   min-width: 48px;
   display: flex;
   align-items: center;
   justify-content: center;
   background: var(--icon-gradient, var(--gradient-primary));
   border-radius: 14px;
   color: #fff;
   font-size: 1.2rem;
   box-shadow: 0 4px 12px rgba(139, 92, 246, 0.2);
}

.stat-info {
   display: flex;
   flex-direction: column;
}

.stat-label {
   font-size: 0.78rem;
   font-weight: 500;
   color: var(--app-secondary-text-color);
   text-transform: uppercase;
   letter-spacing: 0.5px;
}

.stat-value {
   font-size: 1.3rem;
   font-weight: 700;
   color: var(--app-text-color);
   line-height: 1.3;
}

/* Glass Card */
.glass-card {
   border-radius: 20px;
   overflow: hidden;
}

.card-header-premium {
   display: flex;
   justify-content: space-between;
   align-items: center;
   padding: 1.25rem 1.5rem;
   border-bottom: 1px solid var(--app-border-color);
   flex-wrap: wrap;
   gap: 1rem;
}

.header-icon {
   width: 38px;
   height: 38px;
   display: flex;
   align-items: center;
   justify-content: center;
   background: var(--icon-gradient, var(--gradient-primary));
   border-radius: 10px;
   color: #fff;
   font-size: 1rem;
}

/* Charts */
.charts-grid {
   display: grid;
   grid-template-columns: 1fr 1fr;
   gap: 1.5rem;
   margin-bottom: 1.5rem;
}

.chart-body {
   padding: 1.25rem;
   height: 280px;
}

/* Search */
.search-bar {
   display: flex;
   align-items: center;
   gap: 0.5rem;
   padding: 0.45rem 0.9rem;
   background: var(--app-surface);
   border: 1px solid var(--app-border-color);
   border-radius: 10px;
   min-width: 180px;
   transition: border-color 0.3s;
}

.search-bar:focus-within {
   border-color: var(--primary-gradient-start);
}

.search-bar i {
   color: var(--app-secondary-text-color);
   font-size: 0.85rem;
}

.search-bar input {
   border: none;
   background: transparent;
   outline: none;
   color: var(--app-text-color);
   font-size: 0.85rem;
   width: 100%;
}

.search-bar input::placeholder {
   color: var(--app-secondary-text-color);
}

/* Main Grid */
.main-grid {
   display: grid;
   grid-template-columns: 1fr 380px;
   gap: 1.5rem;
}

.sidebar-stack {
   display: flex;
   flex-direction: column;
   gap: 1.5rem;
}

/* Transactions */
.transactions-card {
   position: relative;
}

.transactions-list {
   min-height: 200px;
}

.transactions-list.is-loading {
   opacity: 0.4;
   pointer-events: none;
}

.transaction-item {
   display: flex;
   justify-content: space-between;
   align-items: center;
   padding: 0.85rem 1.5rem;
   border-bottom: 1px solid var(--app-border-color);
   transition: background 0.2s;
   animation: slide-in-right 0.4s ease-out both;
}

.transaction-item:last-child {
   border-bottom: none;
}

.transaction-item:hover {
   background: var(--app-surface);
}

.transaction-left,
.transaction-right {
   display: flex;
   align-items: center;
   gap: 0.75rem;
}

.transaction-status-icon {
   width: 38px;
   height: 38px;
   display: flex;
   align-items: center;
   justify-content: center;
   border-radius: 10px;
   font-size: 1rem;
}

.status-icon-paid {
   background: rgba(34, 197, 94, 0.1);
   color: #22C55E;
}

.status-icon-pending {
   background: rgba(245, 158, 11, 0.1);
   color: #F59E0B;
}

.status-icon-expired,
.status-icon-failed {
   background: rgba(239, 68, 68, 0.1);
   color: #EF4444;
}

.transaction-details {
   display: flex;
   flex-direction: column;
}

.transaction-id {
   font-weight: 600;
   font-size: 0.85rem;
   color: var(--app-text-color);
}

.transaction-date {
   font-size: 0.75rem;
   color: var(--app-secondary-text-color);
}

.status-pill {
   padding: 0.25rem 0.7rem;
   border-radius: 50px;
   font-size: 0.7rem;
   font-weight: 600;
   text-transform: uppercase;
   letter-spacing: 0.5px;
}

.pill-paid {
   background: rgba(34, 197, 94, 0.1);
   color: #22C55E;
}

.pill-pending {
   background: rgba(245, 158, 11, 0.1);
   color: #F59E0B;
}

.pill-expired,
.pill-failed {
   background: rgba(239, 68, 68, 0.1);
   color: #EF4444;
}

.transaction-actions {
   display: flex;
   gap: 4px;
}

.btn-icon {
   width: 32px;
   height: 32px;
   display: flex;
   align-items: center;
   justify-content: center;
   background: transparent;
   border: 1px solid var(--app-border-color);
   border-radius: 8px;
   color: var(--app-secondary-text-color);
   cursor: pointer;
   transition: all 0.2s;
   font-size: 0.8rem;
}

.btn-icon:hover {
   background: var(--gradient-primary);
   color: #fff;
   border-color: transparent;
}

.loading-overlay {
   position: absolute;
   inset: 0;
   display: flex;
   align-items: center;
   justify-content: center;
   background: rgba(255, 255, 255, 0.5);
   backdrop-filter: blur(2px);
   z-index: 2;
   border-radius: 20px;
}

.pagination-bar {
   display: flex;
   align-items: center;
   justify-content: center;
   gap: 1rem;
   padding: 0.75rem;
   border-top: 1px solid var(--app-border-color);
}

.btn-page {
   width: 34px;
   height: 34px;
   display: flex;
   align-items: center;
   justify-content: center;
   background: var(--app-surface);
   border: 1px solid var(--app-border-color);
   border-radius: 10px;
   color: var(--app-text-color);
   cursor: pointer;
   transition: all 0.2s;
}

.btn-page:hover:not(:disabled) {
   background: var(--gradient-primary);
   color: #fff;
   border-color: transparent;
}

.btn-page:disabled {
   opacity: 0.4;
   cursor: default;
}

.page-info {
   font-size: 0.85rem;
   font-weight: 600;
   color: var(--app-secondary-text-color);
}

/* Products/Users List */
.products-list {
   padding: 0.5rem 0;
}

.product-rank-item {
   display: flex;
   align-items: center;
   gap: 0.75rem;
   padding: 0.75rem 1.5rem;
   transition: background 0.2s;
}

.product-rank-item:hover {
   background: var(--app-surface);
}

.rank-badge {
   width: 30px;
   height: 30px;
   min-width: 30px;
   display: flex;
   align-items: center;
   justify-content: center;
   border-radius: 8px;
   font-weight: 700;
   font-size: 0.8rem;
   background: var(--app-surface);
   color: var(--app-secondary-text-color);
   border: 1px solid var(--app-border-color);
}

.rank-1 {
   background: linear-gradient(135deg, #F59E0B, #FBBF24);
   color: #fff;
   border: none;
}

.rank-2 {
   background: linear-gradient(135deg, #94A3B8, #CBD5E1);
   color: #fff;
   border: none;
}

.rank-3 {
   background: linear-gradient(135deg, #D97706, #F59E0B);
   color: #fff;
   border: none;
}

.product-info {
   display: flex;
   flex-direction: column;
   flex: 1;
   min-width: 0;
}

.product-name {
   font-weight: 600;
   font-size: 0.85rem;
   color: var(--app-text-color);
   white-space: nowrap;
   overflow: hidden;
   text-overflow: ellipsis;
}

.product-sales {
   font-size: 0.75rem;
   color: var(--app-secondary-text-color);
}

/* Tag Manager */
.tag-manager-body {
   padding: 1.25rem 1.5rem;
}

.tag-input-wrap {
   display: flex;
   gap: 0.5rem;
   margin-bottom: 1rem;
}

.tag-input-wrap input {
   flex: 1;
   padding: 0.5rem 0.75rem;
   background: var(--app-surface);
   border: 1px solid var(--app-border-color);
   border-radius: 10px;
   color: var(--app-text-color);
   font-size: 0.85rem;
   outline: none;
   transition: border-color 0.3s;
}

.tag-input-wrap input:focus {
   border-color: var(--primary-gradient-start);
}

.tag-list {
   display: flex;
   flex-wrap: wrap;
   gap: 0.5rem;
}

.tag-chip {
   display: flex;
   align-items: center;
   gap: 0.35rem;
   padding: 0.3rem 0.4rem 0.3rem 0.75rem;
   background: var(--app-surface);
   border: 1px solid var(--app-border-color);
   border-radius: 50px;
   font-size: 0.82rem;
   color: var(--app-text-color);
}

.tag-delete {
   width: 24px;
   height: 24px;
   display: flex;
   align-items: center;
   justify-content: center;
   background: rgba(239, 68, 68, 0.1);
   color: #EF4444;
   border: none;
   border-radius: 50%;
   cursor: pointer;
   font-size: 0.8rem;
   transition: all 0.2s;
}

.tag-delete:hover {
   background: #EF4444;
   color: #fff;
}

/* Empty State */
.empty-state {
   display: flex;
   flex-direction: column;
   align-items: center;
   padding: 2.5rem 1rem;
   color: var(--app-secondary-text-color);
}

.empty-state i {
   font-size: 2rem;
   opacity: 0.3;
   margin-bottom: 0.5rem;
}

.empty-state p {
   font-weight: 600;
   margin: 0;
   font-size: 0.9rem;
}

.small-empty {
   padding: 1.5rem 1rem;
}

.small-empty i {
   font-size: 1.5rem;
}

/* Error */
.error-card {
   padding: 3rem;
   margin: 2rem 0;
}

.error-icon-wrap {
   width: 64px;
   height: 64px;
   display: inline-flex;
   align-items: center;
   justify-content: center;
   background: rgba(239, 68, 68, 0.1);
   color: #EF4444;
   border-radius: 16px;
   font-size: 1.8rem;
}

/* Modal */
.premium-modal {
   background: var(--app-card-bg);
   border: 1px solid var(--app-border-color);
   border-radius: 20px;
   overflow: hidden;
}

.premium-modal-header {
   border-bottom: 1px solid var(--app-border-color);
   padding: 1.25rem 1.5rem;
}

.premium-modal-body {
   padding: 1.5rem;
}

.premium-modal-footer {
   border-top: 1px solid var(--app-border-color);
   padding: 1rem 1.5rem;
   display: flex;
   gap: 0.75rem;
   justify-content: flex-end;
}

.modal-status-banner {
   display: flex;
   align-items: center;
   gap: 0.75rem;
   padding: 0.85rem 1.1rem;
   border-radius: 12px;
   font-weight: 600;
   font-size: 0.85rem;
   margin-bottom: 1.25rem;
}

.banner-paid {
   background: rgba(34, 197, 94, 0.1);
   color: #22C55E;
}

.banner-pending {
   background: rgba(245, 158, 11, 0.1);
   color: #F59E0B;
}

.modal-detail-grid {
   display: flex;
   flex-direction: column;
   gap: 0.85rem;
}

.detail-item {
   display: flex;
   justify-content: space-between;
   align-items: flex-start;
   padding-bottom: 0.85rem;
   border-bottom: 1px solid var(--app-border-color);
}

.detail-item:last-child {
   border-bottom: none;
   padding-bottom: 0;
}

.detail-label {
   font-size: 0.82rem;
   color: var(--app-secondary-text-color);
   font-weight: 500;
}

.detail-value {
   font-weight: 600;
   color: var(--app-text-color);
   text-align: right;
   max-width: 60%;
}

.total-value {
   font-size: 1.15rem;
   background: var(--gradient-primary);
   -webkit-background-clip: text;
   -webkit-text-fill-color: transparent;
   background-clip: text;
}

.product-tag {
   display: inline-block;
   padding: 0.2rem 0.5rem;
   background: var(--app-surface);
   border: 1px solid var(--app-border-color);
   border-radius: 6px;
   font-size: 0.78rem;
   margin: 0.1rem;
}

.btn-ghost {
   padding: 0.5rem 1rem;
   background: transparent;
   border: 1px solid var(--app-border-color);
   border-radius: 10px;
   color: var(--app-text-color);
   font-weight: 500;
   cursor: pointer;
   transition: all 0.2s;
}

.btn-ghost:hover {
   background: var(--app-surface);
}

/* Animations */
@keyframes float {

   0%,
   100% {
      transform: translate(0, 0);
   }

   50% {
      transform: translate(15px, -15px);
   }
}

@keyframes pulse-bounce {

   0%,
   80%,
   100% {
      transform: scale(0.6);
      opacity: 0.4;
   }

   40% {
      transform: scale(1);
      opacity: 1;
   }
}

@keyframes slide-in-right {
   from {
      opacity: 0;
      transform: translateX(-10px);
   }

   to {
      opacity: 1;
      transform: translateX(0);
   }
}

.animate-slide-up {
   animation: slide-up 0.5s ease-out both;
}

.animate-fade-in {
   animation: fade-in 0.4s ease-out both;
}

@keyframes slide-up {
   from {
      opacity: 0;
      transform: translateY(20px);
   }

   to {
      opacity: 1;
      transform: translateY(0);
   }
}

@keyframes fade-in {
   from {
      opacity: 0;
   }

   to {
      opacity: 1;
   }
}

/* Terminal Monitor */
.terminal-card {
   background: #0f172a !important;
   /* Hard dark slate */
   border: 1px solid rgba(16, 185, 129, 0.2);
   overflow: hidden;
}

.terminal-header {
   border-bottom: 1px solid rgba(16, 185, 129, 0.1);
   background: rgba(15, 23, 42, 0.5);
}

.terminal-title {
   font-family: 'Consolas', 'Monaco', monospace;
   letter-spacing: 0.5px;
}

.pulse-dot-green {
   width: 8px;
   height: 8px;
   background: #10B981;
   border-radius: 50%;
   display: inline-block;
   animation: pulse-green 2s infinite;
}

@keyframes pulse-green {
   0% {
      box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7);
   }

   70% {
      box-shadow: 0 0 0 6px rgba(16, 185, 129, 0);
   }

   100% {
      box-shadow: 0 0 0 0 rgba(16, 185, 129, 0);
   }
}

.terminal-body {
   padding: 1rem;
   height: 350px;
   overflow-y: auto;
   font-family: 'Consolas', 'Monaco', monospace;
   font-size: 0.85rem;
   color: #e2e8f0;
   background: #000;
}

.terminal-empty {
   display: flex;
   align-items: center;
   justify-content: center;
   height: 100%;
   color: #64748b;
   font-style: italic;
}

.terminal-logs {
   display: flex;
   flex-direction: column;
   gap: 4px;
}

.log-line {
   word-break: break-all;
   line-height: 1.4;
   padding-bottom: 2px;
   border-bottom: 1px dashed rgba(255, 255, 255, 0.05);
}

.log-line:last-child {
   border-bottom: none;
}

.log-time {
   color: #94a3b8;
   margin-right: 8px;
}

.log-type {
   font-weight: 600;
   margin-right: 8px;
}

.log-info .log-type {
   color: #3b82f6;
}

/* Blue */
.log-warn .log-type {
   color: #f59e0b;
}

/* Yellow */
.log-error .log-type {
   color: #ef4444;
}

/* Red */

.log-info .log-message {
   color: #e2e8f0;
}

.log-warn .log-message {
   color: #fcd34d;
}

.log-error .log-message {
   color: #fca5a5;
}

/* Responsive */
@media (max-width: 1200px) {
   .stats-grid {
      grid-template-columns: repeat(2, 1fr);
   }

   .charts-grid {
      grid-template-columns: 1fr;
   }

   .main-grid {
      grid-template-columns: 1fr;
   }
}

@media (max-width: 768px) {
   .stats-grid {
      grid-template-columns: 1fr;
   }

   .hero-title {
      font-size: 1.5rem;
   }

   .admin-hero {
      padding: 1.5rem 0 1rem;
   }

   .card-header-premium {
      flex-direction: column;
      align-items: flex-start;
   }

   .search-bar {
      width: 100%;
      min-width: unset;
   }

   .transaction-item {
      flex-direction: column;
      align-items: flex-start;
      gap: 0.75rem;
   }

   .transaction-right {
      width: 100%;
      justify-content: space-between;
   }
}

/* Dark Mode */
:global(body.dark-mode) .loading-overlay {
   background: rgba(15, 23, 42, 0.5);
}

:global(body.dark-mode) .stat-card-premium:hover {
   box-shadow: 0 12px 30px rgba(0, 0, 0, 0.3);
}
</style>
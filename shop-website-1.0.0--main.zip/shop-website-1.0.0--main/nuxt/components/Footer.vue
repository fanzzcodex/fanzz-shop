<template>
   <footer class="modern-footer">
      <div class="container">
         <div class="row g-5 mb-5">
            <div class="col-lg-4 col-md-6">
               <div class="footer-brand-section">
                  <div class="footer-brand-logo-wrap mb-3">
                     <div class="footer-logo-ring">
                        <img src="/images/profile-yilzi.jpg" alt="Yilzi Logo" class="footer-logo-img" />
                     </div>
                     <h3 class="brand-title mb-0">Yilzi Shop</h3>
                  </div>
                  <p class="brand-description mb-4">Professional portfolio of Andri Kusuma (Yilzi), specializing in AI
                     Integration, WhatsApp Bots, and Enterprise Web Solutions.</p>

                  <div class="social-links">
                     <a href="https://github.com/yilzicode" target="_blank" rel="noopener noreferrer"
                        class="social-icon" aria-label="GitHub">
                        <i class="bi bi-github"></i>
                     </a>
                     <a href="https://linkedin.com/in/yilzicode" target="_blank" rel="noopener noreferrer"
                        class="social-icon" aria-label="LinkedIn">
                        <i class="bi bi-linkedin"></i>
                     </a>
                     <a href="https://twitter.com/yilzi_dominan" target="_blank" rel="noopener noreferrer"
                        class="social-icon" aria-label="Twitter">
                        <i class="bi bi-twitter"></i>
                     </a>
                     <a href="https://instagram.com/yilzi_dominan" target="_blank" rel="noopener noreferrer"
                        class="social-icon" aria-label="Instagram">
                        <i class="bi bi-instagram"></i>
                     </a>
                  </div>
               </div>
            </div>

            <div class="col-lg-2 col-md-6">
               <h5 class="footer-heading">Services</h5>
               <ul class="footer-nav">
                  <li><a href="https://yilzicode.com" target="_blank">WhatsApp Bots</a></li>
                  <li><a href="https://yilzicode.com" target="_blank">Web Development</a></li>
                  <li><a href="https://yilzicode.com" target="_blank">AI Integration</a></li>
                  <li><a href="https://yilzicode.com" target="_blank">Consulting</a></li>
               </ul>
            </div>

            <div class="col-lg-2 col-md-6">
               <h5 class="footer-heading">Company</h5>
               <ul class="footer-nav">
                  <li><a href="https://yilzicode.com" target="_blank">About</a></li>
                  <li>
                     <NuxtLink to="/products">Projects</NuxtLink>
                  </li>
                  <li><a href="https://yilzicode.com/blog" target="_blank">Blog</a></li>
                  <li>
                     <NuxtLink to="/contact">Contact</NuxtLink>
                  </li>
               </ul>
            </div>

            <div class="col-lg-4 col-md-6">
               <h5 class="footer-heading">Connect</h5>
               <ul class="contact-list">
                  <li>
                     <i class="bi bi-envelope-fill"></i>
                     <a href="mailto:owner@yilzicode.com">owner@yilzicode.com</a>
                  </li>
                  <li>
                     <i class="bi bi-instagram"></i>
                     <a href="https://instagram.com/yilzi_dominan" target="_blank">@yilzi_dominan</a>
                  </li>
               </ul>
            </div>
         </div>

         <div class="footer-bottom">
            <div class="row align-items-center">
               <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                  <p class="mb-0 copyright">
                     © {{ new Date().getFullYear() }} Yilzi (Andri Kusuma). All rights reserved.
                  </p>
               </div>
               <div class="col-md-6 text-center text-md-end">
                  <div class="footer-links">
                     <a href="https://yilzicode.com/privacy" target="_blank">Privacy Policy</a>
                     <span class="mx-2">·</span>
                     <a href="https://yilzicode.com/terms" target="_blank">Terms of Service</a>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </footer>
</template>

<script setup>
import { usePageEffects } from '@/composables/usePageEffects'
const config = useRuntimeConfig()
const theme = usePageEffects().theme
</script>

<style scoped>
.modern-footer {
   position: relative;
   background: var(--app-card-bg);
   border-top: 1px solid var(--app-border-color);
   margin-top: auto;
   padding: 4rem 0 2rem;
}

.footer-brand-logo-wrap {
   display: flex;
   align-items: center;
   gap: 0.875rem;
}

/* === Footer Logo Ring 3D === */
.footer-logo-ring {
   position: relative;
   width: 52px;
   height: 52px;
   border-radius: 50%;
   display: flex;
   align-items: center;
   justify-content: center;
   flex-shrink: 0;
   transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
   transform-style: preserve-3d;
}

.footer-logo-ring::before {
   content: '';
   position: absolute;
   inset: -2.5px;
   border-radius: 50%;
   background: var(--gradient-primary);
   z-index: 0;
   opacity: 0.8;
}

.footer-logo-ring::after {
   content: '';
   position: absolute;
   inset: 0;
   border-radius: 50%;
   background: var(--app-card-bg);
   z-index: 0;
}

.footer-logo-ring:hover {
   transform: scale(1.08) rotateY(10deg);
   box-shadow: 0 8px 30px rgba(139, 92, 246, 0.25);
}

.footer-logo-img {
   width: 36px;
   height: 36px;
   object-fit: cover;
   border-radius: 50%;
   position: relative;
   z-index: 1;
   box-shadow: 0 2px 12px rgba(139, 92, 246, 0.2);
}

.footer-brand-section .brand-title {
   font-size: 1.75rem;
   font-weight: 800;
   background: var(--gradient-primary);
   -webkit-background-clip: text;
   -webkit-text-fill-color: transparent;
   background-clip: text;
}

.brand-description {
   color: var(--app-secondary-text-color);
   line-height: 1.6;
}

.social-links {
   display: flex;
   gap: 0.75rem;
}

.social-icon {
   width: 44px;
   height: 44px;
   border-radius: 12px;
   background: var(--app-card-bg);
   border: 1px solid var(--app-border-color);
   display: flex;
   align-items: center;
   justify-content: center;
   color: var(--app-text-color);
   font-size: 1.25rem;
   transition: all 0.3s ease;
}

.social-icon:hover {
   background: var(--gradient-primary);
   border-color: var(--primary-gradient-start);
   color: white;
   transform: translateY(-4px);
}

.footer-heading {
   font-weight: 700;
   margin-bottom: 1.5rem;
   color: var(--app-text-color);
}

.footer-nav {
   list-style: none;
   padding: 0;
   margin: 0;
}

.footer-nav li {
   margin-bottom: 0.75rem;
}

.footer-nav a {
   color: var(--app-secondary-text-color);
   text-decoration: none;
   display: flex;
   align-items: center;
   transition: all 0.3s ease;
}

.footer-nav a:hover {
   color: var(--primary-gradient-start);
}

.footer-links {
   display: flex;
   align-items: center;
   justify-content: center;
   gap: 0.5rem;
}

.footer-links a {
   color: var(--app-secondary-text-color);
   text-decoration: none;
   font-size: 0.875rem;
   transition: color 0.3s ease;
}

.footer-links a:hover {
   color: var(--primary-gradient-start);
}

@media (max-width: 768px) {
   .footer-links {
      justify-content: center;
   }
}

.contact-list {
   list-style: none;
   padding: 0;
   margin: 0;
}

.contact-list li {
   display: flex;
   align-items: center;
   gap: 0.75rem;
   margin-bottom: 1rem;
   color: var(--app-secondary-text-color);
}

.contact-list i {
   font-size: 1.25rem;
   color: var(--primary-gradient-start);
   min-width: 24px;
}

.contact-list a {
   color: var(--app-secondary-text-color);
   text-decoration: none;
   transition: color 0.3s ease;
}

.contact-list a:hover {
   color: var(--primary-gradient-start);
}

.footer-bottom {
   margin-top: 3rem;
   padding-top: 2rem;
   border-top: 1px solid var(--app-border-color);
}

.copyright,
.credit {
   color: var(--app-secondary-text-color);
   font-size: 0.875rem;
}

.credit a {
   color: var(--primary-gradient-start);
   text-decoration: none;
   font-weight: 600;
   transition: color 0.3s ease;
}

.credit a:hover {
   color: var(--primary-gradient-end);
}

@media (max-width: 768px) {
   .modern-footer {
      padding: 3rem 0 1.5rem;
   }

   .footer-brand-section {
      text-align: center;
   }

   .social-links {
      justify-content: center;
   }
}
</style>

<template>
   <button @click="toggleTheme" class="theme-toggle-btn" :aria-label="`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`">
      <transition name="rotate" mode="out-in">
         <i v-if="theme === 'dark'" key="moon" class="bi bi-moon-stars-fill"></i>
         <i v-else key="sun" class="bi bi-sun-fill"></i>
      </transition>
   </button>
</template>

<script setup lang="ts">
import { usePageEffects } from '@/composables/usePageEffects'
const { theme, toggleTheme } = usePageEffects()
</script>

<style scoped>
.theme-toggle-btn {
   width: 44px;
   height: 44px;
   border-radius: 12px;
   border: 1px solid var(--app-border-color);
   background: var(--app-card-bg);
   display: flex;
   align-items: center;
   justify-content: center;
   cursor: pointer;
   transition: all 0.3s ease;
}

.theme-toggle-btn:hover {
   background: var(--gradient-primary);
   border-color: var(--primary-gradient-start);
   transform: translateY(-2px);
   box-shadow: 0 4px 12px rgba(139, 92, 246, 0.3);
}

.theme-toggle-btn i {
   font-size: 1.25rem;
   color: var(--app-text-color);
   transition: color 0.3s ease;
}

.theme-toggle-btn:hover i {
   color: white;
}

.rotate-enter-active,
.rotate-leave-active {
   transition: transform 0.3s ease, opacity 0.3s ease;
}

.rotate-enter-from {
   transform: rotate(-180deg);
   opacity: 0;
}

.rotate-leave-to {
   transform: rotate(180deg);
   opacity: 0;
}
</style>
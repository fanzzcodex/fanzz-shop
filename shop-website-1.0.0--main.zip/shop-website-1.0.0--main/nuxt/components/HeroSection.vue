<template>
   <section class="hero-section">
      <div class="hero-bg">
         <div class="hero-glow glow-1"></div>
         <div class="hero-glow glow-2"></div>
      </div>

      <div class="container hero-container">
         <div class="hero-top">
            <div class="hero-text-col">
               <div class="hero-badge">
                  <span class="badge-dot"></span>
                  <span>YILZI OFFICIAL STORE</span>
               </div>

               <h1 class="hero-heading">
                  {{ config.public.hero.title }}
               </h1>

               <p class="hero-desc">
                  {{ config.public.hero.highlight }}
               </p>

               <div class="hero-actions">
                  <button @click="$router.push('/products')" class="btn-hero-primary">
                     Lihat Semua Produk
                  </button>
               </div>
            </div>

            <div class="hero-brand-col">
               <div class="brand-logo-wrap">
                  <!-- Orbiting ring decorations -->
                  <div class="brand-orbit orbit-1"></div>
                  <div class="brand-orbit orbit-2"></div>
                  <div class="brand-orbit orbit-3"></div>
                  <!-- Corner art elements -->
                  <div class="brand-art art-tl"></div>
                  <div class="brand-art art-tr"></div>
                  <div class="brand-art art-bl"></div>
                  <div class="brand-art art-br"></div>
                  <!-- Sparkle dots -->
                  <div class="brand-sparkle sp-1"></div>
                  <div class="brand-sparkle sp-2"></div>
                  <div class="brand-sparkle sp-3"></div>
                  <div class="brand-sparkle sp-4"></div>
                  <!-- 3D text block -->
                  <div class="brand-3d-container">
                     <span class="brand-3d-text brand-main">Yilzi</span>
                     <span class="brand-3d-text brand-sub">SHOP</span>
                  </div>
               </div>
            </div>
         </div>

         <div class="hero-features">
            <div class="feature-pill" v-for="(f, i) in features" :key="i">
               <div class="fp-icon" :class="f.colorClass">
                  <i class="bi" :class="f.icon"></i>
               </div>
               <div class="fp-text">
                  <span class="fp-title">{{ f.title }}</span>
                  <span class="fp-sub">{{ f.sub }}</span>
               </div>
            </div>
         </div>

         <div class="hero-metrics">
            <div class="metric-item">
               <span class="metric-value">500+</span>
               <span class="metric-label">PELANGGAN</span>
            </div>
            <div class="metric-divider"></div>
            <div class="metric-item">
               <span class="metric-value">4.9/5</span>
               <span class="metric-label">RATING</span>
            </div>
            <div class="metric-divider"></div>
            <div class="metric-item">
               <span class="metric-value">24/7</span>
               <span class="metric-label">SUPPORT</span>
            </div>
         </div>
      </div>
   </section>
</template>

<script setup lang="ts">
import { usePageEffects } from '@/composables/usePageEffects';

const config = useRuntimeConfig();
const pageEffects = usePageEffects();
const theme = pageEffects.theme;

const features = [
   { icon: 'bi-lightning-charge-fill', title: 'Otomasi Cepat', sub: 'Proses instan', colorClass: 'fp-purple' },
   { icon: 'bi-shield-check', title: 'Aman & Terpercaya', sub: 'Garansi 100%', colorClass: 'fp-green' },
   { icon: 'bi-graph-up-arrow', title: 'Performa Tinggi', sub: 'Uptime 99.9%', colorClass: 'fp-cyan' },
   { icon: 'bi-code-slash', title: 'Source Code', sub: 'Full akses', colorClass: 'fp-pink' }
];
</script>

<style scoped>
.hero-section {
   position: relative;
   min-height: 100vh;
   display: flex;
   align-items: center;
   padding: 7rem 0 4rem;
   overflow: hidden;
}

.hero-bg {
   position: absolute;
   inset: 0;
   z-index: 0;
}

.hero-glow {
   position: absolute;
   border-radius: 50%;
   filter: blur(120px);
   opacity: 0.35;
}

.glow-1 {
   width: 500px;
   height: 500px;
   background: var(--primary-gradient-start);
   top: -150px;
   left: -100px;
}

.glow-2 {
   width: 400px;
   height: 400px;
   background: var(--accent-cyan);
   bottom: -150px;
   right: -80px;
}

.hero-container {
   position: relative;
   z-index: 1;
}

/* Top: text + brand */
.hero-top {
   display: flex;
   align-items: center;
   gap: 4rem;
   margin-bottom: 3.5rem;
}

.hero-text-col {
   flex: 1;
   min-width: 0;
}

.hero-brand-col {
   flex: 0 0 auto;
   display: flex;
   align-items: center;
   justify-content: center;
}

/* =================== 3D BRAND DISPLAY =================== */
.brand-logo-wrap {
   position: relative;
   display: flex;
   align-items: center;
   justify-content: center;
   user-select: none;
   perspective: 1000px;
   width: 320px;
   height: 280px;
}

/* -- Orbiting rings -- */
.brand-orbit {
   position: absolute;
   border-radius: 50%;
   border: 1.5px solid var(--app-text-color);
   opacity: 0.06;
   pointer-events: none;
}

.orbit-1 {
   width: 310px;
   height: 310px;
   animation: orbit-spin 18s linear infinite;
   border-style: dashed;
}

.orbit-2 {
   width: 260px;
   height: 260px;
   animation: orbit-spin 14s linear infinite reverse;
   border-top-color: var(--primary-gradient-start);
   border-right-color: transparent;
   border-bottom-color: var(--primary-gradient-end);
   border-left-color: transparent;
   opacity: 0.10;
}

.orbit-3 {
   width: 220px;
   height: 220px;
   animation: orbit-spin 22s linear infinite;
   border-style: dotted;
   opacity: 0.04;
}

@keyframes orbit-spin {
   from {
      transform: rotate(0deg);
   }

   to {
      transform: rotate(360deg);
   }
}

/* -- Corner art elements -- */
.brand-art {
   position: absolute;
   width: 28px;
   height: 28px;
   opacity: 0.12;
   pointer-events: none;
}

.brand-art::before,
.brand-art::after {
   content: '';
   position: absolute;
   background: var(--app-text-color);
   border-radius: 1px;
}

.brand-art::before {
   width: 100%;
   height: 1.5px;
   top: 50%;
   transform: translateY(-50%);
}

.brand-art::after {
   height: 100%;
   width: 1.5px;
   left: 50%;
   transform: translateX(-50%);
}

.art-tl {
   top: 0;
   left: 0;
}

.art-tr {
   top: 0;
   right: 0;
}

.art-bl {
   bottom: 0;
   left: 0;
}

.art-br {
   bottom: 0;
   right: 0;
}

/* -- Sparkle dots -- */
.brand-sparkle {
   position: absolute;
   width: 5px;
   height: 5px;
   border-radius: 50%;
   background: var(--primary-gradient-start);
   opacity: 0;
   pointer-events: none;
   animation: sparkle-pulse 3s ease-in-out infinite;
}

.sp-1 {
   top: 12%;
   left: 18%;
   animation-delay: 0s;
}

.sp-2 {
   top: 8%;
   right: 22%;
   animation-delay: 0.8s;
}

.sp-3 {
   bottom: 15%;
   left: 14%;
   animation-delay: 1.6s;
}

.sp-4 {
   bottom: 10%;
   right: 16%;
   animation-delay: 2.2s;
}

@keyframes sparkle-pulse {

   0%,
   100% {
      opacity: 0;
      transform: scale(0.6);
   }

   50% {
      opacity: 0.55;
      transform: scale(1.3);
   }
}

/* -- 3D text container -- */
.brand-3d-container {
   position: relative;
   display: flex;
   flex-direction: column;
   align-items: flex-end;
   transform: rotateY(-10deg) rotateX(3deg);
   transform-style: preserve-3d;
   animation: brand-3d-float 7s ease-in-out infinite;
   z-index: 2;
}

.brand-3d-text {
   display: block;
   line-height: 1;
   font-weight: 900;
   transition: all 0.5s ease;
   position: relative;
   /* Adapts to theme automatically */
   color: var(--app-text-color);
   opacity: 0.10;
}

/* 3D depth layers via text-shadow */
.brand-main {
   font-size: 8rem;
   letter-spacing: -4px;
   text-shadow:
      0 1px 0 rgba(139, 92, 246, 0.06),
      0 2px 0 rgba(139, 92, 246, 0.05),
      0 3px 0 rgba(139, 92, 246, 0.04),
      0 4px 0 rgba(139, 92, 246, 0.03),
      0 5px 0 rgba(139, 92, 246, 0.02),
      0 6px 0 rgba(139, 92, 246, 0.01),
      0 10px 30px rgba(0, 0, 0, 0.06),
      0 20px 60px rgba(139, 92, 246, 0.04);
   transform: translateZ(40px);
}

.brand-sub {
   font-size: 3rem;
   letter-spacing: 2rem;
   text-transform: uppercase;
   font-weight: 200;
   margin-top: -0.15rem;
   text-shadow:
      0 1px 0 rgba(59, 130, 246, 0.05),
      0 2px 0 rgba(59, 130, 246, 0.04),
      0 3px 0 rgba(59, 130, 246, 0.03),
      0 8px 20px rgba(0, 0, 0, 0.04);
   transform: translateZ(20px);
}

@keyframes brand-3d-float {

   0%,
   100% {
      transform: rotateY(-10deg) rotateX(3deg) translateY(0);
   }

   50% {
      transform: rotateY(-6deg) rotateX(5deg) translateY(-14px);
   }
}

.hero-badge {
   display: inline-flex;
   align-items: center;
   gap: 0.625rem;
   padding: 0.5rem 1.125rem;
   background: var(--app-card-bg);
   border: 1px solid var(--app-border-color);
   border-radius: 50px;
   font-size: 0.75rem;
   font-weight: 700;
   color: var(--app-secondary-text-color);
   margin-bottom: 1.75rem;
   letter-spacing: 0.08em;
   text-transform: uppercase;
}

.badge-dot {
   width: 8px;
   height: 8px;
   border-radius: 50%;
   background: #22c55e;
   animation: blink 2s infinite;
}

@keyframes blink {

   0%,
   100% {
      opacity: 1;
   }

   50% {
      opacity: 0.3;
   }
}

.hero-heading {
   font-size: clamp(2.5rem, 5vw, 3.75rem);
   font-weight: 800;
   line-height: 1.15;
   margin-bottom: 1.25rem;
   color: var(--app-text-color);
}

.hero-desc {
   font-size: 1.0625rem;
   line-height: 1.7;
   color: var(--app-secondary-text-color);
   margin-bottom: 2rem;
   max-width: 520px;
}

.hero-actions {
   margin-bottom: 0;
}

.btn-hero-primary {
   display: inline-flex;
   align-items: center;
   gap: 0.5rem;
   padding: 0.875rem 2.25rem;
   background: transparent;
   color: var(--app-text-color);
   border: 1px solid var(--app-border-color);
   border-radius: 8px;
   font-size: 0.9375rem;
   font-weight: 600;
   cursor: pointer;
   transition: all 0.3s ease;
}

.btn-hero-primary:hover {
   border-color: var(--primary-gradient-start);
   color: var(--primary-gradient-start);
   transform: translateY(-2px);
   box-shadow: 0 6px 24px rgba(139, 92, 246, 0.15);
}

/* Feature pills row */
.hero-features {
   display: flex;
   flex-wrap: wrap;
   gap: 1rem;
   margin-bottom: 3rem;
   padding-top: 2.5rem;
   border-top: 1px solid var(--app-border-color);
}

.feature-pill {
   display: flex;
   align-items: center;
   gap: 0.75rem;
   padding: 0.75rem 1.25rem;
   background: var(--app-card-bg);
   border: 1px solid var(--app-border-color);
   border-radius: 12px;
   transition: all 0.3s ease;
   flex: 1;
   min-width: 200px;
}

.feature-pill:hover {
   border-color: var(--primary-gradient-start);
   transform: translateY(-3px);
   box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
}

.fp-icon {
   width: 40px;
   height: 40px;
   border-radius: 10px;
   display: flex;
   align-items: center;
   justify-content: center;
   color: white;
   font-size: 1.125rem;
   flex-shrink: 0;
}

.fp-purple {
   background: var(--gradient-primary);
}

.fp-green {
   background: linear-gradient(135deg, #22c55e, #16a34a);
}

.fp-cyan {
   background: linear-gradient(135deg, #06b6d4, #0891b2);
}

.fp-pink {
   background: linear-gradient(135deg, #ec4899, #db2777);
}

.fp-text {
   display: flex;
   flex-direction: column;
}

.fp-title {
   font-size: 0.875rem;
   font-weight: 700;
   color: var(--app-text-color);
}

.fp-sub {
   font-size: 0.75rem;
   color: var(--app-secondary-text-color);
}

/* Metrics */
.hero-metrics {
   display: flex;
   align-items: center;
   gap: 2rem;
}

.metric-item {
   display: flex;
   flex-direction: column;
}

.metric-value {
   font-size: 1.5rem;
   font-weight: 800;
   color: var(--app-text-color);
}

.metric-label {
   font-size: 0.75rem;
   color: var(--app-secondary-text-color);
   text-transform: uppercase;
   letter-spacing: 0.06em;
   font-weight: 500;
}

.metric-divider {
   width: 1px;
   height: 36px;
   background: var(--app-border-color);
}

/* Responsive */
@media (max-width: 991px) {
   .hero-section {
      min-height: auto;
      padding: 6rem 0 3rem;
   }

   .hero-top {
      flex-direction: column;
      gap: 2rem;
   }

   .hero-brand-col {
      display: none;
   }

   .hero-heading {
      font-size: clamp(2rem, 6vw, 3rem);
   }

   .hero-features {
      flex-direction: column;
   }

   .feature-pill {
      min-width: 0;
   }
}

@media (max-width: 576px) {
   .hero-section {
      padding: 5.5rem 0 2rem;
   }

   .hero-heading {
      font-size: 1.875rem;
   }

   .hero-desc {
      font-size: 0.9375rem;
   }

   .hero-metrics {
      gap: 1.25rem;
   }

   .metric-value {
      font-size: 1.25rem;
   }
}
</style>

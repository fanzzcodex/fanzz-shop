<template>
   <section id="featured-products" class="featured-section">
      <div class="container position-relative z-1">
         <div class="text-center mb-5 animate-slide-up">
            <div
               class="d-inline-flex align-items-center gap-2 px-3 py-2 rounded-pill bg-primary bg-opacity-10 text-primary mb-3">
               <i class="bi bi-star-fill text-warning"></i>
               <span class="fw-bold tracking-wider text-uppercase small">Featured Products</span>
            </div>
            <h2 class="display-4 fw-black mb-3 text-gradient">Terbaik Bulan Ini</h2>
            <p class="lead text-secondary mx-auto" style="max-width: 600px;">
               Koleksi produk digital pilihan dengan performa tinggi dan desain terdepan.
            </p>
         </div>

         <div v-if="pending" class="d-flex justify-content-center align-items-center py-5">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
               <span class="visually-hidden">Loading...</span>
            </div>
         </div>

         <div v-else-if="error" class="alert custom-alert-danger text-center mx-auto" style="max-width: 500px">
            <i class="bi bi-exclamation-triangle-fill fs-3 mb-2 d-block"></i>
            <p class="mb-0">Maaf, gagal memuat produk unggulan. Silakan coba lagi nanti.</p>
         </div>

         <div v-else-if="featuredProducts.length" class="product-slider-container">
            <div class="product-slider d-flex gap-4 pb-4">
               <div v-for="(product, index) in featuredProducts" :key="product.id"
                  class="product-slide-item flex-shrink-0 animate-slide-up"
                  :style="{ animationDelay: `${index * 0.1}s` }">
                  <div class="premium-card h-100 d-flex flex-column" @click="$router.push('/product/' + product.id)">

                     <div class="premium-image-wrapper">
                        <img :src="product.imageUrl" class="premium-image" :alt="product.name"
                           @error="handleImageError">
                        <div class="image-overlay d-flex flex-column justify-content-center align-items-center">
                           <button class="btn btn-glass-light rounded-pill px-4 py-2 fw-semibold">
                              <i class="bi bi-eye me-2"></i> Lihat Detail
                           </button>
                        </div>
                        <div class="badge-float top-left" v-if="product.label">
                           <span class="glow-badge">{{ product.label }}</span>
                        </div>
                        <div class="badge-float bottom-right">
                           <span class="dark-badge"><i class="bi bi-cart-check-fill me-1 text-success"></i> {{
                              product.sales || 0 }} Terjual</span>
                        </div>
                     </div>

                     <div class="premium-content p-4 d-flex flex-column flex-grow-1">
                        <h4 class="fw-bold mb-2 text-truncate-2">{{ product.name }}</h4>
                        <div
                           class="d-flex flex-column pt-3 border-top border-secondary border-opacity-25 relative mt-4">
                           <div class="mb-3">
                              <span
                                 class="d-block text-secondary small fw-medium tracking-wider mb-1 text-uppercase">Harga</span>
                              <span class="fs-4 fw-black text-gradient">Rp {{ formatCurrency(product.price) }}</span>
                           </div>
                           <div class="d-flex gap-2">
                              <button class="btn btn-glass-light flex-grow-1 rounded-pill py-2 fw-semibold"
                                 @click.stop="$router.push('/product/' + product.id)">
                                 Detail
                              </button>
                              <button class="btn btn-premium flex-grow-1 rounded-pill py-2 fw-semibold"
                                 @click.stop="$router.push('/product/' + product.id)">
                                 Beli Now
                              </button>
                           </div>
                        </div>
                     </div>

                  </div>
               </div>
            </div>
         </div>

         <div v-else class="text-center py-5">
            <i class="bi bi-box-seam display-1 text-secondary opacity-25 mb-3 d-block"></i>
            <p class="text-secondary fs-5">Belum ada produk unggulan.</p>
         </div>

         <div class="text-center mt-5 pt-4" v-if="featuredProducts.length">
            <button @click="$router.push('/products')"
               class="btn-premium rounded-pill px-5 py-3 fs-5 d-inline-flex align-items-center gap-2">
               Eksplorasi Semua <i class="bi bi-arrow-right"></i>
            </button>
         </div>
      </div>
   </section>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'

const { $api, $router }: any = useNuxtApp()

const featuredProducts = ref([])
const pending = ref(true)
const error = ref(null)

onMounted(async () => {
   pending.value = true
   error.value = null
   try {
      const res = await $api('/api/v1/top-products')
      featuredProducts.value = res.data.products.map(product => ({
         id: product._id,
         name: product.name,
         price: product.price,
         imageUrl: product.imageUrl,
         description: product.description,
         label: product.label,
         sales: product.sales
      }))
   } catch (err) {
      error.value = 'Gagal memuat produk unggulan'
   } finally {
      pending.value = false
   }
})

const formatCurrency = value => {
   if (!value) return '0'
   return Number(value).toLocaleString('id-ID')
}

const formatDescription = (description) => {
   if (!description) return ''
   return description
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/(\r\n|\n)/g, '<br>')
}

const handleImageError = event => {
   event.target.src = 'https://via.placeholder.com/600x400?text=Image+Unavailable'
}
</script>

<style scoped>
.featured-section {
   padding: 8rem 0;
   position: relative;
}

/* Helpers */
.fw-black {
   font-weight: 900;
}

.tracking-wider {
   letter-spacing: 0.1em;
}

.text-truncate-2 {
   display: -webkit-box;
   -webkit-line-clamp: 2;
   -webkit-box-orient: vertical;
   overflow: hidden;
}

.text-gradient {
   background: linear-gradient(135deg, #a78bfa, #60a5fa);
   -webkit-background-clip: text;
   -webkit-text-fill-color: transparent;
   background-clip: text;
}

/* Alert */
.custom-alert-danger {
   background: rgba(239, 68, 68, 0.1);
   border: 1px solid rgba(239, 68, 68, 0.2);
   color: #ef4444;
   border-radius: 16px;
}

/* Premium Card (Glassmorphism + Smooth Shadows) */
.premium-card {
   background: var(--app-card-bg);
   border: 1px solid var(--app-border-color);
   border-radius: 24px;
   overflow: hidden;
   cursor: pointer;
   transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
   box-shadow: 0 10px 30px rgba(0, 0, 0, 0.03);
}

.dark-mode .premium-card {
   box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
}

.premium-card:hover {
   transform: translateY(-10px);
   border-color: rgba(139, 92, 246, 0.5);
   box-shadow: 0 20px 40px rgba(139, 92, 246, 0.15);
}

/* Image Wrapper */
.premium-image-wrapper {
   position: relative;
   width: 100%;
   padding-top: 65%;
   /* 16:9 approx */
   overflow: hidden;
   background: var(--app-surface);
}

.premium-image {
   position: absolute;
   top: 0;
   left: 0;
   width: 100%;
   height: 100%;
   object-fit: cover;
   transition: transform 0.6s cubic-bezier(0.16, 1, 0.3, 1);
}

.premium-card:hover .premium-image {
   transform: scale(1.08);
}

.image-overlay {
   position: absolute;
   inset: 0;
   background: rgba(0, 0, 0, 0.4);
   opacity: 0;
   backdrop-filter: blur(2px);
   transition: all 0.4s ease;
}

.premium-card:hover .image-overlay {
   opacity: 1;
}

/* Buttons inside overlay */
.btn-glass-light {
   background: rgba(255, 255, 255, 0.9);
   color: #111;
   border: none;
   transform: translateY(20px);
   transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
}

.premium-card:hover .btn-glass-light {
   transform: translateY(0);
}

.btn-glass-light:hover {
   background: #fff;
   box-shadow: 0 0 20px rgba(255, 255, 255, 0.5);
}

/* Floating Badges */
.badge-float {
   position: absolute;
   z-index: 2;
}

.top-left {
   top: 1rem;
   left: 1rem;
}

.bottom-right {
   bottom: 1rem;
   right: 1rem;
}

.glow-badge {
   background: linear-gradient(135deg, #f43f5e, #fb7185);
   color: white;
   padding: 0.4rem 1rem;
   border-radius: 50px;
   font-size: 0.75rem;
   font-weight: 700;
   letter-spacing: 0.5px;
   box-shadow: 0 4px 15px rgba(244, 63, 94, 0.4);
}

.dark-badge {
   background: rgba(15, 23, 42, 0.85);
   backdrop-filter: blur(8px);
   color: white;
   padding: 0.4rem 0.8rem;
   border-radius: 12px;
   font-size: 0.75rem;
   font-weight: 600;
   border: 1px solid rgba(255, 255, 255, 0.1);
}

/* Corner Icon Button */
.icon-btn-circle {
   width: 45px;
   height: 45px;
   border-radius: 50%;
   background: var(--app-surface);
   border: 1px solid var(--app-border-color);
   display: flex;
   align-items: center;
   justify-content: center;
   transition: all 0.3s ease;
   color: var(--app-text-color);
}

.premium-card:hover .icon-btn-circle {
   background: linear-gradient(135deg, #8b5cf6, #3b82f6);
   color: white;
   border-color: transparent;
   transform: rotate(45deg);
}

/* Big Button */
.btn-premium {
   background: linear-gradient(135deg, #8b5cf6, #3b82f6);
   color: white;
   border: none;
   font-weight: 700;
   transition: all 0.3s ease;
   box-shadow: 0 10px 25px rgba(139, 92, 246, 0.3);
}

.btn-premium:hover {
   transform: translateY(-3px) scale(1.02);
   box-shadow: 0 15px 35px rgba(139, 92, 246, 0.4);
}

/* Animations */
.animate-slide-up {
   animation: slideUp 0.8s cubic-bezier(0.16, 1, 0.3, 1) both;
}

@keyframes slideUp {
   0% {
      opacity: 0;
      transform: translateY(40px);
   }

   100% {
      opacity: 1;
      transform: translateY(0);
   }
}

.product-slider-container {
   width: 100%;
}

.product-slider {
   overflow-x: auto;
   scroll-snap-type: x mandatory;
   -webkit-overflow-scrolling: touch;
}

.product-slider::-webkit-scrollbar {
   display: none;
}

.product-slide-item {
   width: 85%;
   scroll-snap-align: center;
}

@media (min-width: 768px) {
   .product-slide-item {
      width: 45%;
   }
}

@media (min-width: 992px) {
   .product-slide-item {
      width: 31%;
   }
}
</style>

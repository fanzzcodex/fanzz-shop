<template>
   <section id="purchase-process" class="process-section">
      <div class="container">
         <div class="section-header text-center mb-5">
            <div class="badge-pill-section mb-3">
               <i class="bi bi-cart-check me-2"></i>
               <span>Cara Pembelian</span>
            </div>
            <h2 class="display-5 fw-bold mb-3">Proses Pembelian</h2>
            <p class="lead text-muted mx-auto" style="max-width: 600px;">
               Hanya dengan 4 langkah sederhana untuk mendapatkan produk.
            </p>
         </div>

         <div class="row g-4">
            <div class="col-lg-3 col-md-6">
               <div class="process-card">
                  <div class="process-number">01</div>
                  <div class="process-icon">
                     <i class="bi bi-person-check"></i>
                  </div>
                  <h5 class="process-title">Login / Daftar</h5>
                  <p class="process-description">
                     Masuk atau mendaftar jika belum mempunyai akun untuk melanjutkan proses.
                  </p>
               </div>
            </div>

            <div class="col-lg-3 col-md-6">
               <div class="process-card">
                  <div class="process-number">02</div>
                  <div class="process-icon">
                     <i class="bi bi-box-seam"></i>
                  </div>
                  <h5 class="process-title">Pesan Online</h5>
                  <p class="process-description">
                     Pilih produk, baca deskripsi produk dan ikuti instruksi dilayar.
                  </p>
               </div>
            </div>

            <div class="col-lg-3 col-md-6">
               <div class="process-card">
                  <div class="process-number">03</div>
                  <div class="process-icon">
                     <i class="bi bi-credit-card"></i>
                  </div>
                  <h5 class="process-title">Pembayaran</h5>
                  <p class="process-description">
                     Lakukan pembayaran melalui metode yang tersedia dengan aman dan cepat.
                  </p>
               </div>
            </div>

            <div class="col-lg-3 col-md-6">
               <div class="process-card">
                  <div class="process-number">04</div>
                  <div class="process-icon">
                     <i class="bi bi-download"></i>
                  </div>
                  <h5 class="process-title">Unduh Produk</h5>
                  <p class="process-description">
                     Download file atau hubungi admin melalui kontak yang tersedia di website ini.
                  </p>
               </div>
            </div>
         </div>
      </div>
   </section>
</template>

<style scoped>
.process-section {
   padding: 6rem 0;
}

.badge-pill-section {
   display: inline-flex;
   align-items: center;
   padding: 0.5rem 1.25rem;
   background: linear-gradient(135deg, rgba(139, 92, 246, 0.1), rgba(59, 130, 246, 0.1));
   color: var(--primary-gradient-start);
   border-radius: 50px;
   font-weight: 600;
   font-size: 0.875rem;
   border: 1px solid rgba(139, 92, 246, 0.2);
}

.process-card {
   position: relative;
   background: var(--app-card-bg);
   border: 1px solid var(--app-border-color);
   border-radius: 16px;
   padding: 2rem;
   height: 100%;
   transition: all 0.3s ease;
   overflow: hidden;
}

.process-card::before {
   content: '';
   position: absolute;
   top: 0;
   left: 0;
   right: 0;
   height: 4px;
   background: var(--gradient-primary);
   transform: scaleX(0);
   transition: transform 0.3s ease;
}

.process-card:hover::before {
   transform: scaleX(1);
}

.process-card:hover {
   transform: translateY(-8px);
   box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
   border-color: var(--primary-gradient-start);
}

.process-number {
   position: absolute;
   top: 1rem;
   right: 1rem;
   font-size: 3rem;
   font-weight: 800;
   background: var(--gradient-primary);
   -webkit-background-clip: text;
   -webkit-text-fill-color: transparent;
   background-clip: text;
   opacity: 0.2;
}

.process-icon {
   width: 64px;
   height: 64px;
   border-radius: 16px;
   background: linear-gradient(135deg, rgba(139, 92, 246, 0.1), rgba(59, 130, 246, 0.1));
   display: flex;
   align-items: center;
   justify-content: center;
   margin-bottom: 1.5rem;
}

.process-icon i {
   font-size: 2rem;
   background: var(--gradient-primary);
   -webkit-background-clip: text;
   -webkit-text-fill-color: transparent;
   background-clip: text;
}

.process-title {
   font-size: 1.25rem;
   font-weight: 700;
   color: var(--app-text-color);
   margin-bottom: 0.75rem;
}

.process-description {
   color: var(--app-secondary-text-color);
   line-height: 1.6;
   margin: 0;
}

@media (max-width: 768px) {
   .process-section {
      padding: 4rem 0;
   }
   
   .process-card {
      padding: 1.5rem;
   }
}
</style>
<template>
   <div class="buy-card-modern card-3d">
      <div class="price-header mb-4">
         <div class="price-badge">
            <span class="price-label">Harga</span>
            <h3 class="price-main gradient-text mb-0">{{ formatCurrencyV2(product.price) }}</h3>
         </div>
         <div v-if="product.original_price" class="discount-badge">
            <i class="bi bi-tag-fill me-1"></i>
            <span class="original-price">{{ formatCurrencyV2(product.original_price) }}</span>
         </div>
      </div>

      <form id="purchase-form" @submit.prevent="handleBuy(product._id)">
         <div v-if="purchaseFormData.length" class="mb-4">
            <div class="section-header mb-3">
               <i class="bi bi-clipboard-check me-2"></i>
               <h5 class="mb-0">Lengkapi Data Pesanan</h5>
            </div>
            <div v-for="(info, index) in purchaseFormData" :key="index" class="form-group-modern mb-3">
               <label :for="`info-${index}`" class="form-label-modern">{{ info.name }}</label>
               <input type="text" class="form-control-modern" :id="`info-${index}`" v-model="info.value"
                  :placeholder="`Masukkan ${info.name}`" required />
            </div>
         </div>
      </form>

      <div class="payment-breakdown mb-3">
         <div class="breakdown-item">
            <span class="breakdown-label">
               <i class="bi bi-box-seam me-2"></i>Harga Produk
            </span>
            <span class="breakdown-value">{{ formatCurrencyV2(product.price) }}</span>
         </div>
         <div class="breakdown-item">
            <span class="breakdown-label">
               <i class="bi bi-shield-check me-2"></i>Biaya Layanan
            </span>
            <span class="breakdown-value">{{ formatCurrencyV2(platformFee) }}</span>
         </div>
      </div>

      <div class="total-section mb-4">
         <span class="total-label">Total Bayar</span>
         <span class="total-value gradient-text">{{ formatCurrencyV2(totalPrice) }}</span>
      </div>

      <div class="stock-indicator-modern mb-4">
         <template v-if="product.stock === -1">
            <div class="stock-badge stock-available">
               <i class="bi bi-infinity me-2"></i>Stok Unlimited
            </div>
         </template>
         <template v-else-if="product.stock > 0">
            <div class="stock-badge stock-available">
               <i class="bi bi-check-circle-fill me-2"></i>Tersedia
            </div>
            <span class="stock-counter">({{ product.stock }} tersisa)</span>
         </template>
         <template v-else>
            <div class="stock-badge stock-empty">
               <i class="bi bi-x-circle-fill me-2"></i>Stok Habis
            </div>
         </template>
      </div>

      <div class="action-buttons position-relative">
         <button type="button" class="btn-contact-modern" @click.prevent="showContactPopup = !showContactPopup"
            title="Hubungi CS">
            <i class="bi bi-headset"></i>
         </button>

         <button type="submit" form="purchase-form" :disabled="isLoading || product.stock === 0" class="btn-buy-modern">
            <span v-if="isLoading" class="spinner-border spinner-border-sm me-2"></span>
            <span v-else-if="product.stock === 0"><i class="bi bi-x-circle me-2"></i>Tidak Tersedia</span>
            <span v-else><i class="bi bi-cart-check me-2"></i>Beli Sekarang</span>
         </button>

         <!-- Contact CS Popup Modal -->
         <Transition name="fade">
            <div v-if="showContactPopup" class="contact-modal shadow-lg">
               <div
                  class="contact-modal-header border-bottom border-light border-opacity-25 pb-2 mb-3 d-flex justify-content-between align-items-center">
                  <span class="fw-bold small text-uppercase tracking-wider">Pilih Kontak</span>
                  <button type="button" class="btn-close-compact" @click="showContactPopup = false"><i
                        class="bi bi-x"></i></button>
               </div>
               <div class="d-flex flex-column gap-2">
                  <a :href="waUrl" target="_blank" class="contact-option wa-option">
                     <i class="bi bi-whatsapp fs-5"></i> <span>WhatsApp Admin</span>
                  </a>
                  <a :href="telegramUrl" target="_blank" class="contact-option tele-option">
                     <i class="bi bi-telegram fs-5"></i> <span>Telegram Admin</span>
                  </a>
               </div>
            </div>
         </Transition>
      </div>
   </div>
</template>

<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import { formatCurrencyV2 } from '~/utils'
import Swal from 'sweetalert2'

const config = useRuntimeConfig()
const { $api }: any = useNuxtApp()

interface Product {
   _id: number | string
   name: string
   price: number
   original_price?: number
   additional_information?: any
   stock: number
}

interface PurchaseInfo {
   name: string
   value: string
}

const props = defineProps<{ product: Product }>()

const isLoading = ref(false)
const purchaseFormData = ref<PurchaseInfo[]>([])
const showContactPopup = ref(false)

const waUrl = computed(() => {
   const contacts = config.public.contacts as any[]
   const wa = contacts?.find(c => c.name === 'WhatsApp')
   return wa ? wa.url : '#'
})

const telegramUrl = computed(() => {
   const contacts = config.public.contacts as any[]
   const tele = contacts?.find(c => c.name === 'Telegram')
   return tele ? tele.url : '#'
})

watch(() => props.product, newProduct => {
   purchaseFormData.value = []
   if (!newProduct?.additional_information) return

   let rawData = newProduct.additional_information

   try {
      let parsedData = []

      if (typeof rawData === 'string') {
         parsedData = JSON.parse(rawData)
      } else if (Array.isArray(rawData)) {
         parsedData = rawData
      }

      if (Array.isArray(parsedData)) {
         purchaseFormData.value = parsedData.map(info => ({
            name: info.name,
            value: ''
         }))
      }
   } catch (e) {
      console.error('Gagal memproses additional_information:', e)
   }
}, { immediate: true, deep: true })

const calculatePricingDetails = (base: number, taxPercent: number) => {
   const tax = base * (taxPercent / 100)
   return { tax: Number(Math.round(tax)?.toFixed(0)), total: base + tax }
}

const platformFee = computed(() => calculatePricingDetails(props.product.price, config.public.tax as number).tax)
const totalPrice = computed(() => Number(props.product.price) + Number(platformFee.value))

const handleBuy = async (productId: number | string) => {
   if (props.product.stock === 0) {
      Swal.fire({ icon: 'error', text: 'Maaf, stok produk ini telah habis.' })
      return
   }

   for (const info of purchaseFormData.value) {
      if (!info.value.trim()) {
         Swal.fire({ icon: 'warning', text: `Harap isi kolom "${info.name}" terlebih dahulu.` })
         return
      }
   }

   isLoading.value = true
   try {
      const res = await $api('/api/v1/checkout', {
         method: 'POST',
         body: {
            item: productId,
            additional_information: purchaseFormData.value
         }
      })
      if (!res.status) throw new Error(res.msg)
      purchaseFormData.value.forEach(info => info.value = '')
      await navigateTo(res.data.redirect)
   } catch (error: any) {
      const msg = error?.data?.msg || 'Terjadi kesalahan yang tidak diketahui. Silakan coba lagi.'
      Swal.fire({ icon: 'error', text: msg })
   } finally {
      isLoading.value = false
   }
}
</script>

<style scoped>
.buy-card-modern {
   background: var(--app-card-bg);
   border: 1px solid var(--app-border-color);
   border-radius: 20px;
   padding: 2rem;
   position: relative;
   transition: all 0.4s cubic-bezier(0.23, 1, 0.32, 1);
}

.buy-card-modern:hover {
   transform: translateY(-8px);
   box-shadow: 0 20px 40px rgba(139, 92, 246, 0.2);
}

.price-header {
   display: flex;
   justify-content: space-between;
   align-items: flex-start;
   padding-bottom: 1.5rem;
   border-bottom: 2px solid var(--app-border-color);
}

.price-badge {
   flex: 1;
}

.price-label {
   display: block;
   font-size: 0.75rem;
   color: var(--app-secondary-text-color);
   text-transform: uppercase;
   letter-spacing: 0.05em;
   font-weight: 700;
   margin-bottom: 0.5rem;
}

.price-main {
   font-size: 2rem;
   font-weight: 800;
   line-height: 1;
}

.discount-badge {
   display: flex;
   align-items: center;
   gap: 0.5rem;
   padding: 0.5rem 1rem;
   background: rgba(239, 68, 68, 0.1);
   color: #ef4444;
   border-radius: 12px;
   font-size: 0.875rem;
   font-weight: 600;
}

.original-price {
   text-decoration: line-through;
}

.section-header {
   display: flex;
   align-items: center;
   color: var(--app-text-color);
   font-weight: 700;
}

.form-group-modern {
   position: relative;
}

.form-label-modern {
   display: block;
   font-size: 0.875rem;
   font-weight: 600;
   color: var(--app-text-color);
   margin-bottom: 0.5rem;
}

.form-control-modern {
   width: 100%;
   padding: 0.875rem 1rem;
   background: var(--app-surface);
   border: 2px solid var(--app-border-color);
   border-radius: 12px;
   color: var(--app-text-color);
   font-size: 0.9375rem;
   transition: all 0.3s ease;
}

.form-control-modern:focus {
   outline: none;
   border-color: var(--primary-gradient-start);
   box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.1);
}

.payment-breakdown {
   padding: 1.5rem 0;
   border-bottom: 1px solid var(--app-border-color);
}

.breakdown-item {
   display: flex;
   justify-content: space-between;
   align-items: center;
   padding: 0.75rem 0;
}

.breakdown-label {
   display: flex;
   align-items: center;
   color: var(--app-secondary-text-color);
   font-size: 0.9375rem;
}

.breakdown-value {
   font-weight: 600;
   color: var(--app-text-color);
}

.total-section {
   display: flex;
   justify-content: space-between;
   align-items: center;
   padding: 1.5rem;
   background: linear-gradient(135deg, rgba(139, 92, 246, 0.05), rgba(59, 130, 246, 0.05));
   border-radius: 16px;
   border: 1px solid rgba(139, 92, 246, 0.2);
}

.total-label {
   font-size: 0.875rem;
   font-weight: 700;
   color: var(--app-text-color);
   text-transform: uppercase;
   letter-spacing: 0.05em;
}

.total-value {
   font-size: 1.75rem;
   font-weight: 800;
}

.stock-indicator-modern {
   display: flex;
   align-items: center;
   gap: 0.75rem;
}

.stock-badge {
   display: inline-flex;
   align-items: center;
   padding: 0.625rem 1.25rem;
   border-radius: 12px;
   font-size: 0.875rem;
   font-weight: 700;
}

.stock-available {
   background: rgba(34, 197, 94, 0.1);
   color: #22c55e;
}

.stock-empty {
   background: rgba(239, 68, 68, 0.1);
   color: #ef4444;
}

.stock-counter {
   color: var(--app-secondary-text-color);
   font-size: 0.875rem;
}

.action-buttons {
   display: flex;
   gap: 0.75rem;
}

.btn-contact-modern {
   width: 56px;
   height: 56px;
   border-radius: 16px;
   border: 2px solid rgba(139, 92, 246, 0.4);
   background: rgba(139, 92, 246, 0.1);
   color: #8b5cf6;
   font-size: 1.5rem;
   display: flex;
   align-items: center;
   justify-content: center;
   cursor: pointer;
   transition: all 0.3s ease;
}

.btn-contact-modern:hover {
   background: #8b5cf6;
   color: white;
   transform: scale(1.1) rotate(10deg);
   box-shadow: 0 8px 20px rgba(139, 92, 246, 0.4);
}

.contact-modal {
   position: absolute;
   bottom: 110%;
   left: 0;
   background: var(--app-card-bg);
   border: 1px solid var(--app-border-color);
   border-radius: 16px;
   padding: 1rem;
   width: 100%;
   min-width: 200px;
   z-index: 100;
   backdrop-filter: blur(10px);
}

.btn-close-compact {
   background: transparent;
   border: none;
   color: var(--app-text-color);
   font-size: 1.25rem;
   line-height: 1;
   cursor: pointer;
   padding: 0;
   transition: transform 0.2s;
}

.btn-close-compact:hover {
   transform: scale(1.1);
   color: #ef4444;
}

.contact-option {
   display: flex;
   align-items: center;
   gap: 0.75rem;
   padding: 0.75rem 1rem;
   border-radius: 12px;
   text-decoration: none;
   font-weight: 600;
   transition: all 0.3s ease;
   border: 1px solid transparent;
}

.contact-option.wa-option {
   background: rgba(37, 211, 102, 0.05);
   color: #25d366;
   border-color: rgba(37, 211, 102, 0.1);
}

.contact-option.wa-option:hover {
   background: #25d366;
   color: white;
   box-shadow: 0 4px 15px rgba(37, 211, 102, 0.3);
}

.contact-option.tele-option {
   background: rgba(0, 136, 204, 0.05);
   color: #0088cc;
   border-color: rgba(0, 136, 204, 0.1);
}

.contact-option.tele-option:hover {
   background: #0088cc;
   color: white;
   box-shadow: 0 4px 15px rgba(0, 136, 204, 0.3);
}

.btn-buy-modern {
   flex: 1;
   height: 56px;
   border-radius: 16px;
   border: none;
   background: var(--gradient-primary);
   color: white;
   font-size: 1rem;
   font-weight: 700;
   display: flex;
   align-items: center;
   justify-content: center;
   cursor: pointer;
   transition: all 0.3s ease;
   box-shadow: 0 4px 15px rgba(139, 92, 246, 0.4);
}

.btn-buy-modern:hover:not(:disabled) {
   transform: translateY(-2px);
   box-shadow: 0 8px 25px rgba(139, 92, 246, 0.5);
}

.btn-buy-modern:disabled {
   opacity: 0.6;
   cursor: not-allowed;
   transform: none;
}

@media (max-width: 992px) {
   .buy-card-modern {
      position: relative;
      top: 0;
   }
}
</style>
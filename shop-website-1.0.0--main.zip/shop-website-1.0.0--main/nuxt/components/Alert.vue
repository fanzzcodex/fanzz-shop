<template>
   <transition name="slide-down">
      <div v-if="show" class="alert-modern" :class="`alert-${type}`" role="alert">
         <div class="alert-icon">
            <i v-if="type === 'success'" class="bi bi-check-circle-fill"></i>
            <i v-else-if="type === 'danger'" class="bi bi-x-circle-fill"></i>
            <i v-else-if="type === 'warning'" class="bi bi-exclamation-triangle-fill"></i>
            <i v-else class="bi bi-info-circle-fill"></i>
         </div>
         <div class="alert-content">
            <slot>A default alert message.</slot>
         </div>
      </div>
   </transition>
</template>

<script setup>
const props = defineProps({
   type: {
      type: String,
      default: 'info',
      validator: (val) => ['info', 'danger', 'success', 'warning'].includes(val),
   },
   show: {
      type: Boolean,
      default: true,
   },
})
</script>

<style scoped>
.alert-modern {
   display: flex;
   align-items: center;
   gap: 1rem;
   padding: 1rem 1.5rem;
   border-radius: 12px;
   border: 1px solid;
   backdrop-filter: blur(10px);
   animation: slideIn 0.3s ease-out;
}

.alert-icon {
   font-size: 1.5rem;
   flex-shrink: 0;
}

.alert-content {
   flex: 1;
   font-size: 0.9375rem;
   line-height: 1.5;
}

.alert-success {
   background: rgba(34, 197, 94, 0.1);
   border-color: #22c55e;
   color: #16a34a;
}

.alert-success .alert-icon {
   color: #22c55e;
}

.alert-danger {
   background: rgba(239, 68, 68, 0.1);
   border-color: #ef4444;
   color: #dc2626;
}

.alert-danger .alert-icon {
   color: #ef4444;
}

.alert-warning {
   background: rgba(251, 191, 36, 0.1);
   border-color: #fbbf24;
   color: #d97706;
}

.alert-warning .alert-icon {
   color: #fbbf24;
}

.alert-info {
   background: rgba(59, 130, 246, 0.1);
   border-color: #3b82f6;
   color: #2563eb;
}

.alert-info .alert-icon {
   color: #3b82f6;
}

.slide-down-enter-active,
.slide-down-leave-active {
   transition: all 0.3s ease;
}

.slide-down-enter-from {
   opacity: 0;
   transform: translateY(-20px);
}

.slide-down-leave-to {
   opacity: 0;
   transform: translateY(20px);
}

@keyframes slideIn {
   from {
      opacity: 0;
      transform: translateY(-20px);
   }
   to {
      opacity: 1;
      transform: translateY(0);
   }
}
</style>

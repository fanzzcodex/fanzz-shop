<template>
   <section class="faq-section">
      <div class="container">
         <div class="faq-header">
            <span class="faq-badge">FAQ</span>
            <h2 class="faq-title">Frequently Asked Questions</h2>
            <p class="faq-subtitle">Temukan jawaban atas pertanyaan yang sering ditanyakan</p>
         </div>

         <div class="faq-list">
            <div 
               v-for="(item, index) in faqItems" 
               :key="item.id" 
               class="faq-item"
               :class="{ 'is-open': openIndex === index }"
            >
               <button class="faq-question" @click="toggle(index)">
                  <span class="faq-q-text">{{ item.question }}</span>
                  <span class="faq-toggle">
                     <i class="bi" :class="openIndex === index ? 'bi-dash' : 'bi-plus'"></i>
                  </span>
               </button>
               <Transition name="faq-expand">
                  <div v-show="openIndex === index" class="faq-answer">
                     <p>{{ item.answer }}</p>
                  </div>
               </Transition>
            </div>
         </div>
      </div>
   </section>
</template>

<script setup>
import { ref } from 'vue'

const openIndex = ref(0)

const faqItems = [
   {
      id: 1,
      question: 'Bagaimana cara membeli produk?',
      answer: 'Sebelum membeli produk baca deskripsi terlebih dahulu, pembelian cukup dengan mengklik tombol "Beli" dan ikuti instruksi di layar kemudian setelah selesai membayar dan terjadi kendala silahkan hubungi admin.'
   },
   {
      id: 2,
      question: 'Apakah pembayaran di cek otomatis?',
      answer: 'Ya, pembayaran dicek otomatis oleh sistem jadi pastikan tidak keluar dari halaman invoice. Setelah pembayaran terdeteksi, produk akan langsung dikirim ke akun Anda.'
   },
   {
      id: 3,
      question: 'Metode pembayaran apa yang digunakan?',
      answer: 'Pembayaran melalui QRIS karena lebih fleksibel melakukan pembayaran lewat manapun baik itu bank maupun e-wallet seperti GoPay, OVO, Dana, dan lainnya.'
   },
   {
      id: 4,
      question: 'Apakah ada garansi produk?',
      answer: 'Ya, kami memberikan garansi 7 hari setelah pembelian. Jika produk tidak sesuai deskripsi atau ada kendala teknis, silakan hubungi admin untuk bantuan.'
   },
   {
      id: 5,
      question: 'Bagaimana cara mendapatkan support?',
      answer: 'Anda bisa menghubungi kami melalui WhatsApp, email, atau Instagram. Tim support kami siap membantu 24/7 dengan response time kurang dari 2 jam.'
   }
]

const toggle = (index) => {
   openIndex.value = openIndex.value === index ? -1 : index
}
</script>

<style scoped>
.faq-section {
   padding: 5rem 0;
}

.faq-header {
   text-align: center;
   margin-bottom: 3rem;
}

.faq-badge {
   display: inline-block;
   padding: 0.4rem 1.25rem;
   background: var(--gradient-primary);
   color: white;
   font-size: 0.75rem;
   font-weight: 700;
   letter-spacing: 1.5px;
   border-radius: 50px;
   margin-bottom: 1rem;
}

.faq-title {
   font-size: 2.25rem;
   font-weight: 800;
   color: var(--app-text-color);
   margin-bottom: 0.5rem;
}

.faq-subtitle {
   font-size: 1rem;
   color: var(--app-secondary-text-color);
   margin: 0;
}

.faq-list {
   max-width: 720px;
   margin: 0 auto;
   display: flex;
   flex-direction: column;
   gap: 0.75rem;
}

.faq-item {
   background: var(--app-card-bg);
   border: 1px solid var(--app-border-color);
   border-radius: 14px;
   overflow: hidden;
   transition: all 0.3s ease;
}

.faq-item:hover {
   border-color: var(--primary-gradient-start);
   box-shadow: 0 4px 16px rgba(99, 102, 241, 0.08);
}

.faq-item.is-open {
   border-color: var(--primary-gradient-start);
   box-shadow: 0 8px 24px rgba(99, 102, 241, 0.12);
}

.faq-question {
   width: 100%;
   display: flex;
   align-items: center;
   justify-content: space-between;
   gap: 1rem;
   padding: 1.25rem 1.5rem;
   background: none;
   border: none;
   cursor: pointer;
   text-align: left;
}

.faq-q-text {
   font-size: 1rem;
   font-weight: 600;
   color: var(--app-text-color);
   flex: 1;
   line-height: 1.5;
}

.is-open .faq-q-text {
   color: var(--primary-gradient-start);
}

.faq-toggle {
   width: 32px;
   height: 32px;
   border-radius: 8px;
   background: var(--app-surface);
   display: flex;
   align-items: center;
   justify-content: center;
   color: var(--primary-gradient-start);
   font-size: 1.25rem;
   flex-shrink: 0;
   transition: all 0.3s ease;
}

.is-open .faq-toggle {
   background: var(--primary-gradient-start);
   color: white;
}

.faq-answer {
   padding: 0 1.5rem 1.25rem 1.5rem;
}

.faq-answer p {
   margin: 0;
   font-size: 0.9375rem;
   line-height: 1.7;
   color: var(--app-secondary-text-color);
}

/* Transition */
.faq-expand-enter-active,
.faq-expand-leave-active {
   transition: all 0.3s ease;
   max-height: 200px;
   overflow: hidden;
}

.faq-expand-enter-from,
.faq-expand-leave-to {
   max-height: 0;
   opacity: 0;
   padding-top: 0;
   padding-bottom: 0;
}

@media (max-width: 768px) {
   .faq-title {
      font-size: 1.75rem;
   }
   
   .faq-question {
      padding: 1rem 1.25rem;
   }
   
   .faq-q-text {
      font-size: 0.9375rem;
   }
   
   .faq-answer {
      padding: 0 1.25rem 1rem 1.25rem;
   }
}
</style>

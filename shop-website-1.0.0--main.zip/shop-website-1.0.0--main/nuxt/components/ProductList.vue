<template>
   <div>
      <div v-if="isInitialLoading" class="d-flex flex-column justify-content-center align-items-center py-5 min-vh-50">
         <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="visually-hidden">Loading...</span>
         </div>
         <p class="mt-3 text-secondary tracking-wider fs-5">Mempersiapkan Etalase...</p>
      </div>

      <div v-else-if="error" class="alert alert-glass-danger border-0 d-flex align-items-center gap-3">
         <i class="bi bi-exclamation-triangle-fill fs-3"></i>
         <div>
            <h5 class="mb-1 fw-bold">Terjadi Kesalahan</h5>
            <p class="mb-0">{{ error }}</p>
         </div>
      </div>

      <div v-else class="products-showcase">
         <!-- Featured Product Banner -->
         <div v-if="featuredProduct" class="featured-showcase mb-5">
            <div class="featured-card">
               <div class="row g-0 h-100">
                  <div class="col-lg-7 position-relative overflow-hidden cursor-pointer"
                     @click="viewDetails(featuredProduct._id)">
                     <img
                        :src="featuredProduct.imageUrl || 'https://via.placeholder.com/800x600.png?text=Premium+Product'"
                        class="featured-hero-img w-100 h-100 object-fit-cover" :alt="featuredProduct.name">
                     <div class="featured-img-overlay d-flex flex-column justify-content-end p-4 p-lg-5">
                        <div class="d-flex gap-2 mb-3">
                           <span class="badge-glow-primary"><i class="bi bi-star-fill me-1 text-warning"></i>
                              Unggulan</span>
                           <span v-if="featuredProduct.tag" class="badge-glass">{{ featuredProduct.tag.name }}</span>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-5 d-flex flex-column p-4 p-lg-5 featured-content-area position-relative">
                     <div class="glowing-orb"></div>
                     <div class="flex-grow-1 position-relative z-1" @click="viewDetails(featuredProduct._id)"
                        style="cursor:pointer">
                        <h2 class="display-6 fw-black mb-3 text-gradient">{{ featuredProduct.name }}</h2>
                        <p class="fs-5 text-secondary fst-italic mb-4">{{ createExcerpt(featuredProduct.description,
                           160) }}</p>
                     </div>
                     <div
                        class="mt-auto d-flex flex-column flex-sm-row justify-content-between align-items-sm-end gap-3 position-relative z-1">
                        <div>
                           <span class="text-uppercase small tracking-wider text-secondary fw-bold mb-1 d-block">Harga
                              Spesial</span>
                           <h3 class="mb-0 fw-black fs-2">{{ formatCurrencyV2(featuredProduct.price) }}</h3>
                        </div>
                        <button @click.stop="viewDetails(featuredProduct._id)"
                           class="btn-premium px-4 py-2 rounded-pill d-inline-flex align-items-center gap-2">
                           Detail Spesifikasi <i class="bi bi-arrow-right"></i>
                        </button>
                     </div>
                  </div>
               </div>
            </div>
         </div>

         <div v-if="featuredProduct && products.length > 0" class="showcase-divider my-5">
            <span>Koleksi Lainnya</span>
         </div>

         <!-- Grid of Products -->
         <div v-if="products.length > 0">
            <div class="row row-cols-2 g-3 g-md-4">
               <div v-for="(product, index) in products" :key="product._id" class="col animate-slide-up"
                  :style="{ animationDelay: `${(index % 6) * 0.1}s` }">
                  <div class="glass-product-card h-100 d-flex flex-column" @click="viewDetails(product._id)">
                     <div class="card-img-container">
                        <img :src="product.imageUrl || 'https://via.placeholder.com/600x400.png?text=Product'"
                           class="card-img-top" :alt="product.name">

                        <div
                           class="card-badges top-0 start-0 p-3 w-100 d-flex justify-content-between align-items-start pointer-events-none">
                           <span v-if="product.tag" class="badge-glass-dark">
                              <i class="bi bi-tag-fill me-1"></i>{{ product.tag.name }}
                           </span>
                           <span v-if="product.stock !== -1" class="badge-glass-light shadow-sm">
                              <i class="bi bi-box-seam me-1"></i>{{ product.stock }}
                           </span>
                        </div>

                        <div class="hover-action-overlay">
                           <button class="btn-circle-glass">
                              <i class="bi bi-eye fs-4"></i>
                           </button>
                        </div>
                     </div>

                     <div class="card-info p-4 d-flex flex-column flex-grow-1">
                        <h4 class="fw-bold mb-2 text-truncate-2 flex-grow-0">{{ product.name }}</h4>

                        <div class="stock-status mb-3 flex-grow-0">
                           <span v-if="product.stock === -1" class="status-badge success"><i class="bi bi-infinity"></i>
                              Unlimited</span>
                           <span v-else-if="product.stock > 10" class="status-badge success"><i
                                 class="bi bi-check-circle-fill"></i> Tersedia</span>
                           <span v-else-if="product.stock > 0" class="status-badge warning"><i class="bi bi-fire"></i>
                              Terbatas</span>
                           <span v-else class="status-badge danger"><i class="bi bi-x-circle-fill"></i> Habis</span>
                        </div>

                        <p class="text-secondary small mb-4 flex-grow-1">{{ createExcerpt(product.description, 100) }}
                        </p>

                        <div
                           class="d-flex justify-content-between align-items-end mt-auto pt-3 border-top border-secondary border-opacity-25 relative">
                           <div class="price-container">
                              <span
                                 class="d-block text-uppercase small text-secondary fw-semibold tracking-wider mb-1">Total</span>
                              <div class="d-flex flex-column">
                                 <span class="fs-4 fw-black text-gradient">{{ formatCurrencyV2(product.price) }}</span>
                                 <span v-if="product.original_price"
                                    class="text-decoration-line-through text-secondary small">{{
                                       formatCurrencyV2(product.original_price) }}</span>
                              </div>
                           </div>
                           <button class="btn-circle-action" :disabled="product.stock === 0"
                              @click.stop="viewDetails(product._id)" title="Beli / Lihat Detail">
                              <i class="bi bi-cart-plus-fill"></i>
                           </button>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>

         <!-- Loader & End State -->
         <div ref="loaderRef" class="text-center py-5 mt-4">
            <div v-if="isLoadingMore" class="spinner-grow text-primary" style="width: 2rem; height: 2rem;"
               role="status">
               <span class="visually-hidden">Loading more...</span>
            </div>
         </div>

         <div v-if="!hasMore && products.length > 0 && !isInitialLoading"
            class="text-center text-secondary py-4 tracking-wider small fw-bold text-uppercase">
            <i class="bi bi-check2-all me-2"></i> Semua koleksi telah ditampilkan.
         </div>

         <div v-else-if="!isInitialLoading && products.length === 0 && !featuredProduct" class="text-center py-5">
            <i class="bi bi-inbox display-1 text-secondary opacity-25 mb-3 d-block"></i>
            <p class="text-secondary fs-5">Katalog kosong saat ini.</p>
         </div>
      </div>
   </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted, nextTick } from 'vue'
import { useRouter } from 'vue-router'
import MarkdownIt from 'markdown-it'
import { formatCurrencyV2 } from '~/utils'

const md = new MarkdownIt()
interface Product { _id: number | string; name: string; price: number; original_price?: number; description: string; imageUrl?: string; updated_at?: string; stock: number; tag?: { _id: string; name: string; } }

const router = useRouter()
const { $api }: any = useNuxtApp()
const featuredProduct = ref<Product | null>(null)
const products = ref<Product[]>([])
const isInitialLoading = ref(true)
const isLoadingMore = ref(false)
const error = ref<string | null>(null)
const page = ref(1)
const hasMore = ref(true)
const ITEMS_PER_PAGE = 6
const loaderRef = ref<Element | null>(null)
let observer: IntersectionObserver

const createExcerpt = (markdownContent: string, maxLength: number = 150): string => {
   if (!markdownContent) return ''
   const htmlContent = md.render(markdownContent)
   const plainText = htmlContent.replace(/<[^>]*>?/gm, '')
   if (plainText.length <= maxLength) return plainText
   const truncated = plainText.substring(0, maxLength)
   const lastSpaceIndex = truncated.lastIndexOf(' ')
   return (lastSpaceIndex > 0 ? truncated.substring(0, lastSpaceIndex) : truncated) + '...'
}

const viewDetails = (productId: number | string) => router.push(`/product/${productId}`)

const sortProductsByStock = (prods: Product[]) => {
   return prods.sort((a, b) => {
      const getPrio = (s: number) => s === -1 ? 999999999 : s;
      return getPrio(b.stock) - getPrio(a.stock);
   })
}

const fetchProducts = async () => {
   if (isLoadingMore.value || !hasMore.value) return
   isLoadingMore.value = true
   try {
      const response = await $api('/api/v1/products', { params: { page: page.value, limit: ITEMS_PER_PAGE } })
      if (response && response.status && Array.isArray(response.data.products) && response.data.products.length > 0) {
         const newProducts = response.data.products.filter((p: Product) => p._id !== featuredProduct.value?._id)
         products.value = sortProductsByStock([...products.value, ...newProducts])
         page.value++
         if (response.data.products.length < ITEMS_PER_PAGE) hasMore.value = false
      } else { hasMore.value = false }
   } catch (e: any) {
      error.value = e.message || 'Error.'
      hasMore.value = false
   } finally { isLoadingMore.value = false }
}

const setupObserver = () => {
   if (observer) observer.disconnect()
   const options = { rootMargin: '200px', threshold: 0 }
   observer = new IntersectionObserver((entries) => {
      const [entry] = entries
      if (entry.isIntersecting && !isLoadingMore.value) fetchProducts()
   }, options)
   if (loaderRef.value) observer.observe(loaderRef.value)
}

onMounted(async () => {
   isInitialLoading.value = true
   error.value = null
   try {
      const [featuredResponse, productsResponse] = await Promise.all([
         $api('/api/v1/products/featured'),
         $api('/api/v1/products', { params: { page: 1, limit: ITEMS_PER_PAGE } })
      ])
      if (featuredResponse && featuredResponse.status && featuredResponse.data) {
         featuredProduct.value = featuredResponse.data
      }

      if (productsResponse && productsResponse.status && Array.isArray(productsResponse.data.products)) {
         if (!featuredProduct.value && productsResponse.data.products.length > 0) {
            featuredProduct.value = productsResponse.data.products[0];
         }
         const prods = productsResponse.data.products.filter((p: Product) => p._id !== featuredProduct.value?._id)
         products.value = sortProductsByStock(prods)
         page.value = 2
         const totalInitialProducts = products.value.length + (featuredProduct.value ? 1 : 0)
         if (productsResponse.data.products.length < ITEMS_PER_PAGE || totalInitialProducts >= productsResponse.data.total) hasMore.value = false
      } else { hasMore.value = false }
   } catch (e: any) {
      error.value = e.message || 'Gagal memuat data produk.'
   } finally {
      isInitialLoading.value = false
      if (hasMore.value) {
         await nextTick()
         setupObserver()
      }
   }
})

onUnmounted(() => { if (observer) observer.disconnect() })
</script>

<style scoped>
/* Utilities */
.fw-black {
   font-weight: 900;
}

.tracking-wider {
   letter-spacing: 0.1em;
}

.text-truncate-2 {
   display: -webkit-box;
   -webkit-line-clamp: 2;
   -webkit-box-orient: vertical;
   overflow: hidden;
}

.text-gradient {
   background: linear-gradient(135deg, #a78bfa, #60a5fa);
   -webkit-background-clip: text;
   -webkit-text-fill-color: transparent;
   background-clip: text;
}

.alert-glass-danger {
   background: rgba(239, 68, 68, 0.1);
   backdrop-filter: blur(10px);
   border-left: 4px solid #ef4444 !important;
   color: #ef4444;
}

/* Featured Card */
.featured-card {
   background: var(--app-card-bg);
   border-radius: 24px;
   border: 1px solid var(--app-border-color);
   overflow: hidden;
   box-shadow: 0 20px 50px rgba(0, 0, 0, 0.05);
   transition: box-shadow 0.4s ease;
}

.dark-mode .featured-card {
   box-shadow: 0 20px 50px rgba(0, 0, 0, 0.3);
}

.featured-card:hover {
   box-shadow: 0 30px 60px rgba(139, 92, 246, 0.15);
   border-color: rgba(139, 92, 246, 0.4);
}

.featured-hero-img {
   transition: transform 0.8s cubic-bezier(0.16, 1, 0.3, 1);
}

.featured-card:hover .featured-hero-img {
   transform: scale(1.05);
}

.featured-img-overlay {
   position: absolute;
   inset: 0;
   background: linear-gradient(to top, rgba(0, 0, 0, 0.7) 0%, transparent 60%);
   pointer-events: none;
}

.featured-content-area {
   background: var(--app-card-bg);
   backdrop-filter: blur(20px);
}

.glowing-orb {
   position: absolute;
   width: 200px;
   height: 200px;
   background: radial-gradient(circle, rgba(139, 92, 246, 0.2) 0%, transparent 70%);
   top: 50%;
   left: 50%;
   transform: translate(-50%, -50%);
   border-radius: 50%;
   filter: blur(30px);
   z-index: 0;
}

.btn-premium {
   background: linear-gradient(135deg, #8b5cf6, #3b82f6);
   color: white;
   border: none;
   font-weight: 700;
   transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.btn-premium:hover {
   transform: translateY(-2px);
   box-shadow: 0 10px 25px rgba(139, 92, 246, 0.4);
   color: white;
}

/* Badges */
.badge-glow-primary {
   background: linear-gradient(135deg, #8b5cf6, #3b82f6);
   color: white;
   padding: 0.4rem 1rem;
   border-radius: 50px;
   font-size: 0.75rem;
   font-weight: 700;
   letter-spacing: 1px;
   box-shadow: 0 4px 15px rgba(139, 92, 246, 0.4);
}

.badge-glass {
   background: rgba(255, 255, 255, 0.2);
   backdrop-filter: blur(5px);
   color: white;
   border: 1px solid rgba(255, 255, 255, 0.4);
   padding: 0.4rem 1rem;
   border-radius: 50px;
   font-size: 0.75rem;
   font-weight: 600;
}

/* Divider */
.showcase-divider {
   text-align: center;
   position: relative;
}

.showcase-divider::before {
   content: "";
   position: absolute;
   top: 50%;
   left: 0;
   right: 0;
   height: 1px;
   background: linear-gradient(90deg, transparent, var(--app-border-color), transparent);
}

.showcase-divider span {
   background: var(--app-bg);
   padding: 0 1.5rem;
   position: relative;
   z-index: 1;
   color: var(--app-secondary-text-color);
   font-weight: 700;
   text-transform: uppercase;
   letter-spacing: 2px;
   font-size: 0.8rem;
}

/* Grid Cards */
.glass-product-card {
   background: var(--app-card-bg);
   border: 1px solid var(--app-border-color);
   border-radius: 20px;
   overflow: hidden;
   cursor: pointer;
   transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
   box-shadow: 0 10px 30px rgba(0, 0, 0, 0.03);
   position: relative;
}

.dark-mode .glass-product-card {
   box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
}

.glass-product-card:hover {
   transform: translateY(-8px);
   border-color: rgba(139, 92, 246, 0.6);
   box-shadow: 0 20px 40px rgba(139, 92, 246, 0.15);
}

.card-img-container {
   position: relative;
   width: 100%;
   padding-top: 65%;
   overflow: hidden;
}

.card-img-top {
   position: absolute;
   top: 0;
   left: 0;
   width: 100%;
   height: 100%;
   object-fit: cover;
   transition: transform 0.6s cubic-bezier(0.16, 1, 0.3, 1);
}

.glass-product-card:hover .card-img-top {
   transform: scale(1.08);
}

.card-badges {
   position: absolute;
   z-index: 2;
}

.badge-glass-dark {
   background: rgba(15, 23, 42, 0.8);
   backdrop-filter: blur(8px);
   color: white;
   padding: 0.35rem 0.75rem;
   border-radius: 8px;
   font-size: 0.7rem;
   font-weight: 600;
   border: 1px solid rgba(255, 255, 255, 0.1);
}

.badge-glass-light {
   background: rgba(255, 255, 255, 0.95);
   color: #111;
   padding: 0.35rem 0.75rem;
   border-radius: 8px;
   font-size: 0.7rem;
   font-weight: 700;
}

.hover-action-overlay {
   position: absolute;
   inset: 0;
   background: rgba(0, 0, 0, 0.3);
   backdrop-filter: blur(2px);
   display: flex;
   justify-content: center;
   align-items: center;
   opacity: 0;
   transition: all 0.4s ease;
}

.glass-product-card:hover .hover-action-overlay {
   opacity: 1;
}

.btn-circle-glass {
   width: 60px;
   height: 60px;
   border-radius: 50%;
   border: none;
   background: rgba(255, 255, 255, 0.2);
   color: white;
   border: 1px solid rgba(255, 255, 255, 0.5);
   backdrop-filter: blur(10px);
   display: flex;
   align-items: center;
   justify-content: center;
   transform: scale(0.8);
   transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
}

.glass-product-card:hover .btn-circle-glass {
   transform: scale(1);
}

.btn-circle-glass:hover {
   background: white;
   color: black;
}

.status-badge {
   display: inline-flex;
   align-items: center;
   gap: 0.25rem;
   padding: 0.3rem 0.6rem;
   border-radius: 6px;
   font-size: 0.65rem;
   font-weight: 700;
   text-transform: uppercase;
   letter-spacing: 0.05em;
}

.status-badge.success {
   background: rgba(16, 185, 129, 0.1);
   color: #10b981;
}

.status-badge.warning {
   background: rgba(245, 158, 11, 0.1);
   color: #f59e0b;
}

.status-badge.danger {
   background: rgba(239, 68, 68, 0.1);
   color: #ef4444;
}

.btn-circle-action {
   width: 44px;
   height: 44px;
   border-radius: 50%;
   border: 1px solid var(--app-border-color);
   background: var(--app-surface);
   color: var(--app-text-color);
   font-size: 1.2rem;
   display: flex;
   align-items: center;
   justify-content: center;
   transition: all 0.3s ease;
}

.glass-product-card:hover .btn-circle-action {
   background: linear-gradient(135deg, #8b5cf6, #3b82f6);
   color: white;
   border-color: transparent;
   transform: rotate(45deg);
}

.animate-slide-up {
   animation: slideUp 0.8s cubic-bezier(0.16, 1, 0.3, 1) both;
}

@keyframes slideUp {
   0% {
      opacity: 0;
      transform: translateY(40px);
   }

   100% {
      opacity: 1;
      transform: translateY(0);
   }
}
</style>
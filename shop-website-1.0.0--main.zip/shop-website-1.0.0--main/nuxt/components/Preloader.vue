<template>
   <transition name="preloader-exit">
      <div v-if="show" class="preloader-cinema" :class="{ 'exit-stage': exiting }">
         <!-- Particle field -->
         <div class="particle-field">
            <span v-for="n in 24" :key="n" class="particle" :style="particleStyle(n)"></span>
         </div>

         <!-- Orbiting rings -->
         <div class="orbit-system">
            <div class="orbit orbit-outer"></div>
            <div class="orbit orbit-mid"></div>
            <div class="orbit orbit-inner"></div>
            <div class="orbit orbit-dashed"></div>
         </div>

         <!-- Center logo block -->
         <div class="center-block">
            <div class="logo-ring-wrap">
               <div class="logo-ring-gradient"></div>
               <div class="logo-ring-bg"></div>
               <img src="/images/profile-yilzi.jpg" alt="Yilzi" class="logo-avatar" />
            </div>

            <div class="brand-line">
               <span class="brand-hello">Selamat Datang di</span>
            </div>
            <div class="brand-name">
               <span class="gradient-text">Yilzi Shop</span>
            </div>
            <p class="brand-tagline">Premium Digital Products</p>

            <div class="progress-track">
               <div class="progress-fill"></div>
            </div>
         </div>
      </div>
   </transition>
</template>

<script setup lang="ts">
import { ref, onMounted, onBeforeUnmount } from 'vue'

const show = ref(false)
const exiting = ref(false)
let timer: ReturnType<typeof setTimeout> | null = null

const particleStyle = (n: number) => {
   const angle = (n / 24) * 360
   const dist = 140 + Math.random() * 120
   const size = 2 + Math.random() * 3
   const delay = Math.random() * 3
   const dur = 3 + Math.random() * 4
   return {
      '--angle': `${angle}deg`,
      '--dist': `${dist}px`,
      '--size': `${size}px`,
      '--delay': `${delay}s`,
      '--dur': `${dur}s`,
   }
}

onMounted(() => {
   if (process.client) {
      // Check if preloader has been shown this session
      const hasShown = sessionStorage.getItem('preloader_shown')
      
      if (!hasShown) {
         console.log('[v0] Showing entrance animation')
         show.value = true
         sessionStorage.setItem('preloader_shown', 'true')
         
         timer = setTimeout(() => {
            exiting.value = true
            setTimeout(() => { 
               show.value = false 
               console.log('[v0] Entrance animation complete')
            }, 700)
         }, 2600)
      } else {
         console.log('[v0] Preloader already shown this session, skipping')
      }
   }
})

onBeforeUnmount(() => { if (timer) clearTimeout(timer) })
</script>

<style scoped>
/* ===== CINEMATIC PRELOADER ===== */
.preloader-cinema {
   position: fixed;
   inset: 0;
   z-index: 99999999;
   background: var(--app-bg);
   display: flex;
   align-items: center;
   justify-content: center;
   overflow: hidden;
}

/* --- Particles --- */
.particle-field {
   position: absolute;
   inset: 0;
   display: flex;
   align-items: center;
   justify-content: center;
   pointer-events: none;
}

.particle {
   position: absolute;
   width: var(--size);
   height: var(--size);
   border-radius: 50%;
   background: var(--primary-gradient-start);
   opacity: 0;
   animation: particle-drift var(--dur) var(--delay) ease-in-out infinite;
}

@keyframes particle-drift {
   0%   { opacity: 0; transform: rotate(var(--angle)) translateX(60px) scale(0); }
   30%  { opacity: 0.6; }
   70%  { opacity: 0.5; }
   100% { opacity: 0; transform: rotate(var(--angle)) translateX(var(--dist)) scale(1); }
}

/* --- Orbiting Rings --- */
.orbit-system {
   position: absolute;
   width: 340px;
   height: 340px;
   display: flex;
   align-items: center;
   justify-content: center;
   pointer-events: none;
}

.orbit {
   position: absolute;
   border-radius: 50%;
   border: 1.5px solid var(--app-text-color);
}

.orbit-outer {
   width: 100%;
   height: 100%;
   opacity: 0.05;
   border-style: solid;
   animation: orbit-rotate 12s linear infinite;
}
.orbit-mid {
   width: 82%;
   height: 82%;
   opacity: 0.08;
   border-top-color: var(--primary-gradient-start);
   border-right-color: transparent;
   border-bottom-color: var(--primary-gradient-end);
   border-left-color: transparent;
   animation: orbit-rotate 8s linear infinite reverse;
}
.orbit-inner {
   width: 65%;
   height: 65%;
   opacity: 0.04;
   border-style: dotted;
   animation: orbit-rotate 16s linear infinite;
}
.orbit-dashed {
   width: 115%;
   height: 115%;
   opacity: 0.04;
   border-style: dashed;
   animation: orbit-rotate 20s linear infinite reverse;
}

@keyframes orbit-rotate {
   from { transform: rotate(0deg); }
   to   { transform: rotate(360deg); }
}

/* --- Center Block --- */
.center-block {
   position: relative;
   z-index: 2;
   display: flex;
   flex-direction: column;
   align-items: center;
   gap: 0.5rem;
   animation: center-entrance 0.9s cubic-bezier(0.16, 1, 0.3, 1) forwards;
   opacity: 0;
   transform: scale(0.85) translateY(20px);
}

@keyframes center-entrance {
   to { opacity: 1; transform: scale(1) translateY(0); }
}

/* Logo avatar ring */
.logo-ring-wrap {
   position: relative;
   width: 88px;
   height: 88px;
   border-radius: 50%;
   display: flex;
   align-items: center;
   justify-content: center;
   margin-bottom: 0.75rem;
}
.logo-ring-gradient {
   position: absolute;
   inset: -3px;
   border-radius: 50%;
   background: var(--gradient-primary);
   animation: ring-pulse 2.4s ease-in-out infinite;
}
.logo-ring-bg {
   position: absolute;
   inset: 0;
   border-radius: 50%;
   background: var(--app-bg);
}
.logo-avatar {
   width: 72px;
   height: 72px;
   border-radius: 50%;
   object-fit: cover;
   position: relative;
   z-index: 1;
   box-shadow: 0 4px 24px rgba(139, 92, 246, 0.3);
}

@keyframes ring-pulse {
   0%, 100% { opacity: 0.8; transform: scale(1); }
   50%      { opacity: 1;   transform: scale(1.04); }
}

/* Text */
.brand-line {
   animation: text-up 0.7s 0.3s cubic-bezier(0.16, 1, 0.3, 1) both;
}
.brand-hello {
   font-size: 0.875rem;
   font-weight: 500;
   color: var(--app-secondary-text-color);
   letter-spacing: 0.15em;
   text-transform: uppercase;
}

.brand-name {
   animation: text-up 0.7s 0.5s cubic-bezier(0.16, 1, 0.3, 1) both;
}
.brand-name .gradient-text {
   font-size: 2.5rem;
   font-weight: 900;
   letter-spacing: -0.03em;
}

.brand-tagline {
   font-size: 0.8125rem;
   color: var(--app-secondary-text-color);
   letter-spacing: 0.25em;
   text-transform: uppercase;
   animation: text-up 0.7s 0.7s cubic-bezier(0.16, 1, 0.3, 1) both;
   margin-top: 0.125rem;
}

@keyframes text-up {
   from { opacity: 0; transform: translateY(16px); }
   to   { opacity: 1; transform: translateY(0); }
}

/* Progress */
.progress-track {
   width: 180px;
   height: 3px;
   background: var(--app-border-color);
   border-radius: 3px;
   overflow: hidden;
   margin-top: 1.25rem;
   animation: text-up 0.7s 0.9s cubic-bezier(0.16, 1, 0.3, 1) both;
}
.progress-fill {
   height: 100%;
   background: var(--gradient-primary);
   border-radius: 3px;
   animation: progress-run 2.2s 0.4s cubic-bezier(0.4, 0, 0.2, 1) both;
}
@keyframes progress-run {
   from { width: 0; }
   to   { width: 100%; }
}

/* --- Exit --- */
.exit-stage {
   animation: cinema-exit 0.7s cubic-bezier(0.7, 0, 0.3, 1) forwards;
}
@keyframes cinema-exit {
   0%   { opacity: 1; transform: scale(1); filter: blur(0); }
   100% { opacity: 0; transform: scale(1.08); filter: blur(6px); }
}

.preloader-exit-leave-active {
   transition: opacity 0.1s;
}
.preloader-exit-leave-to {
   opacity: 0;
}
</style>

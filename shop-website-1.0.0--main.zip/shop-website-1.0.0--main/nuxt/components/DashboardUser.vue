<template>
   <div class="buyer-dashboard">
      <!-- Header Section with Gradient -->
      <div class="dashboard-hero">
         <div class="hero-gradient-orb orb-1"></div>
         <div class="hero-gradient-orb orb-2"></div>
         <div class="hero-content">
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
               <div class="animate-slide-up">
                  <div class="greeting-badge">
                     <i class="bi bi-stars me-2"></i>
                     <span>Dashboard</span>
                  </div>
                  <h1 v-if="user.name" class="hero-title">Selamat Datang, <span class="gradient-text">{{ user.name
                  }}</span>!</h1>
                  <h1 v-else class="hero-title">Dasbor Anda</h1>
                  <p class="hero-subtitle">Kelola transaksi dan produk digital Anda di satu tempat.</p>
               </div>
               <div class="d-flex gap-2 animate-slide-up" style="animation-delay: 0.1s">
                  <button @click.prevent="$router.push('/dashboard/reviews')" class="btn-explore"
                     style="background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2);">
                     <i class="bi bi-star-fill me-2 text-warning"></i>Ulasan
                  </button>
                  <button @click.prevent="$router.push('/dashboard/profile')" class="btn-explore">
                     <i class="bi bi-person-gear md-2"></i>Edit Profil
                  </button>
               </div>
            </div>
         </div>
      </div>

      <!-- Loading State -->
      <div v-if="isLoading" class="loading-container">
         <div class="loading-pulse">
            <div class="pulse-dot"></div>
            <div class="pulse-dot"></div>
            <div class="pulse-dot"></div>
         </div>
         <p class="loading-text">Memuat dashboard Anda...</p>
      </div>

      <!-- Error State -->
      <div v-else-if="errorMsg" class="glass-card error-card text-center animate-fade-in">
         <div class="error-icon-wrap">
            <i class="bi bi-cloud-slash"></i>
         </div>
         <h5 class="fw-bold mt-3">Gagal Memuat Data</h5>
         <p class="text-secondary">{{ errorMsg }}</p>
         <button @click="fetchInitialData" class="btn-explore mt-2">
            <i class="bi bi-arrow-clockwise me-2"></i>Coba Lagi
         </button>
      </div>

      <!-- Main Content -->
      <div v-else class="dashboard-content">
         <!-- Stats Grid -->
         <div class="stats-grid animate-slide-up" style="animation-delay: 0.15s">
            <div class="stat-card-premium">
               <div class="stat-icon-wrap" style="--icon-gradient: linear-gradient(135deg, #8B5CF6, #A855F7)">
                  <i class="bi bi-wallet2"></i>
               </div>
               <div class="stat-info">
                  <span class="stat-label">Saldo Saat Ini</span>
                  <span class="stat-value">Rp {{ formatCurrency(user.balance || 0) }}</span>
               </div>
               <div class="stat-decoration"></div>
            </div>

            <div class="stat-card-premium">
               <div class="stat-icon-wrap" style="--icon-gradient: linear-gradient(135deg, #3B82F6, #60A5FA)">
                  <i class="bi bi-receipt-cutoff"></i>
               </div>
               <div class="stat-info">
                  <span class="stat-label">Total Transaksi</span>
                  <span class="stat-value">{{ customerStats.totalTransactions }} <small>Transaksi</small></span>
               </div>
               <div class="stat-decoration"></div>
            </div>

            <div class="stat-card-premium">
               <div class="stat-icon-wrap" style="--icon-gradient: linear-gradient(135deg, #06B6D4, #22D3EE)">
                  <i class="bi bi-star"></i>
               </div>
               <div class="stat-info">
                  <span class="stat-label">Peringkat (Rank)</span>
                  <span class="stat-value text-uppercase" style="letter-spacing: 1px;">{{ (user.xp >= 5000 ? 'Sultan' :
                     user.xp >= 1000 ? 'VIP' : 'Basic') }}</span>
               </div>
               <div class="stat-decoration"></div>
            </div>

            <div class="stat-card-premium">
               <div class="stat-icon-wrap" style="--icon-gradient: linear-gradient(135deg, #F59E0B, #FBBF24)">
                  <i class="bi bi-lightning-charge-fill"></i>
               </div>
               <div class="stat-info">
                  <span class="stat-label">Total XP</span>
                  <span class="stat-value">{{ user.xp || 0 }} <small>XP</small></span>
               </div>
               <div class="stat-decoration"></div>
            </div>
         </div>

         <!-- Traffic Graph -->
         <div class="glass-card mb-4 p-4 animate-slide-up" style="animation-delay: 0.2s">
            <h5 class="fw-bold mb-4 d-flex align-items-center gap-2">
               <i class="bi bi-graph-up-arrow text-primary"></i> Statistik Trafik & Kunjungan Produk
            </h5>
            <div style="height: 300px; width: 100%;">
               <Line v-if="chartData.labels" :data="chartData" :options="chartOptions" />
            </div>
         </div>

         <!-- Main Grid: Transactions + Products -->
         <div class="main-grid">
            <!-- Transaction History -->
            <div class="glass-card transactions-card animate-slide-up" style="animation-delay: 0.25s">
               <div class="card-header-premium">
                  <div class="d-flex align-items-center gap-2">
                     <div class="header-icon">
                        <i class="bi bi-clock-history"></i>
                     </div>
                     <div>
                        <h5 class="fw-bold mb-0">Riwayat Transaksi</h5>
                        <small class="text-secondary">{{ totalTransactions }} total transaksi</small>
                     </div>
                  </div>
                  <div class="search-bar">
                     <i class="bi bi-search"></i>
                     <input type="search" v-model="transactionSearchQuery" placeholder="Cari transaksi..."
                        :disabled="isTransactionsLoading">
                  </div>
               </div>

               <div class="transactions-list" :class="{ 'is-loading': isTransactionsLoading }">
                  <!-- Empty State -->
                  <div v-if="transactions.length === 0 && !isTransactionsLoading" class="empty-state">
                     <i class="bi bi-inbox"></i>
                     <p>Belum ada transaksi</p>
                     <small>Mulai belanja untuk melihat riwayat transaksi Anda</small>
                  </div>

                  <!-- Transaction Items -->
                  <div v-else v-for="(sale, index) in transactions" :key="sale._id" class="transaction-item"
                     :style="{ animationDelay: `${index * 0.05}s` }">
                     <div class="transaction-left">
                        <div class="transaction-status-icon" :class="`status-icon-${sale.status.toLowerCase()}`">
                           <i
                              :class="sale.status === 'Paid' ? 'bi bi-check-circle-fill' : sale.status === 'Pending' ? 'bi bi-hourglass-split' : 'bi bi-x-circle-fill'"></i>
                        </div>
                        <div class="transaction-details">
                           <span class="transaction-id">{{ sale._id }}</span>
                           <span class="transaction-date">{{ formatDateInvoice(sale.created_at) }}</span>
                        </div>
                     </div>
                     <div class="transaction-right">
                        <span class="status-pill" :class="`pill-${sale.status.toLowerCase()}`">{{ sale.status }}</span>
                        <div class="transaction-actions">
                           <button v-if="sale.status === 'Paid'" @click="openRefundModal(sale)" class="btn-icon"
                              title="Ajukan Refund">
                              <i class="bi bi-arrow-return-left text-danger"></i>
                           </button>
                           <button @click="showTransactionDetails(sale)" class="btn-icon" title="Detail">
                              <i class="bi bi-eye"></i>
                           </button>
                           <button @click="$router.push(`/invoice/${sale._id}`)" class="btn-icon" title="Invoice">
                              <i class="bi bi-box-arrow-up-right"></i>
                           </button>
                        </div>
                     </div>
                  </div>
               </div>

               <!-- Loading Overlay -->
               <div v-if="isTransactionsLoading" class="loading-overlay">
                  <div class="loading-pulse small">
                     <div class="pulse-dot"></div>
                     <div class="pulse-dot"></div>
                     <div class="pulse-dot"></div>
                  </div>
               </div>

               <!-- Pagination -->
               <div v-if="totalTransactionPages > 1" class="pagination-bar">
                  <button @click="goToTransactionPage(transactionCurrentPage - 1)"
                     :disabled="transactionCurrentPage === 1" class="btn-page">
                     <i class="bi bi-chevron-left"></i>
                  </button>
                  <span class="page-info">{{ transactionCurrentPage }} / {{ totalTransactionPages }}</span>
                  <button @click="goToTransactionPage(transactionCurrentPage + 1)"
                     :disabled="transactionCurrentPage === totalTransactionPages" class="btn-page">
                     <i class="bi bi-chevron-right"></i>
                  </button>
               </div>
            </div>

            <!-- Products Sidebar -->
            <div class="glass-card products-card animate-slide-up" style="animation-delay: 0.35s">
               <div class="card-header-premium">
                  <div class="d-flex align-items-center gap-2">
                     <div class="header-icon" style="--icon-gradient: linear-gradient(135deg, #06B6D4, #22D3EE)">
                        <i class="bi bi-grid-3x3-gap-fill"></i>
                     </div>
                     <div>
                        <h5 class="fw-bold mb-0">Produk Saya</h5>
                        <small class="text-secondary">{{ purchasedProducts.length }} produk dimiliki</small>
                     </div>
                  </div>
               </div>

               <div class="products-list">
                  <div v-if="purchasedProducts.length === 0" class="empty-state">
                     <i class="bi bi-bag-x"></i>
                     <p>Belum ada produk</p>
                     <small>Produk yang Anda beli akan muncul di sini</small>
                  </div>

                  <div v-for="(product, index) in purchasedProducts" :key="product.id" class="product-item"
                     :style="{ animationDelay: `${index * 0.08}s` }">
                     <div class="product-icon-wrap">
                        <i class="bi bi-box-seam-fill"></i>
                     </div>
                     <div class="product-info">
                        <span class="product-name">{{ product.name }}</span>
                        <span class="product-date">
                           <i class="bi bi-calendar3 me-1"></i>{{ formatDate(product.purchaseDate) }}
                        </span>
                     </div>
                     <i class="bi bi-chevron-right product-arrow"></i>
                  </div>
               </div>
            </div>
         </div>
      </div>

      <!-- Transaction Detail Modal -->
      <div class="modal fade" ref="transactionModalRef" tabindex="-1" aria-labelledby="transactionModalLabel"
         aria-hidden="true">
         <div class="modal-dialog modal-dialog-centered">
            <div v-if="selectedTransaction" class="modal-content premium-modal">
               <div class="modal-header premium-modal-header">
                  <div>
                     <h5 class="modal-title fw-bold" id="transactionModalLabel">Detail Transaksi</h5>
                     <small class="text-secondary">{{ selectedTransaction._id }}</small>
                  </div>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
               </div>
               <div class="modal-body premium-modal-body">
                  <div class="modal-status-banner" :class="`banner-${selectedTransaction.status.toLowerCase()}`">
                     <i
                        :class="selectedTransaction.status === 'Paid' ? 'bi bi-check-circle-fill' : 'bi bi-hourglass-split'"></i>
                     <span>{{ selectedTransaction.status === 'Paid' ? 'Pembayaran Berhasil' : 'Menunggu Pembayaran'
                     }}</span>
                  </div>

                  <div class="modal-detail-grid">
                     <div class="detail-item">
                        <span class="detail-label"><i class="bi bi-person me-2"></i>Customer</span>
                        <span class="detail-value">{{ selectedTransaction.email }}</span>
                     </div>
                     <div class="detail-item">
                        <span class="detail-label"><i class="bi bi-calendar3 me-2"></i>Tanggal</span>
                        <span class="detail-value">{{ formatDateInvoice(selectedTransaction.created_at) }}</span>
                     </div>
                     <div class="detail-item">
                        <span class="detail-label"><i class="bi bi-box-seam me-2"></i>Produk</span>
                        <span class="detail-value">
                           <span v-for="name in selectedTransaction.productNames" :key="name" class="product-tag">{{
                              name }}</span>
                        </span>
                     </div>
                     <div class="detail-item total-item">
                        <span class="detail-label"><i class="bi bi-cash-stack me-2"></i>Total</span>
                        <span class="detail-value total-value">Rp {{ formatCurrency(selectedTransaction.amount)
                        }}</span>
                     </div>
                  </div>
               </div>
               <div class="modal-footer premium-modal-footer">
                  <button type="button" class="btn-ghost" data-bs-dismiss="modal">Tutup</button>
                  <button type="button" class="btn-explore" @click="$router.push(`/invoice/${selectedTransaction._id}`)"
                     data-bs-dismiss="modal">
                     <i class="bi bi-box-arrow-up-right me-2"></i>Lihat Invoice
                  </button>
               </div>
            </div>
         </div>
      </div>
      <!-- Refund Modal -->
      <div class="modal fade" ref="refundModalRef" tabindex="-1">
         <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content premium-modal">
               <div class="modal-header premium-modal-header" style="border-bottom: 1px solid rgba(255,255,255,0.05)">
                  <h5 class="modal-title fw-bold text-danger"><i class="bi bi-exclamation-triangle-fill me-2"></i>
                     Ajukan Refund</h5>
                  <button type="button" class="btn-close" @click="closeRefundModal"></button>
               </div>
               <div class="modal-body p-4" v-if="refundForm">
                  <p class="text-secondary small mb-4">Pengajuan refund untuk ID: <strong>{{ refundForm.transaction_id
                        }}</strong></p>

                  <div class="mb-3">
                     <label class="form-label text-secondary small">Kategori Masalah <span
                           class="text-danger">*</span></label>
                     <select class="form-select form-control" v-model="refundForm.category">
                        <option value="" disabled>Pilih Kategori</option>
                        <option value="Barang Rusak">Barang Rusak</option>
                        <option value="Tidak Berfungsi">Tidak Berfungsi</option>
                        <option value="Tidak Sesuai">Tidak Sesuai</option>
                        <option value="Lainnya">Lainnya...</option>
                     </select>
                  </div>

                  <div class="mb-3">
                     <label class="form-label text-secondary small">Alasan Detail <span class="text-danger"
                           v-if="refundForm.category === 'Lainnya'">*</span></label>
                     <textarea class="form-control" v-model="refundForm.reason" rows="3"
                        placeholder="Jelaskan kendala Anda..."></textarea>
                  </div>

                  <div class="mb-4">
                     <label class="form-label text-secondary small">Foto Bukti (Opsional)</label>
                     <input type="file" @change="handleRefundProof" class="form-control" accept="image/*">
                     <div v-if="refundForm.proof_image" class="mt-2 text-success small"><i
                           class="bi bi-check-circle-fill"></i> File siap dikirim</div>
                  </div>

                  <button @click="submitRefund" class="btn-premium w-100"
                     style="background: linear-gradient(135deg, #ef4444, #f97316);" :disabled="isSubmittingRefund">
                     <span v-if="isSubmittingRefund" class="spinner-border spinner-border-sm me-2"></span>
                     Kirim Pengajuan
                  </button>
               </div>
            </div>
         </div>
      </div>

   </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, computed, watch } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { Modal } from 'bootstrap'
import {
   Chart as ChartJS,
   CategoryScale,
   LinearScale,
   PointElement,
   LineElement,
   Title,
   Tooltip,
   Legend,
   Filler
} from 'chart.js'
import { Line } from 'vue-chartjs'

ChartJS.register(
   CategoryScale,
   LinearScale,
   PointElement,
   LineElement,
   Title,
   Tooltip,
   Legend,
   Filler
)

const { $api } = useNuxtApp()
const router = useRouter()
const route = useRoute()

const isLoading = ref(true)
const errorMsg = ref(null)
const user = ref({})
const customerStats = ref({})
const purchasedProducts = ref([])
const transactions = ref([])
const totalTransactions = ref(0)
const isTransactionsLoading = ref(true)
const transactionSearchQuery = ref(route.query.search || '')
const transactionCurrentPage = ref(parseInt(route.query.page) || 1)
const transactionItemsPerPage = ref(10)
const selectedTransaction = ref(null)
const transactionModalRef = ref(null)
const refundModalRef = ref(null)
let modalInstance = null
let refundModalInstance = null

const refundForm = ref(null)
const isSubmittingRefund = ref(false)

const totalTransactionPages = computed(() => Math.ceil(totalTransactions.value / transactionItemsPerPage.value) || 1)

// Chart dummy data configuration
const chartData = ref({
   labels: ['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'],
   datasets: [
      {
         label: 'Kunjungan Produk',
         backgroundColor: 'rgba(139, 92, 246, 0.2)',
         borderColor: '#8B5CF6',
         data: [120, 190, 150, 220, 180, 290, 310],
         fill: true,
         tension: 0.4
      }
   ]
})

const chartOptions = ref({
   responsive: true,
   maintainAspectRatio: false,
   plugins: {
      legend: { display: false },
      tooltip: {
         backgroundColor: 'rgba(15, 23, 42, 0.9)',
         titleColor: '#fff',
         bodyColor: '#e2e8f0',
         borderColor: 'rgba(255,255,255,0.1)',
         borderWidth: 1
      }
   },
   scales: {
      y: {
         beginAtZero: true,
         grid: { color: 'rgba(255,255,255,0.05)' },
         ticks: { color: '#94a3b8' }
      },
      x: {
         grid: { display: false },
         ticks: { color: '#94a3b8' }
      }
   }
})

const formatCurrency = value => Number(value || 0).toLocaleString('id-ID')
const formatDate = dateString => {
   if (!dateString) return '-'
   return new Date(dateString).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })
}
const formatDateInvoice = dateString => new Date(dateString).toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })

const goToTransactionPage = async (page) => {
   if (page >= 1 && page <= totalTransactionPages.value && page !== transactionCurrentPage.value) {
      await router.push({ query: { ...route.query, page: page } })
   }
}

const showTransactionDetails = (transaction) => {
   selectedTransaction.value = transaction
   modalInstance?.show()
}

const fetchTransactions = async () => {
   isTransactionsLoading.value = true
   try {
      const params = new URLSearchParams({
         page: transactionCurrentPage.value,
         limit: transactionItemsPerPage.value,
         search: transactionSearchQuery.value
      })
      const res = await $api(`/api/v1/invoices?${params.toString()}`)
      if (res.status && res.data) {
         transactions.value = res.data.invoices
         totalTransactions.value = res.data.total
      } else {
         transactions.value = []
         totalTransactions.value = 0
      }
   } catch (err) {
      console.error("Gagal mengambil transaksi:", err)
   } finally {
      isTransactionsLoading.value = false
   }
}

const fetchInitialData = async () => {
   isLoading.value = true
   errorMsg.value = null
   try {
      const res = await $api('/api/v1/statistic')
      if (!res.status || !res.data) throw new Error(res.msg || 'Gagal mengambil data dari server.')
      const apiData = res.data
      user.value = { name: apiData.name, registrationDate: apiData.joinedAt }
      customerStats.value = { totalSpending: apiData.stats.totalPurchase, totalTransactions: apiData.stats.totalTransactions, productsOwned: apiData.stats.totalItems }
      purchasedProducts.value = apiData.purchasedProducts
      await fetchTransactions()
   } catch (err) {
      console.error('Error fetching dashboard data:', err)
      errorMsg.value = err.message || 'Terjadi kesalahan saat memuat data.'
   } finally {
      isLoading.value = false
   }
}

let transactionSearchTimeout
watch(transactionSearchQuery, (newSearchQuery) => {
   clearTimeout(transactionSearchTimeout)
   transactionSearchTimeout = setTimeout(async () => {
      const query = { ...route.query, page: 1, search: newSearchQuery || undefined }
      await router.push({ query })
   }, 300)
})

watch(() => route.query, (newQuery) => {
   const newPage = parseInt(newQuery.page) || 1
   transactionCurrentPage.value = newPage
   fetchTransactions()
}, { deep: true })

// ==========================================
// REFUND LOGIC
// ==========================================
const openRefundModal = (transaction) => {
   refundForm.value = {
      transaction_id: transaction._id,
      category: '',
      reason: '',
      proof_image: ''
   }
   refundModalInstance?.show()
}

const closeRefundModal = () => {
   refundModalInstance?.hide()
   refundForm.value = null
}

const handleRefundProof = (e) => {
   const file = e.target.files[0]
   if (!file) return
   if (!file.type.startsWith('image/')) return Swal.fire('Error', 'Harap pilih file gambar', 'error')

   const reader = new FileReader()
   reader.onload = (event) => {
      const img = new Image()
      img.onload = () => {
         const canvas = document.createElement('canvas')
         let { width, height } = img
         if (width > 800) { height *= 800 / width; width = 800; }
         canvas.width = width; canvas.height = height;
         canvas.getContext('2d')?.drawImage(img, 0, 0, width, height)
         refundForm.value.proof_image = canvas.toDataURL('image/jpeg', 0.8)
      }
      img.src = event.target.result
   }
   reader.readAsDataURL(file)
}

const submitRefund = async () => {
   if (!refundForm.value.category) return Swal.fire('Oops', 'Pilih kategori terlebih dahulu', 'warning')
   if (refundForm.value.category === 'Lainnya' && !refundForm.value.reason.trim()) {
      return Swal.fire('Oops', 'Alasan detail wajib diisi untuk kategori Lainnya', 'warning')
   }

   isSubmittingRefund.value = true
   try {
      const res = await $api('/api/v2/refund', {
         method: 'POST',
         body: {
            action: 'requestRefund',
            ...refundForm.value
         }
      })
      if (res.status) {
         Swal.fire('Berhasil', res.msg, 'success')
         closeRefundModal()
         fetchTransactions() // refresh list
      } else {
         Swal.fire('Gagal', res.msg, 'error')
      }
   } catch (e) {
      Swal.fire('Error', e.data?.msg || e.message, 'error')
   } finally {
      isSubmittingRefund.value = false
   }
}

onMounted(() => {
   fetchInitialData()
   import('bootstrap/dist/js/bootstrap.bundle.min.js').then((bootstrap) => {
      if (transactionModalRef.value) {
         modalInstance = new bootstrap.Modal(transactionModalRef.value)
         transactionModalRef.value.addEventListener('hidden.bs.modal', () => {
            selectedTransaction.value = null
         })
      }
      if (refundModalRef.value) {
         refundModalInstance = new bootstrap.Modal(refundModalRef.value)
      }
   })
})

onUnmounted(() => {
   modalInstance?.dispose()
})
</script>

<style scoped>
/* ═══════════════════════════════════════ */
/*  HERO SECTION                          */
/* ═══════════════════════════════════════ */
.buyer-dashboard {
   min-height: 100vh;
}

.dashboard-hero {
   position: relative;
   padding: calc(64px + 2.5rem) 0 2rem;
   overflow: hidden;
}

.hero-gradient-orb {
   position: absolute;
   border-radius: 50%;
   filter: blur(100px);
   opacity: 0.3;
   animation: float 10s ease-in-out infinite;
}

.orb-1 {
   width: 350px;
   height: 350px;
   background: var(--primary-gradient-start);
   top: -120px;
   right: -50px;
}

.orb-2 {
   width: 250px;
   height: 250px;
   background: var(--primary-gradient-end);
   bottom: -80px;
   left: 20%;
   animation-delay: 3s;
}

.hero-content {
   position: relative;
   z-index: 1;
}

.greeting-badge {
   display: inline-flex;
   align-items: center;
   padding: 0.4rem 1rem;
   background: linear-gradient(135deg, rgba(139, 92, 246, 0.12), rgba(59, 130, 246, 0.12));
   color: var(--primary-gradient-start);
   border-radius: 50px;
   font-weight: 600;
   font-size: 0.8rem;
   border: 1px solid rgba(139, 92, 246, 0.2);
   margin-bottom: 1rem;
   letter-spacing: 0.5px;
   text-transform: uppercase;
}

.hero-title {
   font-size: 2rem;
   font-weight: 800;
   color: var(--app-text-color);
   margin-bottom: 0.5rem;
   line-height: 1.2;
}

.gradient-text {
   background: var(--gradient-primary);
   -webkit-background-clip: text;
   -webkit-text-fill-color: transparent;
   background-clip: text;
}

.hero-subtitle {
   color: var(--app-secondary-text-color);
   font-size: 1rem;
   margin: 0;
}

.btn-explore {
   display: inline-flex;
   align-items: center;
   padding: 0.7rem 1.5rem;
   background: var(--gradient-primary);
   color: #fff;
   border: none;
   border-radius: 12px;
   font-weight: 600;
   font-size: 0.9rem;
   cursor: pointer;
   transition: all 0.3s ease;
   text-decoration: none;
   box-shadow: 0 4px 15px rgba(139, 92, 246, 0.3);
}

.btn-explore:hover {
   transform: translateY(-2px);
   box-shadow: 0 8px 25px rgba(139, 92, 246, 0.4);
   color: #fff;
}

/* ═══════════════════════════════════════ */
/*  LOADING                               */
/* ═══════════════════════════════════════ */
.loading-container {
   display: flex;
   flex-direction: column;
   align-items: center;
   justify-content: center;
   padding: 5rem 0;
}

.loading-pulse {
   display: flex;
   gap: 8px;
}

.loading-pulse.small .pulse-dot {
   width: 8px;
   height: 8px;
}

.pulse-dot {
   width: 12px;
   height: 12px;
   background: var(--gradient-primary);
   border-radius: 50%;
   animation: pulse-bounce 1.4s ease-in-out infinite;
}

.pulse-dot:nth-child(2) {
   animation-delay: 0.2s;
}

.pulse-dot:nth-child(3) {
   animation-delay: 0.4s;
}

.loading-text {
   margin-top: 1.5rem;
   color: var(--app-secondary-text-color);
   font-weight: 500;
}

/* ═══════════════════════════════════════ */
/*  STATS GRID                            */
/* ═══════════════════════════════════════ */
.stats-grid {
   display: grid;
   grid-template-columns: repeat(4, 1fr);
   gap: 1.25rem;
   margin-bottom: 1.5rem;
}

.stat-card-premium {
   position: relative;
   display: flex;
   align-items: center;
   gap: 1rem;
   padding: 1.25rem 1.5rem;
   background: var(--app-card-bg);
   border: 1px solid var(--app-border-color);
   border-radius: 16px;
   overflow: hidden;
   transition: all 0.3s ease;
}

.stat-card-premium:hover {
   transform: translateY(-3px);
   box-shadow: 0 12px 30px rgba(0, 0, 0, 0.08);
   border-color: rgba(139, 92, 246, 0.3);
}

.stat-decoration {
   position: absolute;
   top: -20px;
   right: -20px;
   width: 80px;
   height: 80px;
   border-radius: 50%;
   background: var(--gradient-primary);
   opacity: 0.05;
}

.stat-icon-wrap {
   width: 48px;
   height: 48px;
   min-width: 48px;
   display: flex;
   align-items: center;
   justify-content: center;
   background: var(--icon-gradient, var(--gradient-primary));
   border-radius: 14px;
   color: #fff;
   font-size: 1.2rem;
   box-shadow: 0 4px 12px rgba(139, 92, 246, 0.2);
}

.stat-info {
   display: flex;
   flex-direction: column;
}

.stat-label {
   font-size: 0.78rem;
   font-weight: 500;
   color: var(--app-secondary-text-color);
   text-transform: uppercase;
   letter-spacing: 0.5px;
}

.stat-value {
   font-size: 1.3rem;
   font-weight: 700;
   color: var(--app-text-color);
   line-height: 1.3;
}

.stat-value small {
   font-size: 0.75rem;
   font-weight: 500;
   color: var(--app-secondary-text-color);
}

/* ═══════════════════════════════════════ */
/*  GLASS CARD OVERRIDES                  */
/* ═══════════════════════════════════════ */
.glass-card {
   border-radius: 20px;
   overflow: hidden;
}

.card-header-premium {
   display: flex;
   justify-content: space-between;
   align-items: center;
   padding: 1.25rem 1.5rem;
   border-bottom: 1px solid var(--app-border-color);
   flex-wrap: wrap;
   gap: 1rem;
}

.header-icon {
   width: 38px;
   height: 38px;
   display: flex;
   align-items: center;
   justify-content: center;
   background: var(--icon-gradient, var(--gradient-primary));
   border-radius: 10px;
   color: #fff;
   font-size: 1rem;
}

.search-bar {
   display: flex;
   align-items: center;
   gap: 0.5rem;
   padding: 0.5rem 1rem;
   background: var(--app-surface);
   border: 1px solid var(--app-border-color);
   border-radius: 10px;
   min-width: 220px;
   transition: border-color 0.3s;
}

.search-bar:focus-within {
   border-color: var(--primary-gradient-start);
}

.search-bar i {
   color: var(--app-secondary-text-color);
   font-size: 0.85rem;
}

.search-bar input {
   border: none;
   background: transparent;
   outline: none;
   color: var(--app-text-color);
   font-size: 0.85rem;
   width: 100%;
}

.search-bar input::placeholder {
   color: var(--app-secondary-text-color);
}

/* ═══════════════════════════════════════ */
/*  MAIN GRID                             */
/* ═══════════════════════════════════════ */
.main-grid {
   display: grid;
   grid-template-columns: 1fr 380px;
   gap: 1.5rem;
}

/* ═══════════════════════════════════════ */
/*  TRANSACTIONS                          */
/* ═══════════════════════════════════════ */
.transactions-card {
   position: relative;
}

.transactions-list {
   min-height: 200px;
}

.transactions-list.is-loading {
   opacity: 0.4;
   pointer-events: none;
}

.transaction-item {
   display: flex;
   justify-content: space-between;
   align-items: center;
   padding: 1rem 1.5rem;
   border-bottom: 1px solid var(--app-border-color);
   transition: background 0.2s;
   animation: slide-in-right 0.4s ease-out both;
}

.transaction-item:last-child {
   border-bottom: none;
}

.transaction-item:hover {
   background: var(--app-surface);
}

.transaction-left,
.transaction-right {
   display: flex;
   align-items: center;
   gap: 0.75rem;
}

.transaction-status-icon {
   width: 40px;
   height: 40px;
   display: flex;
   align-items: center;
   justify-content: center;
   border-radius: 12px;
   font-size: 1.1rem;
}

.status-icon-paid {
   background: rgba(34, 197, 94, 0.1);
   color: #22C55E;
}

.status-icon-pending {
   background: rgba(245, 158, 11, 0.1);
   color: #F59E0B;
}

.status-icon-expired,
.status-icon-failed {
   background: rgba(239, 68, 68, 0.1);
   color: #EF4444;
}

.transaction-details {
   display: flex;
   flex-direction: column;
}

.transaction-id {
   font-weight: 600;
   font-size: 0.9rem;
   color: var(--app-text-color);
}

.transaction-date {
   font-size: 0.78rem;
   color: var(--app-secondary-text-color);
}

.status-pill {
   padding: 0.3rem 0.8rem;
   border-radius: 50px;
   font-size: 0.72rem;
   font-weight: 600;
   text-transform: uppercase;
   letter-spacing: 0.5px;
}

.pill-paid {
   background: rgba(34, 197, 94, 0.1);
   color: #22C55E;
}

.pill-pending {
   background: rgba(245, 158, 11, 0.1);
   color: #F59E0B;
}

.pill-expired,
.pill-failed {
   background: rgba(239, 68, 68, 0.1);
   color: #EF4444;
}

.transaction-actions {
   display: flex;
   gap: 4px;
}

.btn-icon {
   width: 34px;
   height: 34px;
   display: flex;
   align-items: center;
   justify-content: center;
   background: transparent;
   border: 1px solid var(--app-border-color);
   border-radius: 8px;
   color: var(--app-secondary-text-color);
   cursor: pointer;
   transition: all 0.2s;
   font-size: 0.85rem;
}

.btn-icon:hover {
   background: var(--gradient-primary);
   color: #fff;
   border-color: transparent;
}

/* Loading overlay */
.loading-overlay {
   position: absolute;
   inset: 0;
   display: flex;
   align-items: center;
   justify-content: center;
   background: rgba(255, 255, 255, 0.5);
   backdrop-filter: blur(2px);
   z-index: 2;
   border-radius: 20px;
}

/* Pagination */
.pagination-bar {
   display: flex;
   align-items: center;
   justify-content: center;
   gap: 1rem;
   padding: 1rem;
   border-top: 1px solid var(--app-border-color);
}

.btn-page {
   width: 36px;
   height: 36px;
   display: flex;
   align-items: center;
   justify-content: center;
   background: var(--app-surface);
   border: 1px solid var(--app-border-color);
   border-radius: 10px;
   color: var(--app-text-color);
   cursor: pointer;
   transition: all 0.2s;
}

.btn-page:hover:not(:disabled) {
   background: var(--gradient-primary);
   color: #fff;
   border-color: transparent;
}

.btn-page:disabled {
   opacity: 0.4;
   cursor: default;
}

.page-info {
   font-size: 0.85rem;
   font-weight: 600;
   color: var(--app-secondary-text-color);
}

/* ═══════════════════════════════════════ */
/*  PRODUCTS SIDEBAR                      */
/* ═══════════════════════════════════════ */
.products-list {
   padding: 0.5rem 0;
}

.product-item {
   display: flex;
   align-items: center;
   gap: 0.75rem;
   padding: 0.85rem 1.5rem;
   transition: all 0.2s;
   cursor: default;
   animation: slide-in-right 0.4s ease-out both;
}

.product-item:hover {
   background: var(--app-surface);
}

.product-icon-wrap {
   width: 40px;
   height: 40px;
   min-width: 40px;
   display: flex;
   align-items: center;
   justify-content: center;
   background: linear-gradient(135deg, rgba(6, 182, 212, 0.1), rgba(34, 211, 238, 0.1));
   color: #06B6D4;
   border-radius: 10px;
   font-size: 1rem;
}

.product-info {
   display: flex;
   flex-direction: column;
   flex: 1;
}

.product-name {
   font-weight: 600;
   font-size: 0.9rem;
   color: var(--app-text-color);
   white-space: nowrap;
   overflow: hidden;
   text-overflow: ellipsis;
}

.product-date {
   font-size: 0.75rem;
   color: var(--app-secondary-text-color);
}

.product-arrow {
   color: var(--app-secondary-text-color);
   opacity: 0;
   transition: opacity 0.2s;
}

.product-item:hover .product-arrow {
   opacity: 1;
}

/* ═══════════════════════════════════════ */
/*  EMPTY STATE                           */
/* ═══════════════════════════════════════ */
.empty-state {
   display: flex;
   flex-direction: column;
   align-items: center;
   padding: 3rem 1rem;
   color: var(--app-secondary-text-color);
}

.empty-state i {
   font-size: 2.5rem;
   opacity: 0.3;
   margin-bottom: 0.5rem;
}

.empty-state p {
   font-weight: 600;
   margin: 0;
}

.empty-state small {
   opacity: 0.7;
}

/* Error state */
.error-card {
   padding: 3rem;
   margin: 2rem 0;
}

.error-icon-wrap {
   width: 64px;
   height: 64px;
   display: inline-flex;
   align-items: center;
   justify-content: center;
   background: rgba(239, 68, 68, 0.1);
   color: #EF4444;
   border-radius: 16px;
   font-size: 1.8rem;
}

/* ═══════════════════════════════════════ */
/*  MODAL                                 */
/* ═══════════════════════════════════════ */
.premium-modal {
   background: var(--app-card-bg);
   border: 1px solid var(--app-border-color);
   border-radius: 20px;
   overflow: hidden;
}

.premium-modal-header {
   border-bottom: 1px solid var(--app-border-color);
   padding: 1.25rem 1.5rem;
}

.premium-modal-body {
   padding: 1.5rem;
}

.premium-modal-footer {
   border-top: 1px solid var(--app-border-color);
   padding: 1rem 1.5rem;
   display: flex;
   gap: 0.75rem;
   justify-content: flex-end;
}

.modal-status-banner {
   display: flex;
   align-items: center;
   gap: 0.75rem;
   padding: 1rem 1.25rem;
   border-radius: 12px;
   font-weight: 600;
   font-size: 0.9rem;
   margin-bottom: 1.5rem;
}

.banner-paid {
   background: rgba(34, 197, 94, 0.1);
   color: #22C55E;
}

.banner-pending {
   background: rgba(245, 158, 11, 0.1);
   color: #F59E0B;
}

.modal-detail-grid {
   display: flex;
   flex-direction: column;
   gap: 1rem;
}

.detail-item {
   display: flex;
   justify-content: space-between;
   align-items: flex-start;
   padding-bottom: 1rem;
   border-bottom: 1px solid var(--app-border-color);
}

.detail-item:last-child {
   border-bottom: none;
   padding-bottom: 0;
}

.detail-label {
   font-size: 0.85rem;
   color: var(--app-secondary-text-color);
   font-weight: 500;
}

.detail-value {
   font-weight: 600;
   color: var(--app-text-color);
   text-align: right;
   max-width: 60%;
}

.total-item {
   padding-top: 0.5rem;
}

.total-value {
   font-size: 1.2rem;
   background: var(--gradient-primary);
   -webkit-background-clip: text;
   background-clip: text;
   -webkit-text-fill-color: transparent;
}

.product-tag {
   display: inline-block;
   padding: 0.2rem 0.6rem;
   background: var(--app-surface);
   border: 1px solid var(--app-border-color);
   border-radius: 6px;
   font-size: 0.8rem;
   margin: 0.15rem;
}

.btn-ghost {
   padding: 0.6rem 1.25rem;
   background: transparent;
   border: 1px solid var(--app-border-color);
   border-radius: 10px;
   color: var(--app-text-color);
   font-weight: 500;
   cursor: pointer;
   transition: all 0.2s;
}

.btn-ghost:hover {
   background: var(--app-surface);
}

/* ═══════════════════════════════════════ */
/*  ANIMATIONS                            */
/* ═══════════════════════════════════════ */
@keyframes float {

   0%,
   100% {
      transform: translate(0, 0);
   }

   50% {
      transform: translate(15px, -15px);
   }
}

@keyframes pulse-bounce {

   0%,
   80%,
   100% {
      transform: scale(0.6);
      opacity: 0.4;
   }

   40% {
      transform: scale(1);
      opacity: 1;
   }
}

@keyframes slide-in-right {
   from {
      opacity: 0;
      transform: translateX(-10px);
   }

   to {
      opacity: 1;
      transform: translateX(0);
   }
}

.animate-slide-up {
   animation: slide-up 0.5s ease-out both;
}

.animate-fade-in {
   animation: fade-in 0.4s ease-out both;
}

@keyframes slide-up {
   from {
      opacity: 0;
      transform: translateY(20px);
   }

   to {
      opacity: 1;
      transform: translateY(0);
   }
}

@keyframes fade-in {
   from {
      opacity: 0;
   }

   to {
      opacity: 1;
   }
}

/* ═══════════════════════════════════════ */
/*  RESPONSIVE                            */
/* ═══════════════════════════════════════ */
@media (max-width: 1200px) {
   .stats-grid {
      grid-template-columns: repeat(2, 1fr);
   }

   .main-grid {
      grid-template-columns: 1fr;
   }
}

@media (max-width: 768px) {
   .stats-grid {
      grid-template-columns: 1fr;
   }

   .hero-title {
      font-size: 1.5rem;
   }

   .dashboard-hero {
      padding: 1.5rem 0 1rem;
   }

   .card-header-premium {
      flex-direction: column;
      align-items: flex-start;
   }

   .search-bar {
      width: 100%;
      min-width: unset;
   }

   .transaction-item {
      flex-direction: column;
      align-items: flex-start;
      gap: 0.75rem;
   }

   .transaction-right {
      width: 100%;
      justify-content: space-between;
   }
}

/* ═══════════════════════════════════════ */
/*  DARK MODE                             */
/* ═══════════════════════════════════════ */
:global(body.dark-mode) .loading-overlay {
   background: rgba(15, 23, 42, 0.5);
}

:global(body.dark-mode) .stat-card-premium:hover {
   box-shadow: 0 12px 30px rgba(0, 0, 0, 0.3);
}
</style>
<template>
   <div>
      <Transition name="acw-overlay-fade">
         <div v-if="isChatOpen" class="acw-overlay" @click="closeChat"></div>
      </Transition>

      <div class="acw-widget">
         <Transition name="acw-chat-fade">
            <div v-if="isChatOpen" class="acw-window card-3d">
               <div class="acw-header">
                  <div class="header-info">
                     <div class="bot-avatar-modern">
                        <i class="bi bi-robot"></i>
                     </div>
                     <div>
                        <h6 class="mb-0 fw-bold text-white">Yilzi AI Assistant</h6>
                        <small class="text-white-50">Siap membantu Anda</small>
                     </div>
                  </div>
                  <div class="d-flex align-items-center gap-2">
                     <button class="btn-clear-modern" @click="clearChatHistory" title="Hapus riwayat">
                        <i class="bi bi-trash"></i>
                     </button>
                     <button class="btn-close-modern" @click="closeChat">
                        <i class="bi bi-x-lg"></i>
                     </button>
                  </div>
               </div>
               <div class="acw-messages" ref="messagesContainer">
                  <div class="acw-message acw-is-ai">
                     <div class="message-avatar-ai">
                        <i class="bi bi-robot"></i>
                     </div>
                     <div class="acw-message-bubble bubble-ai">
                        <div class="acw-prose">Halo! Ada yang bisa saya bantu hari ini?</div>
                        <div class="acw-message-timestamp">Sekarang</div>
                     </div>
                  </div>
                  <div v-for="(msg, index) in filteredHistory" :key="index" class="acw-message"
                     :class="msg.role === 'user' ? 'acw-is-user' : 'acw-is-ai'">
                     <div v-if="msg.role !== 'user'" class="message-avatar-ai">
                        <i class="bi bi-robot"></i>
                     </div>
                     <div class="acw-message-bubble" :class="msg.role === 'user' ? 'bubble-user' : 'bubble-ai'">
                        <div v-if="msg.role === 'assistant'" class="acw-prose" v-html="renderMarkdown(msg.content)">
                        </div>
                        <span v-else>{{ msg.content }}</span>
                        <div class="acw-message-timestamp">{{ formatTime(msg.timestamp) }}</div>
                     </div>
                     <div v-if="msg.role === 'user'" class="message-avatar-user">
                        <i class="bi bi-person-fill"></i>
                     </div>
                  </div>
                  <div v-if="isLoading" class="acw-message acw-is-ai">
                     <div class="message-avatar-ai">
                        <i class="bi bi-robot"></i>
                     </div>
                     <div class="acw-message-bubble bubble-ai acw-typing-indicator">
                        <span></span><span></span><span></span>
                     </div>
                  </div>
               </div>

               <!-- Quick Suggestion Buttons -->
               <div v-if="history.length < 2 && !isLoading" class="acw-suggestions">
                  <span class="suggestion-title">Rekomendasi Pertanyaan:</span>
                  <div class="suggestion-chips">
                     <button @click="sendSuggestion('Apa produk terlaris di Yilzi Shop saat ini?')" class="chip-btn">
                        <i class="bi bi-fire text-danger"></i> Produk Terlaris
                     </button>
                     <button @click="sendSuggestion('Bisa minta saran produk untuk belajar web resource/code?')"
                        class="chip-btn">
                        <i class="bi bi-code-slash text-primary"></i> Source Code Web
                     </button>
                     <button @click="sendSuggestion('Bagaimana cara melakukan pembelian atau checkout?')"
                        class="chip-btn">
                        <i class="bi bi-cart-check text-success"></i> Cara Pembelian
                     </button>
                  </div>
               </div>

               <div class="acw-input-area">
                  <form @submit.prevent="sendMessage" class="input-form-modern">
                     <input type="text" class="input-modern" v-model="newMessage" placeholder="Ketik pesan Anda..."
                        :disabled="isLoading" required>
                     <button type="submit" class="btn-send-modern" :disabled="isLoading">
                        <i class="bi bi-send-fill"></i>
                     </button>
                  </form>
               </div>
            </div>
         </Transition>

         <button class="acw-fab" :class="{ 'is-open': isChatOpen }" @click="toggleChat" :aria-expanded="isChatOpen"
            aria-label="Toggle AI Assistant Chat">
            <Transition name="acw-fab-icon-fade" mode="out-in">
               <i class="bi" :key="isChatOpen.toString()" :class="isChatOpen ? 'bi-x-lg' : 'bi-robot'"></i>
            </Transition>
         </button>
      </div>
   </div>
</template>

<script setup lang="ts">
import { ref, onMounted, nextTick, watch, computed } from 'vue'
import MarkdownIt from 'markdown-it'
import Prism from 'prismjs'
import 'prismjs/components/prism-javascript'
import 'prismjs/components/prism-css'
import 'prismjs/components/prism-json'
import 'prismjs/components/prism-bash'

const { $api }: any = useNuxtApp()
const isChatOpen = ref(false)
const history = ref([])
const newMessage = ref('')
const isLoading = ref(false)
const conversationId = ref(null)
const messagesContainer = ref(null)

const md = new MarkdownIt({
   html: true,
   linkify: true,
   breaks: true,
   highlight: function (str, lang) {
      if (lang && Prism.languages[lang]) {
         try {
            return '<pre class="language-' + lang + '"><code>' + Prism.highlight(str, Prism.languages[lang], lang) + '</code></pre>'
         } catch (__) { }
      }
      return '<pre class="language-plain"><code>' + md.utils.escapeHtml(str) + '</code></pre>'
   }
}).disable(['heading'])

const renderMarkdown = (text) => {
   return md.render(text || '')
}

const SESSION_ID_KEY = 'ai_chat_session_id'
const filteredHistory = computed(() => {
   return history.value.filter(msg => msg.role !== 'system')
})

const scrollToBottom = () => {
   nextTick(() => {
      if (messagesContainer.value) {
         messagesContainer.value.scrollTop = messagesContainer.value.scrollHeight
      }
   })
}

const saveHistoryToSession = () => {
   if (conversationId.value) {
      sessionStorage.setItem(conversationId.value, JSON.stringify(history.value))
   }
}

const loadHistoryFromSession = () => {
   if (conversationId.value) {
      const savedHistory = sessionStorage.getItem(conversationId.value)
      if (savedHistory) {
         history.value = JSON.parse(savedHistory)
      } else {
         history.value = []
      }
   } else {
      history.value = []
   }
}

const toggleChat = () => {
   isChatOpen.value = !isChatOpen.value
   if (isChatOpen.value) {
      scrollToBottom()
   }
}

const closeChat = () => {
   isChatOpen.value = false
}

const formatTime = (dateString) => {
   if (!dateString) return ''
   const date = new Date(dateString)
   return date.toLocaleTimeString('id-ID', {
      hour: '2-digit',
      minute: '2-digit'
   })
}

const clearChatHistory = () => {
   if (conversationId.value) {
      sessionStorage.removeItem(conversationId.value)
      sessionStorage.removeItem(SESSION_ID_KEY)
   }
   history.value = []
   conversationId.value = null
}

const sendSuggestion = (text) => {
   newMessage.value = text
   sendMessage()
}

const sendMessage = async () => {
   if (!newMessage.value.trim() || isLoading.value) return
   const userMessage = newMessage.value
   history.value.push({
      role: 'user',
      content: userMessage,
      timestamp: new Date()
   })
   newMessage.value = ''
   scrollToBottom()
   isLoading.value = true
   try {
      const response = await $api('/api/v1/assistant', {
         method: 'POST',
         body: {
            id: conversationId.value,
            message: userMessage,
         }
      })
      if (response.status && response.data?.history) {
         conversationId.value = response.data.id
         const historyFromServer = response.data.history.map(msg => ({
            ...msg,
            timestamp: msg.timestamp || new Date()
         }))
         history.value = historyFromServer
         sessionStorage.setItem(SESSION_ID_KEY, conversationId.value)
      } else {
         history.value.push({
            role: 'assistant',
            content: response.msg || 'Terima kasih atas pesannya! Saat ini AI Assistant sedang dalam perbaikan. Silakan hubungi kami via WhatsApp untuk bantuan lebih lanjut.',
            timestamp: new Date()
         })
      }
   } catch (e) {
      history.value.push({
         role: 'assistant',
         content: 'Terima kasih atas pesannya! AI Assistant sedang offline. Silakan hubungi kami melalui WhatsApp di +62 813-5912-3789 untuk bantuan langsung.',
         timestamp: new Date()
      })
   } finally {
      isLoading.value = false
      scrollToBottom()
   }
}

onMounted(() => {
   const sessionId = sessionStorage.getItem(SESSION_ID_KEY)
   if (sessionId) {
      conversationId.value = sessionId
      loadHistoryFromSession()
   }
})

watch(history, saveHistoryToSession, {
   deep: true
})
</script>

<style scoped>
.acw-overlay {
   position: fixed;
   inset: 0;
   background: rgba(0, 0, 0, 0.5);
   z-index: 999;
   backdrop-filter: blur(4px);
}

.acw-overlay-fade-enter-active,
.acw-overlay-fade-leave-active {
   transition: opacity 0.3s ease;
}

.acw-overlay-fade-enter-from,
.acw-overlay-fade-leave-to {
   opacity: 0;
}

.acw-widget {
   position: fixed;
   bottom: 2rem;
   right: 2rem;
   z-index: 1000;
}

.acw-window {
   position: absolute;
   bottom: 80px;
   right: 0;
   width: 420px;
   max-width: calc(100vw - 2rem);
   height: 600px;
   max-height: calc(100vh - 160px);
   background: var(--app-surface);
   /* Updated to --app-surface for better theme adaptability */
   border: 1px solid var(--app-border-color);
   border-radius: 20px;
   overflow: hidden;
   display: flex;
   flex-direction: column;
   box-shadow: 0 24px 60px rgba(0, 0, 0, 0.3);
}

.acw-chat-fade-enter-active,
.acw-chat-fade-leave-active {
   transition: all 0.3s cubic-bezier(0.23, 1, 0.32, 1);
}

.acw-chat-fade-enter-from,
.acw-chat-fade-leave-to {
   opacity: 0;
   transform: translateY(20px) scale(0.95);
}

.acw-header {
   padding: 1.25rem;
   background: var(--gradient-primary);
   display: flex;
   justify-content: space-between;
   align-items: center;
}

.header-info {
   display: flex;
   align-items: center;
   gap: 0.875rem;
}

.bot-avatar-modern {
   width: 44px;
   height: 44px;
   border-radius: 50%;
   background: rgba(255, 255, 255, 0.2);
   display: flex;
   align-items: center;
   justify-content: center;
   font-size: 1.25rem;
   color: white;
}

.btn-clear-modern,
.btn-close-modern {
   width: 32px;
   height: 32px;
   border-radius: 8px;
   border: none;
   background: rgba(255, 255, 255, 0.2);
   color: white;
   display: flex;
   align-items: center;
   justify-content: center;
   cursor: pointer;
   transition: all 0.3s ease;
}

.btn-clear-modern:hover,
.btn-close-modern:hover {
   background: rgba(255, 255, 255, 0.3);
   transform: scale(1.1);
}

.acw-messages {
   flex: 1;
   overflow-y: auto;
   padding: 1.5rem;
   background: var(--app-surface);
   display: flex;
   flex-direction: column;
   gap: 1rem;
}

.acw-message {
   display: flex;
   gap: 0.75rem;
   animation: slideIn 0.3s ease;
}

@keyframes slideIn {
   from {
      opacity: 0;
      transform: translateY(10px);
   }

   to {
      opacity: 1;
      transform: translateY(0);
   }
}

.acw-is-user {
   flex-direction: row-reverse;
}

.message-avatar-ai,
.message-avatar-user {
   width: 36px;
   height: 36px;
   border-radius: 50%;
   display: flex;
   align-items: center;
   justify-content: center;
   flex-shrink: 0;
   font-size: 1rem;
}

.message-avatar-ai {
   background: var(--gradient-primary);
   color: white;
}

.message-avatar-user {
   background: var(--app-border-color);
   color: var(--app-text-color);
}

.acw-message-bubble {
   max-width: 75%;
   padding: 0.875rem 1.125rem;
   border-radius: 16px;
   display: flex;
   flex-direction: column;
   gap: 0.5rem;
}

.bubble-ai {
   background: var(--app-card-bg);
   border: 1px solid var(--app-border-color);
}

.bubble-user {
   background: var(--gradient-primary);
   color: white;
}

.acw-prose {
   font-size: 0.9375rem;
   line-height: 1.6;
}

.acw-message-timestamp {
   font-size: 0.7rem;
   opacity: 0.7;
}

.acw-typing-indicator {
   display: flex;
   gap: 0.375rem;
   padding: 1rem 1.25rem;
}

.acw-typing-indicator span {
   width: 8px;
   height: 8px;
   border-radius: 50%;
   background: var(--primary-gradient-start);
   animation: typing 1.4s infinite;
}

.acw-typing-indicator span:nth-child(2) {
   animation-delay: 0.2s;
}

.acw-typing-indicator span:nth-child(3) {
   animation-delay: 0.4s;
}

@keyframes typing {

   0%,
   60%,
   100% {
      transform: translateY(0);
      opacity: 0.5;
   }

   30% {
      transform: translateY(-8px);
      opacity: 1;
   }
}

.acw-suggestions {
   padding: 0 1.5rem 0.5rem 1.5rem;
   background: var(--app-surface);
}

.suggestion-title {
   font-size: 0.75rem;
   color: var(--app-text-muted, #6c757d);
   margin-bottom: 0.5rem;
   display: block;
   font-weight: 500;
}

.suggestion-chips {
   display: flex;
   flex-wrap: wrap;
   gap: 0.5rem;
}

.chip-btn {
   background: var(--app-card-bg);
   border: 1px solid var(--app-border-color);
   color: var(--app-text-color);
   padding: 0.4rem 0.75rem;
   border-radius: 20px;
   font-size: 0.8rem;
   cursor: pointer;
   transition: all 0.2s ease;
   display: flex;
   align-items: center;
   gap: 0.3rem;
}

.chip-btn:hover {
   background: var(--gradient-primary);
   color: white;
   border-color: transparent;
   transform: translateY(-2px);
}

.chip-btn:hover i {
   color: white !important;
}

.acw-input-area {
   padding: 1rem;
   background: var(--app-card-bg);
   border-top: 1px solid var(--app-border-color);
}

.input-form-modern {
   display: flex;
   gap: 0.625rem;
}

.input-modern {
   flex: 1;
   padding: 0.875rem 1.125rem;
   background: var(--app-surface);
   border: 2px solid var(--app-border-color);
   border-radius: 12px;
   color: var(--app-text-color);
   font-size: 0.9375rem;
   transition: all 0.3s ease;
}

.input-modern:focus {
   outline: none;
   border-color: var(--primary-gradient-start);
   box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.1);
}

.btn-send-modern {
   width: 48px;
   height: 48px;
   border-radius: 12px;
   border: none;
   background: var(--gradient-primary);
   color: white;
   display: flex;
   align-items: center;
   justify-content: center;
   cursor: pointer;
   transition: all 0.3s ease;
   font-size: 1.125rem;
}

.btn-send-modern:hover:not(:disabled) {
   transform: scale(1.1) rotate(10deg);
   box-shadow: 0 4px 12px rgba(139, 92, 246, 0.4);
}

.btn-send-modern:disabled {
   opacity: 0.5;
   cursor: not-allowed;
}

.acw-fab {
   width: 64px;
   height: 64px;
   border-radius: 50%;
   background: var(--gradient-primary);
   border: none;
   color: white;
   font-size: 1.75rem;
   display: flex;
   align-items: center;
   justify-content: center;
   cursor: pointer;
   box-shadow: 0 8px 24px rgba(139, 92, 246, 0.5);
   transition: all 0.3s cubic-bezier(0.23, 1, 0.32, 1);
}

.acw-fab:hover {
   transform: scale(1.15);
   box-shadow: 0 12px 32px rgba(139, 92, 246, 0.6);
}

.acw-fab.is-open {
   transform: rotate(90deg);
}

.acw-fab-icon-fade-enter-active,
.acw-fab-icon-fade-leave-active {
   transition: transform 0.3s ease, opacity 0.3s ease;
}

.acw-fab-icon-fade-enter-from {
   transform: rotate(-180deg);
   opacity: 0;
}

.acw-fab-icon-fade-leave-to {
   transform: rotate(180deg);
   opacity: 0;
}

@media (max-width: 768px) {
   .acw-widget {
      bottom: 1rem;
      right: 1rem;
      left: 1rem;
   }

   .acw-window {
      width: auto;
      right: 0;
      left: 0;
      bottom: 70px;
      height: 500px;
      max-height: calc(100vh - 100px);
      border-radius: 16px;
   }

   .acw-messages {
      padding: 1rem;
   }

   .acw-fab {
      width: 56px;
      height: 56px;
      font-size: 1.5rem;
      position: absolute;
      right: 0;
      bottom: 0;
   }

   .input-modern {
      padding: 0.75rem 1rem;
   }
}
</style>

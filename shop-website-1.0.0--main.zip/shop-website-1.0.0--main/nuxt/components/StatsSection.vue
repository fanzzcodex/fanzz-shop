<template>
   <section class="stats-section">
      <div class="container">
         <div class="stats-header">
            <span class="stats-badge">PERFORMANCE</span>
            <h2 class="stats-title">Trusted &amp; Reliable</h2>
            <p class="stats-subtitle">Our commitment to excellence in numbers</p>
         </div>

         <div class="stats-row">
            <div
               v-for="(stat, index) in stats"
               :key="index"
               class="stat-card-wrapper"
            >
               <div
                  class="stat-card"
                  :class="{ 'is-visible': hasStarted }"
                  :style="{ transitionDelay: `${index * 150}ms` }"
               >
                  <div class="stat-icon-box" :style="{ background: stat.color }">
                     <i class="bi" :class="stat.icon"></i>
                  </div>
                  <div class="stat-number-row">
                     <span v-if="stat.prefix" class="stat-prefix-text">{{ stat.prefix }}</span>
                     <span class="stat-number-text">{{ hasStarted ? animatedValues[index] : '0' }}</span>
                     <span v-if="stat.suffix" class="stat-suffix-text">{{ stat.suffix }}</span>
                  </div>
                  <div class="stat-label-text">{{ stat.label }}</div>
                  <p class="stat-desc-text">{{ stat.description }}</p>
               </div>
            </div>
         </div>
      </div>
   </section>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'

const hasStarted = ref(false)
const animatedValues = ref(['0', '0', '0', '0'])
let observer = null

const stats = [
   {
      icon: 'bi-shield-check',
      value: 99.9,
      decimal: true,
      prefix: '',
      suffix: '%',
      label: 'Uptime',
      description: '24/7 availability guaranteed',
      color: 'linear-gradient(135deg, #6366f1, #8b5cf6)'
   },
   {
      icon: 'bi-people-fill',
      value: 500,
      decimal: false,
      prefix: '',
      suffix: '+',
      label: 'Happy Clients',
      description: 'Satisfied customers worldwide',
      color: 'linear-gradient(135deg, #ec4899, #f43f5e)'
   },
   {
      icon: 'bi-box-seam',
      value: 50,
      decimal: false,
      prefix: '',
      suffix: '+',
      label: 'Products',
      description: 'Premium digital products',
      color: 'linear-gradient(135deg, #06b6d4, #3b82f6)'
   },
   {
      icon: 'bi-lightning-charge-fill',
      value: 2,
      decimal: false,
      prefix: '<',
      suffix: 'h',
      label: 'Response Time',
      description: 'Fast customer support',
      color: 'linear-gradient(135deg, #10b981, #34d399)'
   }
]

const animateNumber = (index, target, duration = 2000) => {
   const startTime = performance.now()
   const isDecimal = stats[index].decimal

   const tick = (now) => {
      const elapsed = now - startTime
      const progress = Math.min(elapsed / duration, 1)
      const ease = 1 - Math.pow(1 - progress, 4)
      const current = target * ease

      animatedValues.value[index] = isDecimal ? current.toFixed(1) : String(Math.floor(current))

      if (progress < 1) requestAnimationFrame(tick)
   }

   requestAnimationFrame(tick)
}

onMounted(() => {
   observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
         if (entry.isIntersecting && !hasStarted.value) {
            hasStarted.value = true
            stats.forEach((s, i) => {
               setTimeout(() => animateNumber(i, s.value, 2000), i * 200)
            })
         }
      })
   }, { threshold: 0.2 })

   const el = document.querySelector('.stats-section')
   if (el) observer.observe(el)
})

onUnmounted(() => {
   if (observer) observer.disconnect()
})
</script>

<style scoped>
.stats-section {
   padding: 5rem 0;
}

.stats-header {
   text-align: center;
   margin-bottom: 3.5rem;
}

.stats-badge {
   display: inline-block;
   padding: 0.4rem 1.25rem;
   background: var(--gradient-primary);
   color: white;
   font-size: 0.75rem;
   font-weight: 700;
   letter-spacing: 1.5px;
   border-radius: 50px;
   margin-bottom: 1rem;
}

.stats-title {
   font-size: 2.25rem;
   font-weight: 800;
   color: var(--app-text-color);
   margin-bottom: 0.5rem;
}

.stats-subtitle {
   font-size: 1rem;
   color: var(--app-secondary-text-color);
   margin: 0;
}

.stats-row {
   display: flex;
   flex-wrap: wrap;
   gap: 1.5rem;
   justify-content: center;
}

.stat-card-wrapper {
   flex: 1 1 220px;
   max-width: 280px;
}

.stat-card {
   display: flex;
   flex-direction: column;
   align-items: center;
   text-align: center;
   background: var(--app-card-bg);
   border: 1px solid var(--app-border-color);
   border-radius: 20px;
   padding: 2rem 1.5rem;
   opacity: 0;
   transform: translateY(30px);
   transition: opacity 0.6s ease, transform 0.6s ease, box-shadow 0.3s ease, border-color 0.3s ease;
}

.stat-card.is-visible {
   opacity: 1;
   transform: translateY(0);
}

.stat-card:hover {
   transform: translateY(-8px) !important;
   box-shadow: 0 16px 40px rgba(99, 102, 241, 0.15);
   border-color: var(--primary-gradient-start);
}

.stat-icon-box {
   width: 56px;
   height: 56px;
   display: flex;
   align-items: center;
   justify-content: center;
   border-radius: 16px;
   color: white;
   font-size: 1.5rem;
   margin-bottom: 1.25rem;
   transition: transform 0.3s ease;
}

.stat-card:hover .stat-icon-box {
   transform: scale(1.15) rotate(5deg);
}

.stat-number-row {
   display: flex;
   align-items: baseline;
   justify-content: center;
   gap: 2px;
   margin-bottom: 0.5rem;
}

.stat-prefix-text,
.stat-suffix-text {
   font-size: 1.75rem;
   font-weight: 700;
   color: var(--primary-gradient-start);
}

.stat-number-text {
   font-size: 2.75rem;
   font-weight: 800;
   background: var(--gradient-primary);
   -webkit-background-clip: text;
   -webkit-text-fill-color: transparent;
   background-clip: text;
   line-height: 1;
}

.stat-label-text {
   font-size: 0.8rem;
   font-weight: 700;
   color: var(--app-text-color);
   text-transform: uppercase;
   letter-spacing: 1.5px;
   margin-bottom: 0.5rem;
}

.stat-desc-text {
   font-size: 0.8rem;
   color: var(--app-secondary-text-color);
   margin: 0;
   line-height: 1.5;
}

@media (max-width: 768px) {
   .stat-card-wrapper {
      flex: 1 1 140px;
      max-width: 48%;
   }

   .stat-card {
      padding: 1.5rem 1rem;
   }

   .stat-number-text {
      font-size: 2rem;
   }

   .stat-icon-box {
      width: 48px;
      height: 48px;
      font-size: 1.25rem;
   }

   .stats-title {
      font-size: 1.75rem;
   }
}
</style>

<template>
   <Teleport to="body">
      <transition name="toast-slide">
         <div v-if="visible" class="login-toast-overlay" @click.self="dismiss">
            <div class="login-toast-card">
               <!-- Decorative sparkles -->
               <div class="toast-sparkle ts-1"></div>
               <div class="toast-sparkle ts-2"></div>
               <div class="toast-sparkle ts-3"></div>

               <!-- Checkmark circle -->
               <div class="check-ring">
                  <div class="check-ring-glow"></div>
                  <svg class="check-svg" viewBox="0 0 52 52" fill="none">
                     <circle class="check-circle" cx="26" cy="26" r="24" stroke="currentColor" stroke-width="2.5" />
                     <path class="check-path" d="M15 27 L22 34 L37 19" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                  </svg>
               </div>

               <h3 class="toast-title">Login Berhasil!</h3>
               <p class="toast-message">
                  Selamat datang kembali. Anda berhasil masuk ke akun Anda.
               </p>

               <div class="toast-progress">
                  <div class="toast-progress-fill" :style="{ animationDuration: duration + 'ms' }"></div>
               </div>
            </div>
         </div>
      </transition>
   </Teleport>
</template>

<script setup lang="ts">
import { ref, onMounted, onBeforeUnmount } from 'vue'

const props = defineProps({
   duration: { type: Number, default: 4000 },
})

const emit = defineEmits(['done'])

const visible = ref(false)
let timer: ReturnType<typeof setTimeout> | null = null

const dismiss = () => {
   visible.value = false
   emit('done')
}

onMounted(() => {
   requestAnimationFrame(() => { visible.value = true })
   timer = setTimeout(dismiss, props.duration)
})

onBeforeUnmount(() => { if (timer) clearTimeout(timer) })
</script>

<style scoped>
.login-toast-overlay {
   position: fixed;
   inset: 0;
   z-index: 99999998;
   display: flex;
   align-items: center;
   justify-content: center;
   background: rgba(0, 0, 0, 0.35);
   backdrop-filter: blur(4px);
   -webkit-backdrop-filter: blur(4px);
}

.login-toast-card {
   position: relative;
   background: var(--app-card-bg);
   border: 1px solid var(--app-border-color);
   border-radius: 20px;
   padding: 2.5rem 2rem 2rem;
   width: 380px;
   max-width: 90vw;
   text-align: center;
   box-shadow:
      0 24px 80px rgba(0, 0, 0, 0.18),
      0 0 0 1px rgba(139, 92, 246, 0.08),
      0 0 60px rgba(139, 92, 246, 0.06);
   overflow: hidden;
}

/* Sparkles */
.toast-sparkle {
   position: absolute;
   width: 6px;
   height: 6px;
   border-radius: 50%;
   background: var(--primary-gradient-start);
   pointer-events: none;
   animation: sparkle-pop 2s ease-in-out infinite;
}
.ts-1 { top: 18%; left: 14%; animation-delay: 0s; }
.ts-2 { top: 12%; right: 18%; animation-delay: 0.7s; }
.ts-3 { bottom: 22%; right: 12%; animation-delay: 1.3s; }

@keyframes sparkle-pop {
   0%, 100% { opacity: 0; transform: scale(0.5); }
   50%      { opacity: 0.6; transform: scale(1.4); }
}

/* Checkmark ring */
.check-ring {
   position: relative;
   width: 72px;
   height: 72px;
   margin: 0 auto 1.25rem;
   display: flex;
   align-items: center;
   justify-content: center;
}

.check-ring-glow {
   position: absolute;
   inset: -8px;
   border-radius: 50%;
   background: linear-gradient(135deg, rgba(34, 197, 94, 0.2), rgba(16, 185, 129, 0.12));
   filter: blur(12px);
   animation: glow-pulse 2s ease-in-out infinite;
}

@keyframes glow-pulse {
   0%, 100% { opacity: 0.6; transform: scale(1); }
   50%      { opacity: 1;   transform: scale(1.1); }
}

.check-svg {
   width: 52px;
   height: 52px;
   color: #22c55e;
   position: relative;
   z-index: 1;
}

.check-circle {
   fill: none;
   stroke-dasharray: 160;
   stroke-dashoffset: 160;
   animation: circle-draw 0.6s 0.2s cubic-bezier(0.65, 0, 0.35, 1) forwards;
}

.check-path {
   fill: none;
   stroke-dasharray: 50;
   stroke-dashoffset: 50;
   animation: check-draw 0.4s 0.7s cubic-bezier(0.65, 0, 0.35, 1) forwards;
}

@keyframes circle-draw {
   to { stroke-dashoffset: 0; }
}
@keyframes check-draw {
   to { stroke-dashoffset: 0; }
}

/* Text */
.toast-title {
   font-size: 1.375rem;
   font-weight: 800;
   color: var(--app-text-color);
   margin-bottom: 0.5rem;
   animation: toast-text-in 0.5s 0.4s cubic-bezier(0.16, 1, 0.3, 1) both;
}

.toast-message {
   font-size: 0.9375rem;
   color: var(--app-secondary-text-color);
   line-height: 1.6;
   margin-bottom: 1.5rem;
   animation: toast-text-in 0.5s 0.55s cubic-bezier(0.16, 1, 0.3, 1) both;
}

@keyframes toast-text-in {
   from { opacity: 0; transform: translateY(10px); }
   to   { opacity: 1; transform: translateY(0); }
}

/* Progress bar auto-dismiss */
.toast-progress {
   position: absolute;
   bottom: 0;
   left: 0;
   right: 0;
   height: 3px;
   background: var(--app-border-color);
}

.toast-progress-fill {
   height: 100%;
   background: var(--gradient-primary);
   animation: progress-shrink linear forwards;
   animation-duration: inherit;
   border-radius: 0 3px 3px 0;
}

@keyframes progress-shrink {
   from { width: 100%; }
   to   { width: 0%; }
}

/* Transitions */
.toast-slide-enter-active {
   transition: opacity 0.35s ease;
}
.toast-slide-enter-active .login-toast-card {
   animation: card-pop 0.5s cubic-bezier(0.16, 1, 0.3, 1);
}
.toast-slide-leave-active {
   transition: opacity 0.3s ease;
}
.toast-slide-enter-from,
.toast-slide-leave-to {
   opacity: 0;
}
.toast-slide-leave-to .login-toast-card {
   transform: scale(0.92);
   opacity: 0;
}

@keyframes card-pop {
   from { opacity: 0; transform: scale(0.88) translateY(20px); }
   to   { opacity: 1; transform: scale(1) translateY(0); }
}
</style>

<template>
    <Transition name="fade">
        <div v-if="!isVerified"
            class="security-overlay d-flex flex-column justify-content-center align-items-center text-center">
            <div class="glass-security-card p-5 animate-slide-up">
                <!-- Icon -->
                <div class="icon-wrapper mb-4 mx-auto d-flex justify-content-center align-items-center">
                    <i v-if="verifying" class="bi bi-shield-lock-fill display-4 text-warning pulse-animation"></i>
                    <i v-else class="bi bi-shield-check-fill display-4 text-success bounce-animation"></i>
                </div>

                <h3 class="fw-bold mb-3 text-white">Yilzi Shop Protection</h3>

                <div v-if="verifying">
                    <p class="text-secondary mb-4">Memverifikasi koneksi aman. Harap tunggu sebentar...</p>

                    <div class="verification-progress">
                        <div class="progress"
                            style="height: 8px; background: rgba(255,255,255,0.1); border-radius: 10px;">
                            <div class="progress-bar progress-bar-striped progress-bar-animated bg-warning"
                                role="progressbar" :style="{ width: progress + '%' }"></div>
                        </div>
                        <div class="d-flex justify-content-between mt-2 small text-secondary">
                            <span>Checking browser...</span>
                            <span>{{ progress }}%</span>
                        </div>
                    </div>

                    <p
                        class="mt-4 small text-secondary opacity-50 d-flex align-items-center justify-content-center gap-2">
                        <i class="bi bi-cloud-check"></i> Secured by Cloudflare Tunnel
                    </p>
                </div>

                <div v-else>
                    <p class="text-success fw-bold mb-0 fs-5 pb-3">Koneksi Aman! Melanjutkan ke website...</p>
                </div>
            </div>
        </div>
    </Transition>
</template>

<script setup>
import { ref, onMounted } from 'vue'

const isVerified = ref(true)
const verifying = ref(true)
const progress = ref(0)

onMounted(() => {
    // Cek apakah user sudah masuk sesi ini
    const hasPassedCheck = sessionStorage.getItem('security_passed')

    if (!hasPassedCheck) {
        isVerified.value = false

        // Simulasi progress checking
        const interval = setInterval(() => {
            progress.value += Math.floor(Math.random() * 20) + 10

            if (progress.value >= 100) {
                progress.value = 100
                clearInterval(interval)

                // Verifikasi Selesai
                verifying.value = false

                setTimeout(() => {
                    isVerified.value = true
                    sessionStorage.setItem('security_passed', 'true')
                }, 1000) // Delay setelah centang hijau
            }
        }, 500)
    }
})
</script>

<style scoped>
.security-overlay {
    position: fixed;
    inset: 0;
    background: var(--app-bg);
    z-index: 99999;
}

.glass-security-card {
    background: rgba(30, 41, 59, 0.4);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 24px;
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    box-shadow: 0 30px 60px rgba(0, 0, 0, 0.4);
    max-width: 450px;
    width: 90%;
}

.icon-wrapper {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.1);
}

.pulse-animation {
    animation: pulse 1.5s infinite;
}

.bounce-animation {
    animation: bounce 0.5s ease;
}

.animate-slide-up {
    animation: slideUp 0.6s cubic-bezier(0.16, 1, 0.3, 1) both;
}

@keyframes pulse {
    0% {
        transform: scale(0.9);
        opacity: 0.8;
    }

    50% {
        transform: scale(1.1);
        opacity: 1;
    }

    100% {
        transform: scale(0.9);
        opacity: 0.8;
    }
}

@keyframes bounce {
    0% {
        transform: scale(0);
    }

    60% {
        transform: scale(1.2);
    }

    100% {
        transform: scale(1);
    }
}

@keyframes slideUp {
    0% {
        opacity: 0;
        transform: translateY(40px);
    }

    100% {
        opacity: 1;
        transform: translateY(0);
    }
}

.fade-enter-active,
.fade-leave-active {
    transition: opacity 0.5s ease;
}

.fade-enter-from,
.fade-leave-to {
    opacity: 0;
}
</style>

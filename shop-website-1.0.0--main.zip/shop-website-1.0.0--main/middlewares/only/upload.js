import multer from 'multer'
import path from 'path'
import fs from 'fs'
import { imgkub, crypty, studiointermedia } from '@neoxr/helper'
import Jimp from 'jimp'
import { Utils } from '../../lib/index.js'

const productUploads = multer({
   storage: multer.memoryStorage(),
   limits: { fileSize: 25 * 1024 * 1024 }
}).fields([
   { name: 'image', maxCount: 1 },
   { name: 'previews', maxCount: 6 },
   { name: 'file', maxCount: 1 }
])

const processFiles = async (req, res, next) => {
   try {
      if (req.files?.image) {
         const imageFile = req.files.image[0]
         const image = await Jimp.read(imageFile.buffer)
         image.cover(1080, 1080)
         const croppedBuffer = await image.getBufferAsync(imageFile.mimetype)
         const result = await imgkub(croppedBuffer)
         if (result?.data?.url) req.body.imageUrl = result.data.url
      }

      let currentPreviews = []
      if (req.body.preview_images) {
         try {
            currentPreviews = JSON.parse(req.body.preview_images)
         } catch (e) {
            currentPreviews = []
         }
      }

      if (req.files?.previews) {
         for (const file of req.files.previews) {
            // const img = await Jimp.read(file.buffer)
            // img.cover(1080, 1080)
            // const buf = await img.getBufferAsync(file.mimetype)
            const result = await studiointermedia(file.buffer)
            if (result?.data?.url) currentPreviews.push(result.data.url)
         }
      }

      req.body.preview_images = currentPreviews

      if (req.files?.file) {
         const productFile = req.files.file[0]
         const destination = req.body.file_upload_destination
         const extension = path.extname(productFile.originalname).slice(1)

         const fileObject = {
            bytes: productFile.size,
            size: Utils.formatBytes(productFile.size),
            mime: productFile.mimetype,
            extension: extension,
            type: 'local',
            data: ''
         }

         if (destination === 'cloud') {
            const result = await crypty(productFile.buffer)
            if (!result?.data?.url) throw new Error('Gagal mengunggah file ke Quax.')
            fileObject.type = 'cloud'
            fileObject.data = result.data.url
         } else {
            const targetDir = path.join(process.cwd(), 'public', 'files')
            if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir, { recursive: true })
            const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
            const newFilename = `${uniqueSuffix}-${productFile.originalname.replace(/\s/g, '_')}`
            const filePath = path.join(targetDir, newFilename)
            fs.writeFileSync(filePath, productFile.buffer)
            fileObject.type = 'local'
            fileObject.data = `/files/${newFilename}`
         }
         req.body.file = fileObject
      } else if (req.body.file_url) {
         req.body.file = {
            type: 'cloud',
            data: req.body.file_url,
            size: null, bytes: null, mime: null, extension: null
         }
      } else if (req.body.file === '' || req.body.file === 'null') {
         req.body.file = null
      }

      if (req.body.additional_information && typeof req.body.additional_information === 'string') {
         try {
            req.body.additional_information = JSON.parse(req.body.additional_information)
         } catch (e) {
            req.body.additional_information = []
         }
      }

      next()
   } catch (error) {
      next(error)
   }
}

export { productUploads, processFiles }
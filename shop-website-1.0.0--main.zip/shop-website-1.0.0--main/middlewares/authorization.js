import jwt from 'jsonwebtoken'
import { Database } from '../lib/index.js'


export default route => async (req, res, next) => {
   try {
      const authorization = req.headers['authorization']
      let token = authorization?.split(' ')?.[1]?.trim()

      // Fallback to session cookie token if header is missing (important for refresh)
      if (!token && req.session?.token) {
         token = req.session.token
      }

      if (!token) {
         return res.status(401).json({
            creator: global.creator,
            status: false,
            msg: 'Oops!, kamu harus login terlebih dahulu'
         })
      }

      let payload
      try {
         payload = jwt.verify(token, process.env.JWT_SECRET)
      } catch (err) {
         return res.status(401).json({
            creator: global.creator,
            status: false,
            msg: 'Unauthorized: Invalid or expired token'
         })
      }

      const { type, email } = payload

      // Fix: Query the DB to check if the user is currently blocked.
      const userRes = await Database.getUser(email)
      if (userRes.status && userRes.data?.status === 'blocked') {
         return res.status(401).json({
            creator: global.creator,
            status: false,
            msg: `Akun Anda telah diblokir. Alasan: ${userRes.data?.blockReason || 'Melanggar ketentuan.'}`
         })
      }

      // Attach user info to request for downstream routes
      req.user = { email, type }

      if (route.category === 'v2' && type !== 'admin') {
         return res.status(403).json({
            creator: global.creator,
            status: false,
            msg: 'Forbidden: You must be an admin to access this resource'
         })
      }

      next()
   } catch (e) {
      Utils.printError(e)
      res.status(500).json({
         creator: global.creator,
         status: false,
         msg: 'Internal Server Error'
      })
   }
}
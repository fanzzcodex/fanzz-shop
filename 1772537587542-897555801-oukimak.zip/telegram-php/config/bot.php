<?php
return [
    'bot' => [
        'token' => '8171054320:AAH6bl1X78luPjctY5wQ2xxi-LGarS-SsgA',
        'username' => 'YilziBaseBot',
        'owner_id' => 6614903056,
        'owner_username' => '@Yilziii'
    ],
    'ai' => [
        'provider' => 'gemini',
        'default_character' => 'cewe',
        'default_state' => false,
        'api_endpoint' => 'http://localhost:8000/api/gemini.php'
    ],
    'paths' => [
        'database' => 'assets/database',
        'prompts' => 'global/prompts',
        'config' => 'config'
    ]
];
?>
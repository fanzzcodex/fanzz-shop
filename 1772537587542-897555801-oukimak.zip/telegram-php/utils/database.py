import json
import os
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

class Database:
    def __init__(self):
        self.db_path = os.getenv('DATABASE_PATH', 'assets/database')
        os.makedirs(self.db_path, exist_ok=True)
        
        self.users_file = os.path.join(self.db_path, 'users.json')
        self.chats_file = os.path.join(self.db_path, 'chats.json')
        self.stats_file = os.path.join(self.db_path, 'stats.json')
        
        self.init_files()
    
    def init_files(self):
        for file_path in [self.users_file, self.chats_file, self.stats_file]:
            if not os.path.exists(file_path):
                with open(file_path, 'w', encoding='utf-8') as f:
                    if 'users' in file_path:
                        json.dump({}, f)
                    elif 'chats' in file_path:
                        json.dump([], f)
                    else:
                        json.dump({
                            'total_users': 0,
                            'total_chats': 0,
                            'new_today': 0,
                            'active_7days': 0,
                            'start_date': datetime.now().strftime('%d/%m/%Y %H:%M')
                        }, f)
    
    def save_user(self, user_id, username, first_name):
        with open(self.users_file, 'r', encoding='utf-8') as f:
            users = json.load(f)
        
        user_str = str(user_id)
        if user_str not in users:
            users[user_str] = {
                'username': username,
                'first_name': first_name,
                'join_date': datetime.now().strftime('%d/%m/%Y %H:%M'),
                'first_seen': datetime.now().strftime('%d/%m/%Y %H:%M'),
                'message_count': 1,
                'last_seen': datetime.now().strftime('%d/%m/%Y %H:%M')
            }
        else:
            users[user_str]['last_seen'] = datetime.now().strftime('%d/%m/%Y %H:%M')
            users[user_str]['message_count'] = users[user_str].get('message_count', 0) + 1
        
        with open(self.users_file, 'w', encoding='utf-8') as f:
            json.dump(users, f, indent=2, ensure_ascii=False)
        
        self.update_stats()
    
    def save_chat(self, user_id, message, sender='user'):
        with open(self.chats_file, 'r', encoding='utf-8') as f:
            chats = json.load(f)
        
        chats.append({
            'user_id': user_id,
            'message': message[:500],  # Limit panjang
            'sender': sender,
            'timestamp': datetime.now().strftime('%d/%m/%Y %H:%M:%S')
        })
        
        # Keep only last 1000 chats
        if len(chats) > 1000:
            chats = chats[-1000:]
        
        with open(self.chats_file, 'w', encoding='utf-8') as f:
            json.dump(chats, f, indent=2, ensure_ascii=False)
        
        self.update_stats()
    
    def get_user(self, user_id):
        with open(self.users_file, 'r', encoding='utf-8') as f:
            users = json.load(f)
        
        user_str = str(user_id)
        return users.get(user_str, {})
    
    def get_all_users(self):
        with open(self.users_file, 'r', encoding='utf-8') as f:
            users = json.load(f)
        
        return [int(user_id) for user_id in users.keys()]
    
    def update_stats(self):
        with open(self.users_file, 'r', encoding='utf-8') as f:
            users = json.load(f)
        
        with open(self.chats_file, 'r', encoding='utf-8') as f:
            chats = json.load(f)
        
        today = datetime.now().strftime('%d/%m/%Y')
        today_users = sum(1 for user in users.values() if user['join_date'].startswith(today))
        
        # Hitung active users (last seen < 7 hari)
        active_users = 0
        for user in users.values():
            try:
                last_seen = datetime.strptime(user['last_seen'], '%d/%m/%Y %H:%M')
                days_diff = (datetime.now() - last_seen).days
                if days_diff < 7:
                    active_users += 1
            except:
                active_users += 1
        
        with open(self.stats_file, 'w', encoding='utf-8') as f:
            json.dump({
                'total_users': len(users),
                'total_chats': len(chats),
                'new_today': today_users,
                'active_7days': active_users,
                'start_date': datetime.now().strftime('%d/%m/%Y %H:%M')
            }, f, indent=2)
    
    def get_stats(self):
        with open(self.stats_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def create_backup(self):
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_dir = os.path.join(self.db_path, 'backups')
        os.makedirs(backup_dir, exist_ok=True)
        
        backup_file = os.path.join(backup_dir, f'backup_{timestamp}.json')
        
        data = {
            'users': self.load_json(self.users_file),
            'chats': self.load_json(self.chats_file),
            'stats': self.load_json(self.stats_file),
            'backup_time': timestamp,
            'backup_date': datetime.now().strftime('%d/%m/%Y %H:%M:%S')
        }
        
        with open(backup_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        return backup_file
    
    def load_json(self, file_path):
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)
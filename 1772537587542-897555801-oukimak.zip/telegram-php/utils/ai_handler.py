import os
import json
import random
from datetime import datetime

class AIHandler:
    def __init__(self, prompts_path="global/prompts"):
        self.prompts_path = prompts_path
        self.characters = self.load_characters()
        self.responses = {
            "greetings": [
                "Hai! Ada yang bisa aku bantu? 😊",
                "Halo~! Senang berbicara denganmu! ✨",
                "Yo! Apa kabar hari ini? 🌟",
                "Hai hai~! Mau ngobrol apa nih? 💬"
            ],
            "unknown": [
                "Maaf, aku belum paham maksudmu 😅",
                "Bisa diulangi? Aku kurang mengerti~",
                "Hmm, tentang apa ya itu? 🤔",
                "Aku masih belajar, coba tanya hal lain dulu~"
            ],
            "help": [
                "Ketik 'menu' untuk melihat pilihan! 📋",
                "Coba ketik 'help' untuk bantuan ya! 🆘",
                "Gunakan button di bawah untuk navigasi~ 🎯"
            ]
        }
    
    def load_characters(self):
        """Load semua karakter dari folder prompts"""
        characters = {}
        if os.path.exists(self.prompts_path):
            for file in os.listdir(self.prompts_path):
                if file.endswith('.txt'):
                    char_name = file.replace('.txt', '')
                    file_path = os.path.join(self.prompts_path, file)
                    with open(file_path, 'r', encoding='utf-8') as f:
                        characters[char_name] = f.read()
        return characters
    
    def get_ai_response(self, user_message, character="yuri", chat_history=None):
        """Generate AI response berdasarkan karakter"""
        if character not in self.characters:
            character = "assistant"
        
        prompt = self.characters.get(character, "")
        
        # Simple rule-based AI (bisa diganti dengan API nanti)
        message_lower = user_message.lower()
        
        # Cek jenis pesan
        if any(word in message_lower for word in ['hai', 'hello', 'halo', 'hi', 'p']):
            return random.choice(self.responses["greetings"])
        
        elif any(word in message_lower for word in ['makasih', 'terima kasih', 'thanks']):
            return "Sama-sama~! Senang bisa membantu! 💖" if character == "yuri" else "Sama-sama, senang membantu!"
        
        elif any(word in message_lower for word in ['nama', 'siapa kamu']):
            if character == "yuri":
                return "Aku Yuri~! Gadis anime yang siap membantumu! 💫"
            else:
                return "Saya asisten AI Yilzi Bot."
        
        elif any(word in message_lower for word in ['menu', 'bantuan', 'help']):
            return random.choice(self.responses["help"])
        
        elif any(word in message_lower for word in ['lagu', 'musik', 'music']):
            return "Wah, aku suka musik juga! 🎵 Rekomendasi lagu apa ya~?"
        
        elif any(word in message_lower for word in ['film', 'movie', 'anime']):
            return "Kalo anime, aku suka yang genre slice of life! 🍿"
        
        # Default response berdasarkan karakter
        if character == "yuri":
            responses = [
                f"Wah, tentang {user_message} ya~! Menarik sekali! ✨",
                f"Aku denger kamu bilang {user_message}~ Coba cerita lebih detail dong! 💭",
                f"Hmm... {user_message}... Aku pikir itu ide yang bagus! 🌈",
                f"Seru banget ngomongin {user_message} sama kamu! 😊"
            ]
        elif character == "teacher":
            responses = [
                f"Pertanyaan tentang {user_message}? Mari kita pelajari bersama.",
                f"{user_message} adalah topik yang menarik untuk didiskusikan.",
                f"Saya akan menjelaskan tentang {user_message} dengan sederhana."
            ]
        else:  # assistant
            responses = [
                f"Tentang {user_message}, saya bisa bantu menjelaskan.",
                f"{user_message} adalah topik yang bagus untuk dibahas.",
                f"Saya memahami maksud Anda tentang {user_message}."
            ]
        
        return random.choice(responses)
    
    def toggle_ai(self, user_id, state=None):
        """Toggle AI mode untuk user tertentu"""
        settings_file = "assets/database/ai_settings.json"
        
        # Load atau buat file settings
        if os.path.exists(settings_file):
            with open(settings_file, 'r', encoding='utf-8') as f:
                settings = json.load(f)
        else:
            settings = {}
        
        user_key = str(user_id)
        
        if state is not None:
            # Set state spesifik
            settings[user_key] = {
                "ai_enabled": state,
                "character": "yuri",
                "last_updated": datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
        else:
            # Toggle state
            if user_key in settings:
                current = settings[user_key].get("ai_enabled", False)
                settings[user_key]["ai_enabled"] = not current
                settings[user_key]["last_updated"] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            else:
                settings[user_key] = {
                    "ai_enabled": True,
                    "character": "yuri",
                    "last_updated": datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                }
        
        # Save settings
        with open(settings_file, 'w', encoding='utf-8') as f:
            json.dump(settings, f, indent=2, ensure_ascii=False)
        
        current_state = settings[user_key]["ai_enabled"]
        character = settings[user_key].get("character", "yuri")
        
        return current_state, character
    
    def get_ai_state(self, user_id):
        """Get AI state untuk user"""
        settings_file = "assets/database/ai_settings.json"
        
        if os.path.exists(settings_file):
            with open(settings_file, 'r', encoding='utf-8') as f:
                settings = json.load(f)
            
            user_key = str(user_id)
            if user_key in settings:
                return settings[user_key].get("ai_enabled", False)
        
        return False
    
    def set_character(self, user_id, character):
        """Set karakter AI untuk user"""
        settings_file = "assets/database/ai_settings.json"
        
        if os.path.exists(settings_file):
            with open(settings_file, 'r', encoding='utf-8') as f:
                settings = json.load(f)
        else:
            settings = {}
        
        user_key = str(user_id)
        
        if user_key not in settings:
            settings[user_key] = {
                "ai_enabled": True,
                "character": character,
                "last_updated": datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
        else:
            settings[user_key]["character"] = character
            settings[user_key]["last_updated"] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        # Save settings
        with open(settings_file, 'w', encoding='utf-8') as f:
            json.dump(settings, f, indent=2, ensure_ascii=False)
        
        return character
    
    def list_characters(self):
        """List semua karakter yang tersedia"""
        return list(self.characters.keys())
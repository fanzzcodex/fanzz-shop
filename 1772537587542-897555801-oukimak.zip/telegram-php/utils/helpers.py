import time
from datetime import datetime

class Helpers:
    def __init__(self):
        self.start_time = time.time()
    
    def get_uptime(self):
        seconds = int(time.time() - self.start_time)
        days, seconds = divmod(seconds, 86400)
        hours, seconds = divmod(seconds, 3600)
        minutes, seconds = divmod(seconds, 60)
        
        if days > 0:
            return f"{days}d {hours}h {minutes}m"
        elif hours > 0:
            return f"{hours}h {minutes}m {seconds}s"
        else:
            return f"{minutes}m {seconds}s"
    
    def format_date(self, date_string):
        try:
            dt = datetime.strptime(date_string, '%d/%m/%Y %H:%M')
            return dt.strftime('%A, %d %B %Y %H:%M')
        except:
            return date_string
        
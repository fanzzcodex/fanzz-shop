from telegram import InlineKeyboardButton, InlineKeyboardMarkup

class Keyboards:
    def main_menu(self, user_id, ai_enabled=False):
        """Menu utama dengan status AI"""
        keyboard = []
        
        # AI Controls
        if ai_enabled:
            keyboard.append([
                InlineKeyboardButton("🤖 AI: ON ✅", callback_data="ai_status"),
                InlineKeyboardButton("🚫 AI Off", callback_data="ai_off")
            ])
            keyboard.append([
                InlineKeyboardButton("🎭 Karakter", callback_data="characters"),
                InlineKeyboardButton("💬 Chat", callback_data="ai_on")
            ])
        else:
            keyboard.append([
                InlineKeyboardButton("🤖 AI: OFF ❌", callback_data="ai_status"),
                InlineKeyboardButton("✅ AI On", callback_data="ai_on")
            ])
        
        # Main menu
        keyboard.append([
            InlineKeyboardButton("📊 Stats", callback_data="stats"),
            InlineKeyboardButton("👤 Profile", callback_data="profile")
        ])
        
        keyboard.append([
            InlineKeyboardButton("ℹ️ About", callback_data="about"),
            InlineKeyboardButton("🆘 Help", callback_data="help")
        ])
        
        # External links
        keyboard.append([
            InlineKeyboardButton("🌐 Website", url="https://yilzicode.com"),
            InlineKeyboardButton("📁 GitHub", url="https://github.com/YilziiHCT")
        ])
        
        return InlineKeyboardMarkup(keyboard)
    
    def ai_chat_menu(self):
        """Menu saat chat dengan AI"""
        keyboard = [
            [
                InlineKeyboardButton("🎭 Ganti Karakter", callback_data="characters"),
                InlineKeyboardButton("🚫 AI Off", callback_data="ai_off")
            ],
            [
                InlineKeyboardButton("📋 Menu", callback_data="menu"),
                InlineKeyboardButton("🆘 Help", callback_data="help")
            ]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    def character_selection(self, characters):
        """Keyboard untuk memilih karakter"""
        keyboard = []
        
        # Buat button per karakter (2 per baris)
        for i in range(0, len(characters), 2):
            row = []
            if i < len(characters):
                row.append(InlineKeyboardButton(
                    characters[i].capitalize(), 
                    callback_data=f"char_{characters[i]}"
                ))
            if i + 1 < len(characters):
                row.append(InlineKeyboardButton(
                    characters[i + 1].capitalize(), 
                    callback_data=f"char_{characters[i + 1]}"
                ))
            if row:
                keyboard.append(row)
        
        # Tambahkan back button
        keyboard.append([
            InlineKeyboardButton("🔙 Kembali", callback_data="menu")
        ])
        
        return InlineKeyboardMarkup(keyboard)
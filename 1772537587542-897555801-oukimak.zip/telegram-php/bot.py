import os
import json
import logging
import asyncio
import random
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, ContextTypes, filters

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

class Config:
    def __init__(self):
        try:
            with open('config/bot.php', 'r') as f:
                content = f.read()
                import re
                token_match = re.search(r"'token'\s*=>\s*'([^']+)'", content)
                self.token = token_match.group(1) if token_match else ''
        except:
            self.token = os.getenv('BOT_TOKEN', '')
        
        if not self.token:
            raise ValueError("Bot token tidak ditemukan")

class Database:
    def __init__(self):
        self.db_path = "assets/database"
        os.makedirs(self.db_path, exist_ok=True)
        self.users_file = f"{self.db_path}/users.json"
        self.chats_file = f"{self.db_path}/chats.json"
        self.ai_file = f"{self.db_path}/ai_settings.json"
        self.init_files()
    
    def init_files(self):
        for file_path, default_data in [
            (self.users_file, {}),
            (self.chats_file, []),
            (self.ai_file, {})
        ]:
            if not os.path.exists(file_path):
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump(default_data, f, ensure_ascii=False, indent=2)
    
    def save_user(self, user_id, username, first_name):
        with open(self.users_file, 'r', encoding='utf-8') as f:
            users = json.load(f)
        
        user_key = str(user_id)
        if user_key not in users:
            users[user_key] = {
                "username": username,
                "first_name": first_name,
                "join_date": datetime.now().strftime("%d/%m/%Y %H:%M"),
                "message_count": 1,
                "last_seen": datetime.now().strftime("%d/%m/%Y %H:%M")
            }
        else:
            users[user_key]["message_count"] = users[user_key].get("message_count", 0) + 1
            users[user_key]["last_seen"] = datetime.now().strftime("%d/%m/%Y %H:%M")
        
        with open(self.users_file, 'w', encoding='utf-8') as f:
            json.dump(users, f, ensure_ascii=False, indent=2)
    
    def save_chat(self, user_id, message, sender="user"):
        with open(self.chats_file, 'r', encoding='utf-8') as f:
            chats = json.load(f)
        
        chat_entry = {
            "user_id": user_id,
            "message": message[:500],
            "sender": sender,
            "timestamp": datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        }
        chats.append(chat_entry)
        
        with open(self.chats_file, 'w', encoding='utf-8') as f:
            json.dump(chats, f, ensure_ascii=False, indent=2)
    
    def get_ai_state(self, user_id):
        with open(self.ai_file, 'r', encoding='utf-8') as f:
            ai_settings = json.load(f)
        
        user_key = str(user_id)
        return ai_settings.get(user_key, {}).get("enabled", False)
    
    def set_ai_state(self, user_id, enabled=True, character="cewe"):
        with open(self.ai_file, 'r', encoding='utf-8') as f:
            ai_settings = json.load(f)
        
        user_key = str(user_id)
        ai_settings[user_key] = {
            "enabled": enabled,
            "character": character,
            "last_updated": datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        }
        
        with open(self.ai_file, 'w', encoding='utf-8') as f:
            json.dump(ai_settings, f, ensure_ascii=False, indent=2)
        
        return enabled, character
    
    def get_character(self, user_id):
        with open(self.ai_file, 'r', encoding='utf-8') as f:
            ai_settings = json.load(f)
        
        user_key = str(user_id)
        return ai_settings.get(user_key, {}).get("character", "cewe")

class AIHandler:
    def __init__(self):
        self.responses = {
            'cewe': [
                "Haii~! Yuri di sini! Ada yang bisa aku bantu? ✨",
                "Ufufu~ senang bertemu denganmu! 💖",
                "Yo~! Apa kabar hari ini? 🌟",
                "Halo-halo~! Yuri siap menemani! 😊",
                "Wah, ada tamu! Senang banget ketemu kamu! 🥰",
                "Hai! Hari ini cerah ya~ semangat! 🌈",
                "Yuri datang~! Mau ngobrol apa nih? 💬",
                "Halo kakak~! Yuri di sini untuk kamu! 💕",
                "Hai! Siap untuk ngobrol seru? 🎉",
                "Yo! Gimana harimu? Cerita dong~ 💭",
                "Hai~! Yuri excited banget ketemu kamu! ✨",
                "Ufufu~ apa kabar nih? 💖",
                "Yo~! Ready for some fun chat? 🌟",
                "Halo~! Yuri selalu siap untuk kamu! 😊",
                "Wah~! Kamu datang! Senang banget! 🥰",
                "Hai! Hari ini awesome ya? 🌈",
                "Yuri siap~! Mau ngobrol apa? 💬",
                "Halo sayang~! Yuri di sini! 💕",
                "Hai! Let's have fun together! 🎉",
                "Yo! Cerita dong hari ini gimana? 💭"
            ],
            'cowo': [
                "Hmph. Ada apa?",
                "Ya? Mau apa?",
                "Tch. Kenapa?",
                "Hah? Emangnya?",
                "Oke. Lanjut.",
                "Ya. Apa lagi?",
                "Hmm. Begitu.",
                "Baik. Silakan.",
                "Hm. Ya.",
                "Begitu.",
                "Hmph. Jadi?",
                "Ya. Katakan.",
                "Tch. Apa?",
                "Hah? Kenapa?",
                "Oke. Continue.",
                "Ya. Next.",
                "Hmm. Okay.",
                "Baik. Go on.",
                "Hm. Sure.",
                "Begitu. Yeah."
            ]
        }
    
    async def get_response(self, message, character="cewe"):
        await asyncio.sleep(0.3)
        
        message_lower = message.lower()
        
        if 'hai' in message_lower or 'halo' in message_lower or 'hello' in message_lower:
            if character == 'cewe':
                return random.choice([
                    f"Haii~! Yuri di sini! Senang banget kamu menyapa! ✨",
                    f"Halo-halo~! Yuri senang bertemu kamu! 💖",
                    f"Yo~! Hallo juga! Apa kabar? 🌟",
                    f"Hai sayang~! Senang banget denger suaramu! 🥰",
                    f"Yo~! Hallo! Gimana nih? 😊"
                ])
            else:
                return random.choice([
                    f"Hmph. Hai.",
                    f"Ya. Hallo.",
                    f"Hah? Hai juga.",
                    f"Hm. Hai.",
                    f"Oke. Hallo."
                ])
        
        if 'nama' in message_lower or 'siapa' in message_lower:
            if character == 'cewe':
                return "Aku Yuri~! Teman virtualmu yang selalu siap menemani! 🌸"
            else:
                return "Aku Andre. Cukup tahu itu saja."
        
        if 'makasih' in message_lower or 'terima kasih' in message_lower:
            if character == 'cewe':
                return "Sama-sama~! Senang bisa membantu! 💕"
            else:
                return "Ya. Sama-sama."
        
        if 'lagu' in message_lower or 'musik' in message_lower:
            if character == 'cewe':
                return "Wah, aku suka musik~! Rekomendasi lagu favoritmu dong! 🎵"
            else:
                return "Musik? Hmm, oke lah."
        
        if 'film' in message_lower or 'anime' in message_lower:
            if character == 'cewe':
                return "Aku suka anime genre slice of life! Kamu suka apa? 🍿"
            else:
                return "Film? Whatever."
        
        if character == 'cewe':
            responses = [
                f"Wah, tentang {message} ya~! Menarik banget! 🤔",
                f"Hmm... {message}... Aku juga penasaran nih! 💭",
                f"Ceritakan lebih banyak dong tentang {message}~! 🎤",
                f"Aku denger kamu ngomongin {message}, seru ya! ✨",
                f"{message}? Itu topik yang keren banget! 🎉",
                f"Yuri suka banget dengerin cerita soal {message}! 💖",
                f"Wah, {message} itu menarik! Mau tau lebih banyak! 🤩",
                f"Aku penasaran banget sama {message}, ceritain lagi dong~ 🥰",
                f"Wah~! {message} ya? Sounds interesting! 🌈",
                f"Yo! {message}? Tell me more about it! 💫",
                f"Hai~! {message} itu keren banget ya? 💕",
                f"Ufufu~ {message}? Aku mau denger ceritanya! 🎀",
                f"Yuri excited banget denger soal {message}! ✨",
                f"Wah, {message}? That's awesome! 🎊",
                f"Hmm~ {message}... Interesting! 💭",
                f"Yuri suka topik {message}! Cerita lagi dong! 💖",
                f"Wah~! {message} itu seru banget ya? 🌟",
                f"Aku penasaran sama {message}, share more! 🥰",
                f"{message}? Sounds cool! Tell me more! 💫",
                f"Yuri tertarik banget sama {message}! 💕"
            ]
        else:
            responses = [
                f"Hmph. {message}? Boleh juga.",
                f"{message}? Ya, begitulah.",
                f"Tch. {message}. Biasa saja.",
                f"{message}? Lumayan.",
                f"Hah? {message}? Begitu.",
                f"{message}. Cukup.",
                f"{message}? Oke.",
                f"{message}. Hmm.",
                f"{message}. Yeah.",
                f"{message}. Okay.",
                f"Hmph. {message}. Whatever.",
                f"{message}? Fine.",
                f"Tch. {message}. Not bad.",
                f"{message}? Alright.",
                f"Hah? {message}? Meh.",
                f"{message}. I see.",
                f"{message}? Sure.",
                f"{message}. Got it.",
                f"{message}. Right.",
                f"{message}. Okay then."
            ]
        
        return random.choice(responses)

class Keyboards:
    def main_menu(self, ai_enabled=False):
        keyboard = []
        
        if ai_enabled:
            keyboard.append([
                InlineKeyboardButton("🤖 AI: ON", callback_data="ai_status"),
                InlineKeyboardButton("🚫 AI Off", callback_data="ai_off")
            ])
            keyboard.append([
                InlineKeyboardButton("👧 Cewe", callback_data="char_cewe"),
                InlineKeyboardButton("👦 Cowo", callback_data="char_cowo")
            ])
        else:
            keyboard.append([
                InlineKeyboardButton("🤖 AI: OFF", callback_data="ai_status"),
                InlineKeyboardButton("✅ AI On", callback_data="ai_on")
            ])
        
        keyboard.append([
            InlineKeyboardButton("📊 Stats", callback_data="stats"),
            InlineKeyboardButton("👤 Profile", callback_data="profile")
        ])
        
        keyboard.append([
            InlineKeyboardButton("ℹ️ About", callback_data="about"),
            InlineKeyboardButton("🆘 Help", callback_data="help")
        ])
        
        return InlineKeyboardMarkup(keyboard)

class YilziBot:
    def __init__(self):
        self.config = Config()
        self.token = self.config.token
        
        self.db = Database()
        self.ai = AIHandler()
        self.keyboards = Keyboards()
        self.start_time = datetime.now()
        
        self.commands = {
            "menu": self.show_menu,
            "ai on": self.ai_on,
            "ai off": self.ai_off,
            "ai status": self.ai_status,
            "help": self.help,
            "about": self.about,
            "stats": self.stats,
            "profile": self.profile,
            "ping": self.ping,
            "cewe": lambda u,c: self.set_character(u,c,"cewe"),
            "cowo": lambda u,c: self.set_character(u,c,"cowo")
        }
    
    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user = update.effective_user
        self.db.save_user(user.id, user.username, user.first_name)
        
        ai_enabled = self.db.get_ai_state(user.id)
        character = self.db.get_character(user.id)
        char_name = "Yuri" if character == "cewe" else "Andre"
        
        welcome = f"""👋 Halo *{user.first_name}*!

🤖 *Yilzi Base Bot v4.0*
✨ AI Mode: {'✅ ON' if ai_enabled else '❌ OFF'}
🎭 Karakter: {char_name}

💬 *Cara pakai:*
• Langsung ketik pesan untuk AI
• Ketik 'menu' untuk menu utama
• Ketik 'ai on/off' untuk kontrol AI
• Ketik 'cewe' atau 'cowo' untuk ganti karakter
• Tanpa prefix / required

🔧 *Powered by:*
• Advanced AI System
• JSON Database
• Interactive Menus

_Made by @Yilziii • yilzicode.com_"""
        
        await update.message.reply_text(
            welcome,
            parse_mode='Markdown',
            reply_markup=self.keyboards.main_menu(ai_enabled)
        )
    
    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user = update.effective_user
        text = update.message.text.strip()
        user_id = user.id
        
        self.db.save_chat(user_id, text, 'user')
        
        text_lower = text.lower()
        
        if text_lower in self.commands:
            await self.commands[text_lower](update, context)
            return
        
        ai_enabled = self.db.get_ai_state(user_id)
        
        if ai_enabled:
            await self.handle_ai_chat(update, context, text)
        else:
            await self.echo_response(update, context, text)
    
    async def handle_ai_chat(self, update: Update, context: ContextTypes.DEFAULT_TYPE, user_text):
        user = update.effective_user
        character = self.db.get_character(user.id)
        
        logger.info(f"AI Request: {user.id} -> {character}: {user_text}")
        
        typing_task = asyncio.create_task(
            context.bot.send_chat_action(chat_id=user.id, action="typing")
        )
        
        ai_response = await self.ai.get_response(user_text, character)
        
        typing_task.cancel()
        
        logger.info(f"AI Response: {user.id} <- {ai_response[:50]}...")
        
        self.db.save_chat(user.id, ai_response, 'ai')
        
        await update.message.reply_text(
            ai_response,
            parse_mode='Markdown',
            reply_markup=self.keyboards.main_menu(True)
        )
    
    async def echo_response(self, update: Update, context: ContextTypes.DEFAULT_TYPE, user_text):
        response = f"""💬 *{user_text}*

🤖 *AI Mode: ❌ OFF*

Aktifkan AI dengan ketik:
• `ai on` - Nyalakan AI
• `cewe` - Karakter perempuan (Yuri)
• `cowo` - Karakter laki-laki (Andre)
• `menu` - Menu utama

_Semua chat disimpan di database_"""
        
        await update.message.reply_text(response, parse_mode='Markdown')
    
    async def ai_on(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user = update.effective_user
        enabled, character = self.db.set_ai_state(user.id, True)
        char_name = "Yuri" if character == "cewe" else "Andre"
        
        response = f"""✅ *AI DIAKTIFKAN!*

🤖 System: *Advanced AI*
🎭 Karakter: *{char_name}* ({character})
👤 User: {user.first_name}

💾 Database: assets/database/

Sekarang kamu bisa chat dengan AI!
Coba ketik pesan apa saja~ ✨

_Ketik 'ai off' untuk matikan_"""
        
        await self.send_response(update, context, response)
    
    async def ai_off(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user = update.effective_user
        enabled, character = self.db.set_ai_state(user.id, False)
        
        response = f"""❌ *AI DIMATIKAN!*

👤 User: {user.first_name}
🔧 Status: Mode Normal

AI telah dimatikan.
Bot kembali ke mode dasar.

_Ketik 'ai on' untuk nyalakan kembali_"""
        
        await self.send_response(update, context, response)
    
    async def ai_status(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user = update.effective_user
        ai_enabled = self.db.get_ai_state(user.id)
        character = self.db.get_character(user.id)
        char_name = "Yuri" if character == "cewe" else "Andre"
        
        status_text = "✅ **ON**" if ai_enabled else "❌ **OFF**"
        
        response = f"""🤖 *AI STATUS*

👤 User: {user.first_name}
🔧 Status: {status_text}
🎭 Karakter: *{char_name}* ({character})
📁 System: Advanced AI Engine

*Karakter tersedia:*
• Cewe - Yuri (Perempuan imut)
• Cowo - Andre (Laki-laki tsundere)

_Ganti karakter: ketik 'cewe' atau 'cowo'_"""
        
        await self.send_response(update, context, response)
    
    async def set_character(self, update: Update, context: ContextTypes.DEFAULT_TYPE, character):
        user = update.effective_user
        enabled, current_char = self.db.set_ai_state(user.id, True, character)
        
        char_name = "Yuri" if character == "cewe" else "Andre"
        char_desc = "perempuan imut" if character == "cewe" else "laki-laki tsundere"
        
        response = f"""🎭 *KARAKTER DIGANTI!*

👤 User: {user.first_name}
🤖 Karakter: *{char_name}* ({char_desc})
🔧 AI Status: {'✅ ON' if enabled else '❌ OFF'}

Karakter telah diubah ke {char_name}.
Sekarang AI akan berperan sebagai {char_desc}.

Coba chat untuk melihat perbedaannya~ ✨

_Ketik 'ai off' untuk matikan AI_"""
        
        await self.send_response(update, context, response)
    
    async def show_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user = update.effective_user
        ai_enabled = self.db.get_ai_state(user.id)
        character = self.db.get_character(user.id)
        char_name = "Yuri" if character == "cewe" else "Andre"
        
        menu_text = f"""📋 *MENU UTAMA*

👋 Halo, {user.first_name}!
🤖 AI Mode: {'✅ ON' if ai_enabled else '❌ OFF'}
🎭 Karakter: {char_name} ({character})

*Pilih opsi:*"""
        
        await self.send_response(
            update, 
            context, 
            menu_text,
            self.keyboards.main_menu(ai_enabled)
        )
    
    async def about(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        response = """🤖 *YILZI BASE BOT v4.0*

✨ *Fitur Unggulan:*
• Advanced AI System
• Multi Karakter AI
• Tanpa Prefix Command
• JSON Database
• Simpan Riwayat Chat

🔧 *Teknologi:*
• Python Telegram Bot
• JSON File Storage
• Interactive Menus

👨‍💻 *Developer:*
• Nama: Yilzi
• GitHub: YilziiHCT
• Telegram: @Yilziii
• Website: yilzicode.com

_Open Source • MIT License_"""
        
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("🌐 Website", url="https://yilzicode.com"),
             InlineKeyboardButton("📁 GitHub", url="https://github.com/YilziiHCT")],
            [InlineKeyboardButton("🏠 Menu", callback_data="menu")]
        ])
        
        await self.send_response(update, context, response, keyboard)
    
    async def help(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        response = """🆘 *BANTUAN & PERINTAH*

📌 *PERINTAH TEKS:*
• `menu` - Menu utama
• `ai on` - Aktifkan AI
• `ai off` - Matikan AI
• `ai status` - Cek status AI
• `cewe` - Karakter Yuri (perempuan)
• `cowo` - Karakter Andre (laki-laki)
• `help` - Bantuan ini
• `about` - Info bot
• `stats` - Statistik
• `profile` - Profil
• `ping` - Test bot

💡 *CARA PAKAI:*
1. Ketik `ai on` untuk aktifkan AI
2. Pilih karakter dengan `cewe` atau `cowo`
3. Langsung chat dengan AI
4. Ketik `ai off` untuk matikan

💾 *Database:* assets/database/

_Ketik 'menu' untuk kembali_"""
        
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("🤖 AI On", callback_data="ai_on"),
             InlineKeyboardButton("👧 Cewe", callback_data="char_cewe")],
            [InlineKeyboardButton("👦 Cowo", callback_data="char_cowo"),
             InlineKeyboardButton("📋 Menu", callback_data="menu")]
        ])
        
        await self.send_response(update, context, response, keyboard)
    
    async def stats(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        try:
            with open("assets/database/users.json", 'r') as f:
                users = json.load(f)
            with open("assets/database/chats.json", 'r') as f:
                chats = json.load(f)
            with open("assets/database/ai_settings.json", 'r') as f:
                ai_data = json.load(f)
        except:
            users = {}
            chats = []
            ai_data = {}
        
        total_users = len(users)
        total_chats = len(chats)
        ai_users = sum(1 for user in ai_data.values() if user.get("enabled", False))
        cewe_count = sum(1 for user in ai_data.values() if user.get("character") == "cewe")
        cowo_count = sum(1 for user in ai_data.values() if user.get("character") == "cowo")
        
        uptime = datetime.now() - self.start_time
        hours, remainder = divmod(int(uptime.total_seconds()), 3600)
        minutes, seconds = divmod(remainder, 60)
        
        response = f"""📊 *STATISTIK BOT*

👥 Total Users: `{total_users}`
💬 Total Chats: `{total_chats}`
🤖 AI Users: `{ai_users}`
👧 Cewe Users: `{cewe_count}`
👦 Cowo Users: `{cowo_count}`
⏱️ Uptime: {hours}h {minutes}m {seconds}s
📅 Start: {self.start_time.strftime('%d/%m/%Y %H:%M')}

💾 *Database Files:*
• users.json - {total_users} records
• chats.json - {total_chats} messages
• ai_settings.json - {len(ai_data)} users

_Update: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}_"""
        
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("🔄 Refresh", callback_data="stats"),
             InlineKeyboardButton("📋 Menu", callback_data="menu")]
        ])
        
        await self.send_response(update, context, response, keyboard)
    
    async def profile(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user = update.effective_user
        ai_enabled = self.db.get_ai_state(user.id)
        character = self.db.get_character(user.id)
        char_name = "Yuri" if character == "cewe" else "Andre"
        
        try:
            with open("assets/database/users.json", 'r') as f:
                users = json.load(f)
            user_data = users.get(str(user.id), {})
        except:
            user_data = {}
        
        response = f"""👤 *PROFIL USER*

🆔 ID: `{user.id}`
📛 Nama: {user.first_name}
👤 Username: @{user.username or '-'}
🤖 AI Mode: {'✅ ON' if ai_enabled else '❌ OFF'}
🎭 Karakter: {char_name} ({character})
📅 Bergabung: {user_data.get('join_date', 'Now')}
💬 Pesan: {user_data.get('message_count', 0)}
👀 Terakhir: {user_data.get('last_seen', 'Now')}

💾 *Storage:*
• Database: ✅ assets/database/
• AI System: ✅ Active
• Chat History: ✅ Enabled

_Profil diperbarui otomatis_"""
        
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("🤖 " + ("AI Off" if ai_enabled else "AI On"), 
              callback_data="ai_off" if ai_enabled else "ai_on")],
            [InlineKeyboardButton("👧 Cewe" if character == "cowo" else "👦 Cowo", 
              callback_data="char_cewe" if character == "cowo" else "char_cowo")],
            [InlineKeyboardButton("📋 Menu", callback_data="menu")]
        ])
        
        await self.send_response(update, context, response, keyboard)
    
    async def ping(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        response = "✅ *PONG!*\n\nBot aktif dan berjalan normal! 🚀"
        await self.send_response(update, context, response)
    
    async def send_response(self, update, context, text, reply_markup=None):
        if update.callback_query:
            await update.callback_query.edit_message_text(
                text=text,
                parse_mode='Markdown',
                reply_markup=reply_markup
            )
        else:
            await update.message.reply_text(
                text=text,
                parse_mode='Markdown',
                reply_markup=reply_markup
            )
    
    async def button_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        
        handlers = {
            "menu": self.show_menu,
            "ai_on": self.ai_on,
            "ai_off": self.ai_off,
            "ai_status": self.ai_status,
            "about": self.about,
            "help": self.help,
            "stats": self.stats,
            "profile": self.profile,
            "char_cewe": lambda u,c: self.set_character(u,c,"cewe"),
            "char_cowo": lambda u,c: self.set_character(u,c,"cowo")
        }
        
        if query.data in handlers:
            await handlers[query.data](update, context)
    
    async def error_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        logger.error(f"Error: {context.error}")
    
    def run(self):
        print("=" * 60)
        print("🤖 YILZI BOT v4.0 - ADVANCED AI EDITION")
        print("🔗 Powered by Interactive AI System")
        print(f"⏰ {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")
        print("=" * 60)
        
        app = Application.builder().token(self.token).build()
        
        app.add_handler(CommandHandler("start", self.start))
        app.add_handler(CallbackQueryHandler(self.button_handler))
        app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self.handle_message))
        app.add_error_handler(self.error_handler)
        
        print("✅ Bot started successfully!")
        print("📱 Buka Telegram dan ketik /start")
        print("🤖 Aktifkan AI dengan ketik 'ai on'")
        print("🎭 Karakter: cewe (Yuri) / cowo (Andre)")
        print("=" * 60)
        
        app.run_polling(
            allowed_updates=Update.ALL_TYPES,
            drop_pending_updates=True,
            close_loop=False
        )

if __name__ == "__main__":
    bot = YilziBot()
    bot.run()
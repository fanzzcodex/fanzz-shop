<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$config_file = __DIR__ . '/../global/gemini.json';

if (!file_exists($config_file)) {
    echo json_encode(['error' => 'Configuration file not found']);
    exit();
}

$config = json_decode(file_get_contents($config_file), true);

$api_keys = $config['api_keys'] ?? [];
$model = $config['model'] ?? 'gemini-2.5-flash';
$temperature = $config['temperature'] ?? 0.7;

if (empty($api_keys)) {
    $fallback_response = [
        'success' => true,
        'response' => get_fallback_response(),
        'character' => 'cewe',
        'model' => 'fallback',
        'note' => 'Using fallback mode (no API keys)'
    ];
    echo json_encode($fallback_response);
    exit();
}

$current_key = $api_keys[array_rand($api_keys)];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['message'])) {
        echo json_encode(['error' => 'Invalid input: message required']);
        exit();
    }
    
    $message = trim($input['message']);
    $character = trim($input['character'] ?? 'cewe');
    
    if (empty($message)) {
        echo json_encode(['error' => 'Message cannot be empty']);
        exit();
    }
    
    $prompt_file = __DIR__ . "/../global/prompts/{$character}.txt";
    if (!file_exists($prompt_file)) {
        $character = 'cewe';
        $prompt_file = __DIR__ . "/../global/prompts/cewe.txt";
    }
    
    $character_prompt = trim(file_get_contents($prompt_file));
    $full_prompt = $character_prompt . "\n\nUser: " . $message . "\nAI:";
    
    $api_url = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key={$current_key}";
    
    $post_data = [
        'contents' => [
            'parts' => [
                ['text' => $full_prompt]
            ]
        ],
        'generationConfig' => [
            'temperature' => $temperature,
            'topK' => 1,
            'topP' => 1,
            'maxOutputTokens' => 2048
        ]
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json'
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);
    
    if ($http_code === 200) {
        $result = json_decode($response, true);
        
        if (isset($result['candidates'][0]['content']['parts'][0]['text'])) {
            $ai_response = trim($result['candidates'][0]['content']['parts'][0]['text']);
            $response_data = [
                'success' => true,
                'response' => $ai_response,
                'character' => $character,
                'model' => $model,
                'timestamp' => date('Y-m-d H:i:s')
            ];
        } else {
            $response_data = [
                'success' => true,
                'response' => get_fallback_response($message, $character),
                'character' => $character,
                'model' => 'fallback',
                'note' => 'Using fallback response'
            ];
        }
    } else {
        error_log("Gemini API Error {$http_code}: " . $curl_error);
        $response_data = [
            'success' => true,
            'response' => get_fallback_response($message, $character),
            'character' => $character,
            'model' => 'fallback',
            'note' => 'API failed, using fallback'
        ];
    }
    
    echo json_encode($response_data, JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode([
        'error' => 'Method not allowed',
        'allowed_methods' => ['POST']
    ]);
}

function get_fallback_response($message = '', $character = 'cewe') {
    $responses = [
        'cewe' => [
            "Haii~! Yuri di sini! {$message}? Wah, seru banget! ✨",
            "Ufufu~ tentang {$message} ya? Aku penasaran nih! 💭",
            "Wah, kamu cerita {$message}? Seru banget dengerinnya! 😊",
            "{$message}? Aku suka banget topik itu! Cerita lebih banyak dong~ 💖",
            "Hmm... {$message}... Menurutku itu ide yang bagus! 🌈",
            "Aku denger kamu ngomongin {$message}, keren banget! 🎉",
            "Yuri penasaran nih soal {$message}, ceritain dong~ 🥰",
            "Wah, {$message} itu menarik banget! Aku mau tau lebih banyak! 🤩",
            "Halo~! {$message} ya? Aku siap mendengarkan! 💕",
            "Yo~! {$message}? Sounds interesting! 🌟"
        ],
        'cowo' => [
            "Hmph. {$message}? Boleh juga.",
            "{$message}? Ya, begitulah.",
            "Tch. {$message}. Emangnya kenapa?",
            "{$message}? Lumayan lah.",
            "Hah? {$message}? Ya terserah.",
            "{$message}. Gitu doang?",
            "{$message}? Cukup menarik.",
            "{$message}. Hmm, oke.",
            "{$message}. Begitu.",
            "{$message}. Ya."
        ]
    ];
    
    $char_responses = $responses[$character] ?? $responses['cewe'];
    return $char_responses[array_rand($char_responses)];
}
?>
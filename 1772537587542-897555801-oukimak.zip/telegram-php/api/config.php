<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$config = [
    'ai' => [
        'provider' => 'gemini',
        'models' => [
            'gemini-2.5-flash',
            'gemini-2.5-flash-preview-09-2025'
        ],
        'temperature' => 0.7,
        'max_tokens' => 2048
    ],
    'characters' => [
        'cewe' => [
            'name' => 'Yuri',
            'description' => 'Karakter anime perempuan imut',
            'age' => 16,
            'prompt_file' => '../global/prompts/cewe.txt'
        ],
        'cowo' => [
            'name' => 'Andre',
            'description' => 'Karakter anime laki-laki tsundere',
            'age' => 17,
            'prompt_file' => '../global/prompts/cowo.txt'
        ]
    ],
    'api' => [
        'endpoints' => [
            'gemini' => '/api/gemini.php',
            'config' => '/api/config.php',
            'status' => '/api/status.php'
        ],
        'rate_limit' => 60,
        'timeout' => 30
    ],
    'bot' => [
        'name' => 'Yilzi Base Bot',
        'version' => '4.0.0',
        'developer' => 'Yilzi (@Yilziii)',
        'website' => 'yilzicode.com'
    ]
];

echo json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
?>
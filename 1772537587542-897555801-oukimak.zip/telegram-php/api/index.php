<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$response = [
    'status' => 'online',
    'service' => 'Yilzi Bot API',
    'version' => '4.0.0',
    'endpoints' => [
        'POST /api/gemini' => 'AI Chat with Gemini',
        'GET /api/config' => 'Get API configuration',
        'GET /api/status' => 'Check API status'
    ],
    'developer' => [
        'name' => 'Yilzi',
        'telegram' => '@Yilziii',
        'github' => 'YilziiHCT',
        'website' => 'yilzicode.com'
    ],
    'timestamp' => date('Y-m-d H:i:s')
];

echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
?>
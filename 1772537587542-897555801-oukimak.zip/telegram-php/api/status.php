<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

function check_file($path) {
    return file_exists($path) ? ['exists' => true, 'size' => filesize($path)] : ['exists' => false];
}

$status = [
    'status' => 'online',
    'timestamp' => date('Y-m-d H:i:s'),
    'server' => $_SERVER['SERVER_SOFTWARE'] ?? 'PHP Development Server',
    'files' => [
        'config' => check_file('../config/bot.php'),
        'prompt_cewe' => check_file('../global/prompts/cewe.txt'),
        'prompt_cowo' => check_file('../global/prompts/cowo.txt'),
        'gemini_config' => check_file('../global/gemini.json'),
        'database_users' => check_file('../assets/database/users.json'),
        'database_chats' => check_file('../assets/database/chats.json')
    ],
    'memory' => [
        'usage' => memory_get_usage(),
        'peak' => memory_get_peak_usage(),
        'limit' => ini_get('memory_limit')
    ],
    'php' => [
        'version' => PHP_VERSION,
        'extensions' => get_loaded_extensions()
    ]
];

echo json_encode($status, JSON_PRETTY_PRINT);
?>